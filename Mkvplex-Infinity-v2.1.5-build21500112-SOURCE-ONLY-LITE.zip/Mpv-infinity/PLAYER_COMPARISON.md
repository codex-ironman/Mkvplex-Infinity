# Player comparison against the original mpvRx v2.7.2

Original source: commit 9d5a27c2ba6e53e6d33633791ab8a5bb6747720c, tag v2.7.2. Current custom release: build 27300112. APK-level checks and exact test totals are recorded in VALIDATION.json.

| Area | Comparison and behavior |
|---|---|
| MPVView.kt | Original initialization, rendering, hardware-decoder selection, shaders, frame synchronization and shared streaming/cache settings are unchanged. |
| DecoderPreferences.kt and RendererBackendPolicy.kt | Unchanged from v2.7.2. No forced software decoder, new renderer or profile was introduced. |
| Player controls, theme, icons, bundled graphics/fonts | No code/resource changes in these protected areas. Packaging checks all 227 bundled assets and preserves the 18 original native libraries; regenerated ART profiles match the rebuilt DEX. |
| PlaybackSession.kt | Keeps same-title queue replacement for fallback and account-header scoping for direct delivery. The custom Jellyfin-only fast-start options were removed; the loadfile-options block now matches the original. |
| PlayerActivity.kt | Adds same-title failure recovery and provider-aware reporting, scopes HTTP headers, and now attaches remote subtitles asynchronously off Main with a file-generation guard. |
| PlaybackModels.kt | Normalizes only a redundant matching modern ApiKey query parameter so the prior resume identity is retained. |
| MediaUtils.kt | Adds the same-title source-session identifier to the launch intent. |
| JellyfinSessionReporter.kt | Retains provider-specific authorization for status reports. This remains IO work; no video decoding is performed here. |

The live Polyfin metadata for the sampled 81.9 GiB / 80.9 Mbps movie source includes 24 external subtitles in addition to embedded video/audio/subtitle tracks. The previous loader switched to Main.immediate for each remote sub-add. Inspection of the original APK's libplayer.so finds an imported mpv_command symbol, and the wrapper source calls that blocking function. mpv documents sub-add as having distinct synchronous/asynchronous behavior; its async command is abortable on playback end.

The corrected loader sends async sub-add from the existing IO job and uses commandForGeneration so an obsolete URI resolution cannot submit a track for a different title. All 24 subtitles remain available as they load, with their original display titles/languages. The last explicit primary selection is preserved even when HTTP requests finish in a different order.

Controlled native regression: a real desktop libmpv0.37 instance played synthetic local video while a localhost server delayed each of 24 subtitle responses by 150ms. The original blocking calls occupied their caller for about 3.7s. Async submission returned in under 10ms; all 24 tracks/titles loaded, property queries stayed responsive and pending old-file subtitle work was cancelled on file replacement. Desktop results establish the blocking mechanism and command behavior, not Android UI frame rate, thermal behavior or sustained high-bitrate playback on the user's phone.

References:

- https://mpv.io/manual/master/#synchronous-vs-asynchronous
- https://github.com/mpv-player/mpv/blob/v0.41.0/player/command.c
- https://github.com/Riteshp2001/mpvlibAndroid (app/src/main/jni/main.cpp, command JNI wrapper)

No server settings were changed for this revision.
