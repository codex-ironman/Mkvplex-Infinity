/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.ui.browser.jellyfin

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.infinity.mpvz.domain.jellyfin.JellyfinItem
import app.infinity.mpvz.domain.jellyfin.JellyfinMediaSource
import kotlinx.coroutines.CancellationException

/** Keeps Infinity's explicit download-version choice, using the shared custom source model. */
@Composable
internal fun JellyfinDownloadSourceDialog(
  item: JellyfinItem,
  load: suspend () -> List<JellyfinMediaSource>,
  onSelect: (JellyfinMediaSource) -> Unit,
  onDismiss: () -> Unit,
) {
  var attempt by remember(item.id) { mutableIntStateOf(0) }
  var loading by remember(item.id) { mutableStateOf(true) }
  var failed by remember(item.id) { mutableStateOf(false) }
  var sources by remember(item.id) { mutableStateOf<List<JellyfinMediaSource>>(emptyList()) }
  LaunchedEffect(item.id, attempt) {
    loading = true; failed = false
    try { sources = load().distinctBy { it.id } }
    catch (cancelled: CancellationException) { throw cancelled }
    catch (_: Exception) { failed = true; sources = emptyList() }
    finally { loading = false }
  }
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Choose download quality") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(item.name, style = MaterialTheme.typography.titleMedium)
        when {
          loading -> CircularProgressIndicator()
          sources.isEmpty() -> {
            Text(if (failed) "Could not fetch download links." else "No download links returned yet.")
            TextButton(onClick = { attempt++ }) { Text("Retry") }
          }
          else -> LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
            items(sources, key = { it.id }) { source ->
              TextButton(onClick = { onSelect(source) }, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Text(source.name, style = MaterialTheme.typography.bodyLarge)
                  if (source.description.isNotBlank()) Text(source.description, style = MaterialTheme.typography.bodySmall)
                }
              }
            }
          }
        }
      }
    },
    confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
  )
}
