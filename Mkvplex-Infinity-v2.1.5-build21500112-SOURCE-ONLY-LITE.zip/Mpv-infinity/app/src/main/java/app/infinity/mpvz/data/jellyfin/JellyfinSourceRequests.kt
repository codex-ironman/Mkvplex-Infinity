/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.data.jellyfin

import app.infinity.mpvz.domain.jellyfin.JellyfinMediaSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async

/** Share a current detail-page fetch with its chooser, without retaining idle work. */
internal class JellyfinSourceRequests {
  private class Entry(val task: Deferred<Result<List<JellyfinMediaSource>>>, var readers: Int = 0)
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private val entries = mutableMapOf<JellyfinSourceCache.Key, Entry>()

  suspend fun load(
    key: JellyfinSourceCache.Key,
    request: suspend () -> Result<List<JellyfinMediaSource>>,
  ): Result<List<JellyfinMediaSource>> {
    val entry = synchronized(entries) {
      entries.getOrPut(key) { Entry(scope.async(start = CoroutineStart.LAZY) { request() }) }
        .also { it.readers++ }
    }
    try {
      return entry.task.await()
    } finally {
      synchronized(entries) {
        entry.readers--
        if (entry.readers == 0) {
          if (entries[key] === entry) entries.remove(key)
          entry.task.cancel()
        }
      }
    }
  }

  fun invalidate(server: String, user: String, token: String) {
    synchronized(entries) {
      val matching = entries.filterKeys { it.server == server && it.user == user && it.token == token }
      matching.forEach { (key, entry) ->
        entries.remove(key)
        entry.task.cancel()
      }
    }
  }
}
