/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.ui.browser.jellyfin

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.ui.platform.LocalConfiguration
import app.infinity.mpvz.utils.media.MediaUtils
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.infinity.mpvz.R
import app.infinity.mpvz.data.jellyfin.JellyfinClient
import app.infinity.mpvz.domain.jellyfin.JellyfinItem
import app.infinity.mpvz.domain.jellyfin.JellyfinServer
import app.infinity.mpvz.presentation.components.RemoteImage
import app.infinity.mpvz.ui.icons.Icon
import app.infinity.mpvz.ui.icons.Icons
import app.infinity.mpvz.ui.player.controls.components.tvFocusHighlight
import app.infinity.mpvz.ui.player.controls.components.tvContextMenu
import app.infinity.mpvz.ui.theme.LocalDarkAppColorScheme
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/** Watch-progress overlay drawn on top of artwork; uses the always-dark accent so the
 * fill stays visible on the black track in light mode. */
@Composable
private fun WatchProgressOverlayBar(
  progress: Float,
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.height(4.dp)) {
    Box(modifier = Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.6f)))
    Box(
      modifier =
        Modifier
          .fillMaxHeight()
          .fillMaxWidth(progress.coerceIn(0f, 1f))
          .background((LocalDarkAppColorScheme.current ?: MaterialTheme.colorScheme).primary),
    )
  }
}

private fun buildStarSubtitle(
  partsBeforeRating: List<String>,
  communityRating: Double?,
  criticRating: Double?,
  partsAfterRating: List<String> = emptyList(),
): AnnotatedString {
  return buildAnnotatedString {
    var hasContent = false
    partsBeforeRating.filter { it.isNotBlank() }.forEach { part ->
      if (hasContent) append(" • ")
      append(part)
      hasContent = true
    }
    communityRating?.let { rating ->
      if (hasContent) append(" • ")
      withStyle(SpanStyle(fontSize = 13.5.sp)) {
        append("★ ")
      }
      append("%.1f".format(rating))
      hasContent = true
    }
    criticRating?.let { critic ->
      if (hasContent) append(" • ")
      append("🍅 ${critic.roundToInt()}%")
      hasContent = true
    }
    partsAfterRating.filter { it.isNotBlank() }.forEach { part ->
      if (hasContent) append(" • ")
      append(part)
      hasContent = true
    }
  }
}

// ============================================================================
// Hero Featured Carousel Banner (Material 3 Expressive)
// ============================================================================

@Composable
fun JellyfinHeroBanner(
  items: List<JellyfinItem>,
  server: JellyfinServer,
  onPlay: (JellyfinItem) -> Unit,
  onDetails: (JellyfinItem) -> Unit,
  modifier: Modifier = Modifier,
) {
  if (items.isEmpty()) return

  val pageCount = if (items.size > 1) Int.MAX_VALUE else items.size
  val initialPage = remember(items) {
    if (items.size > 1) {
      val middle = Int.MAX_VALUE / 2
      middle - (middle % items.size)
    } else 0
  }
  val pagerState = rememberPagerState(initialPage = initialPage, pageCount = { pageCount })
  val artworkById = remember(server.serverUrl, server.accessToken, items) {
    items.associate { it.id to heroArtwork(server, it) }
  }
  val readyItems = remember(artworkById) { mutableStateMapOf<String, Boolean>() }
  val settledPage = pagerState.settledPage
  val settledItem = items[settledPage % items.size]
  val settledReady = readyItems[settledItem.id] == true

  // Give the first usable frame its full viewing time, even on a slow connection.
  LaunchedEffect(settledPage, items.size, settledReady) {
    if (items.size > 1 && settledReady) {
      delay(5000L)
      if (!pagerState.isScrollInProgress) {
        pagerState.animateScrollToPage(pagerState.currentPage + 1, animationSpec = tween(800))
      }
    }
  }
  if (settledReady && items.size > 1) {
    val next = items[(settledPage + 1) % items.size]
    PrefetchJellyfinHeroBackdrop(artworkById[next.id]?.preferred)
  }

  val configuration = LocalConfiguration.current
  val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
  val screenHeight = configuration.screenHeightDp.dp
  val heroHeight = if (isLandscape) (screenHeight * 0.95f).coerceAtMost(560.dp) else (screenHeight * 0.65f).coerceIn(480.dp, 560.dp)

  Box(
    modifier =
      modifier
        .fillMaxWidth()
        .height(heroHeight),
  ) {
    HorizontalPager(
      state = pagerState,
      modifier = Modifier.fillMaxSize(),
    ) { page ->
      val item = items[page % items.size]
      val artwork = artworkById.getValue(item.id)
      val logo = rememberJellyfinHeroLogo(artwork.logo, readyItems[item.id] == true)

      Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant)) {
        JellyfinHeroBackdrop(artwork, item.name) { readyItems[item.id] = true }

        // Gradient Scrim: top dark for status/topbar, bottom gradient melting into background
        Box(
          modifier =
            Modifier
              .fillMaxSize()
              .background(
                Brush.verticalGradient(
                  0.0f to Color.Black.copy(alpha = 0.6f),
                  0.25f to Color.Transparent,
                  0.65f to MaterialTheme.colorScheme.background.copy(alpha = 0.6f),
                  1.0f to MaterialTheme.colorScheme.background,
                ),
              ),
        )

        // Hero Info Overlay
        Column(
          modifier =
            Modifier
              .fillMaxSize()
              .padding(horizontal = 20.dp, vertical = 16.dp),
          verticalArrangement = Arrangement.Bottom,
        ) {
          // Keep the title visible while the logo loads, and if its request fails.
          if (logo != null) {
            Box(
              modifier =
                Modifier
                  .fillMaxWidth(0.85f)
                  .heightIn(min = 44.dp, max = 96.dp)
                  .padding(bottom = 6.dp),
              contentAlignment = Alignment.BottomStart,
            ) {
              Image(
                bitmap = remember(logo) { logo.asImageBitmap() },
                contentDescription = "${item.name} logo",
                contentScale = ContentScale.Fit,
                alignment = Alignment.BottomStart,
                modifier =
                  Modifier
                    .fillMaxHeight()
                    .wrapContentWidth(Alignment.Start),
              )
            }
          } else {
            Text(
              text = item.name,
              style = MaterialTheme.typography.headlineMedium,
              fontWeight = FontWeight.ExtraBold,
              color = MaterialTheme.colorScheme.onSurface,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.padding(bottom = 4.dp),
            )
          }

          // Genres / Tagline
          val metaText =
            when {
              item.genres.isNotEmpty() -> item.genresString
              !item.taglines.isEmpty() -> item.taglines.first()
              item.isSeries && item.childCount != null -> "${item.childCount} Seasons"
              else -> item.type
            }

          if (metaText.isNotBlank()) {
            Text(
              text = metaText,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.padding(bottom = 8.dp),
            )
          }

          // Badges Row (Rating, Year, Resolution)
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 12.dp),
          ) {
            // Type Pill (Featured)
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f),
            ) {
              Text(
                text = if (item.isSeries) "SERIES" else "MOVIE",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              )
            }

            // Rating Pill
            item.communityRating?.let { rating ->
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color.Black.copy(alpha = 0.6f),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                  Icon(
                    imageVector = Icons.RoundedFilled.Star,
                    contentDescription = null,
                    tint = Color(0xFFFFC107),
                    modifier = Modifier.size(12.dp),
                  )
                  Text(
                    text = "%.1f".format(rating),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White,
                  )
                }
              }
            }

            // Rotten Tomatoes / Critic Rating Pill
            item.criticRating?.let { critic ->
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color.Black.copy(alpha = 0.6f),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                  Text(
                    text = "🍅",
                    style = MaterialTheme.typography.labelSmall,
                  )
                  Text(
                    text = "${critic.roundToInt()}%",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White,
                  )
                }
              }
            }

            // Year Pill
            item.productionYear?.let { year ->
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color.Black.copy(alpha = 0.6f),
              ) {
                Text(
                  text = year.toString(),
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  color = Color.White,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
              }
            }

            // Quality Badge (4K / HDR)
            item.qualityBadge?.let { badge ->
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color.Black.copy(alpha = 0.6f),
              ) {
                Text(
                  text = badge,
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                  // Always-dark accent: colorScheme.primary is too dark for the black scrim in light mode.
                  color = (LocalDarkAppColorScheme.current ?: MaterialTheme.colorScheme).primary,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
              }
            }
          }

          // Action Buttons Row
          Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Button(
              onClick = { onPlay(item) },
              shape = RoundedCornerShape(14.dp),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
              contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
            ) {
              Icon(
                imageVector = if (item.isSeries && item.progressPercent <= 0.05f) Icons.RoundedFilled.Tv else Icons.RoundedFilled.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text =
                  when {
                    item.progressPercent > 0.05f -> "Resume"
                    item.isSeries -> "Explore Series"
                    else -> "Watch Now"
                  },
                fontWeight = FontWeight.Bold,
              )
            }

            FilledTonalButton(
              onClick = { onDetails(item) },
              shape = RoundedCornerShape(14.dp),
              contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            ) {
              Icon(
                imageVector = Icons.RoundedFilled.Info,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = "Details", fontWeight = FontWeight.Medium)
            }

            // Trailer Icon Button
            val heroContext = LocalContext.current
            FilledTonalIconButton(
              onClick = {
                val rawUrl = item.remoteTrailerUrl?.takeIf { it.isNotBlank() }
                val trailerUrl = if (!rawUrl.isNullOrBlank()) {
                  if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) rawUrl
                  else "https://www.youtube.com/watch?v=$rawUrl"
                } else {
                  "https://www.youtube.com/results?search_query=${java.net.URLEncoder.encode("${item.name} trailer", "UTF-8")}"
                }
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(trailerUrl)).apply {
                  addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                runCatching { heroContext.startActivity(intent) }
              },
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier.size(42.dp),
            ) {
              Icon(
                imageVector = Icons.RoundedFilled.Movie,
                contentDescription = "Trailer",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp),
              )
            }
          }
        }
      }
    }

    // Sliding 5-Dot Worm Indicator (AFinity style)
    if (items.size > 1) {
      SlidingWormDotsIndicator(
        pagerState = pagerState,
        pageCount = items.size,
        modifier =
          Modifier
            .align(Alignment.BottomEnd)
            .padding(end = 20.dp, bottom = 16.dp),
      )
    }
  }
}

@Composable
private fun SlidingWormDotsIndicator(
  pagerState: PagerState,
  pageCount: Int,
  modifier: Modifier = Modifier,
  visibleDotCount: Int = 5,
) {
  if (pageCount <= 1) return

  val fraction by remember(pagerState, pageCount) {
    derivedStateOf {
      val rawPage = pagerState.currentPage
      val offset = pagerState.currentPageOffsetFraction
      val page = rawPage % pageCount
      (page.toFloat() + offset).coerceIn(0f, (pageCount - 1).toFloat())
    }
  }

  val maxStart = (pageCount - visibleDotCount).coerceAtLeast(0).toFloat()
  val windowStart = (fraction - (visibleDotCount - 1) / 2f).coerceIn(0f, maxStart)

  Row(
    modifier = modifier,
    horizontalArrangement = Arrangement.spacedBy(5.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    val countToRender = visibleDotCount.coerceAtMost(pageCount)
    repeat(countToRender) { dotIndex ->
      val itemIndex = windowStart + dotIndex
      val dist = kotlin.math.abs(fraction - itemIndex)
      val activeFactor = (1f - dist).coerceIn(0f, 1f)

      val isLeftEdge = dotIndex == 0 && windowStart > 0.1f
      val isRightEdge = dotIndex == countToRender - 1 && windowStart < maxStart - 0.1f
      val edgeScale = if (isLeftEdge || isRightEdge) 0.65f else 1.0f

      val dotWidth = (6f + 12f * activeFactor) * edgeScale
      val dotHeight = (5f + 1f * activeFactor) * edgeScale
      val dotAlpha = 0.35f + 0.65f * activeFactor

      Box(
        modifier =
          Modifier
            .height(dotHeight.dp)
            .width(dotWidth.dp)
            .clip(CircleShape)
            .background(
              if (activeFactor > 0.4f) {
                MaterialTheme.colorScheme.primary.copy(alpha = dotAlpha)
              } else {
                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = dotAlpha)
              },
            ),
      )
    }
  }
}

// ============================================================================
// Section Header with Optional "See All" Action
// ============================================================================

@Composable
fun JellyfinSectionHeader(
  title: String,
  modifier: Modifier = Modifier,
  subtitle: String? = null,
  onSeeAll: (() -> Unit)? = null,
) {
  Row(
    modifier =
      modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column {
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
      )
      if (!subtitle.isNullOrBlank()) {
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }

    if (onSeeAll != null) {
      TextButton(
        onClick = onSeeAll,
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
      ) {
        Text(
          text = "See All",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.primary,
        )
        Icon(
          imageVector = Icons.RoundedFilled.ChevronRight,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(16.dp),
        )
      }
    }
  }
}

// ============================================================================
// Horizontal Scroll Section Container
// ============================================================================

@Composable
fun JellyfinHorizontalSection(
  title: String,
  items: List<JellyfinItem>,
  server: JellyfinServer,
  onItemClick: (JellyfinItem) -> Unit,
  onItemLongClick: ((JellyfinItem) -> Unit)? = null,
  modifier: Modifier = Modifier,
  onSeeAll: (() -> Unit)? = null,
  subtitle: String? = null,
  isContinueWatching: Boolean = false,
) {
  if (items.isEmpty()) return

  Column(
    modifier = modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    JellyfinSectionHeader(
      title = title,
      subtitle = subtitle,
      onSeeAll = onSeeAll,
    )

    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(horizontal = 16.dp),
    ) {
      items(items, key = { it.id }) { item ->
        if (isContinueWatching) {
          JellyfinResumeCard(
            item = item,
            server = server,
            onClick = { onItemClick(item) },
            onLongClick = onItemLongClick?.let { { it(item) } },
          )
        } else {
          JellyfinPosterCard(
            item = item,
            server = server,
            onClick = { onItemClick(item) },
            onLongClick = onItemLongClick?.let { { it(item) } },
            cardWidth = 136.dp,
          )
        }
      }
    }
  }
}

// ============================================================================
// Continue Watching Card (16:9 Cinematic Backdrop)
// ============================================================================

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun JellyfinResumeCard(
  item: JellyfinItem,
  server: JellyfinServer,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  onLongClick: (() -> Unit)? = null,
  isSelected: Boolean = false,
  isInSelectionMode: Boolean = false,
) {
  val imageUrl =
    remember(server.serverUrl, item.id, item.backdropImageTag, item.primaryImageTag, server.accessToken) {
      if (!item.backdropImageTag.isNullOrBlank()) {
        JellyfinClient.getBackdropUrl(
          serverUrl = server.serverUrl,
          itemId = item.id,
          imageTag = item.backdropImageTag,
          maxWidth = 540,
          token = server.accessToken,
        )
      } else {
        JellyfinClient.getImageUrl(
          serverUrl = server.serverUrl,
          itemId = item.id,
          imageTag = item.primaryImageTag,
          maxWidth = 400,
          token = server.accessToken,
        )
      }
    }

  val posterBorderModifier =
    if (isSelected) {
      Modifier.clip(RoundedCornerShape(10.dp)).border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp))
    } else {
      Modifier.clip(RoundedCornerShape(10.dp))
    }

  Column(
    modifier = modifier.width(230.dp),
  ) {
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .aspectRatio(16f / 9f)
          .tvFocusHighlight(RoundedCornerShape(10.dp), focusedScale = 1.03f)
          .then(posterBorderModifier)
          .background(MaterialTheme.colorScheme.surfaceContainerHighest)
          .tvContextMenu(onLongClick)
          .combinedClickable(
            onClick = onClick,
            onLongClick = onLongClick,
          ),
    ) {
      RemoteImage(
        url = imageUrl,
        contentDescription = item.name,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize(),
      )

      // Gradient at bottom of thumbnail for progress legibility
      Box(
        modifier =
          Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                0.5f to Color.Transparent,
                1.0f to Color.Black.copy(alpha = 0.7f),
              ),
            ),
      )

      // Play Button Overlay
      if (!isInSelectionMode && !isSelected) {
        Surface(
          shape = CircleShape,
          color = Color.Black.copy(alpha = 0.55f),
          modifier =
            Modifier
              .size(40.dp)
              .align(Alignment.Center),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.RoundedFilled.PlayArrow,
              contentDescription = "Play",
              tint = Color.White,
              modifier = Modifier.size(24.dp),
            )
          }
        }
      }

      // Selection Checkmark
      if (isSelected) {
        Box(
          modifier =
            Modifier
              .fillMaxSize()
              .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
          contentAlignment = Alignment.Center,
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(34.dp),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.RoundedFilled.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(20.dp),
              )
            }
          }
        }
      }

      // Remaining runtime chip
      val remaining = item.formattedRemainingDuration
      if (remaining.isNotBlank()) {
        Surface(
          shape = RoundedCornerShape(4.dp),
          color = Color.Black.copy(alpha = 0.75f),
          modifier =
            Modifier
              .padding(6.dp)
              .align(Alignment.BottomEnd),
        ) {
          Text(
            text = remaining,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = Color.White,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
          )
        }
      }

      // Progress bar at bottom
      if (item.progressPercent > 0.01f) {
        WatchProgressOverlayBar(
          progress = item.progressPercent,
          modifier =
            Modifier
              .fillMaxWidth()
              .align(Alignment.BottomCenter),
        )
      }
    }

    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(top = 6.dp),
      horizontalAlignment = Alignment.Start,
    ) {
      val title = item.seriesName ?: item.name
      val subtitle =
        if (item.seriesName != null && item.indexNumber != null) {
          AnnotatedString("S${item.parentIndexNumber ?: 1}:E${item.indexNumber} • ${item.name}")
        } else {
          val before = buildList {
            item.productionYear?.let { add(it.toString()) }
            val dur = item.formattedDuration
            if (dur.isNotBlank()) add(dur) else if (item.productionYear == null) add(item.type)
          }
          buildStarSubtitle(before, item.communityRating, item.criticRating)
        }

      Text(
        text = title,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Start,
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.fillMaxWidth(),
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Start,
        modifier = Modifier.fillMaxWidth(),
      )
    }
  }
}

// ============================================================================
// Modern Poster Card (2:3 Aspect Ratio)
// ============================================================================

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun JellyfinPosterCard(
  item: JellyfinItem,
  server: JellyfinServer,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  cardWidth: androidx.compose.ui.unit.Dp? = null,
  onLongClick: (() -> Unit)? = null,
  isSelected: Boolean = false,
  isDownloaded: Boolean = false,
) {
  val posterImageTag = if (item.type == "Episode" && !item.seriesPrimaryImageTag.isNullOrBlank()) {
    item.seriesPrimaryImageTag
  } else {
    item.primaryImageTag
  }
  val posterItemId = if (item.type == "Episode" && !item.seriesId.isNullOrBlank() && !item.seriesPrimaryImageTag.isNullOrBlank()) {
    item.seriesId
  } else {
    item.id
  }
  val imageUrl =
    remember(server.serverUrl, posterItemId, posterImageTag, server.accessToken) {
      JellyfinClient.getImageUrl(
        serverUrl = server.serverUrl,
        itemId = posterItemId,
        imageTag = posterImageTag,
        maxWidth = 400,
        token = server.accessToken,
      )
    }

  val cardModifier =
    if (cardWidth != null) {
      modifier.width(cardWidth)
    } else {
      modifier.fillMaxWidth()
    }

  val posterBorderModifier =
    if (isSelected) {
      Modifier.clip(RoundedCornerShape(8.dp)).border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
    } else {
      Modifier.clip(RoundedCornerShape(8.dp))
    }

  Column(
    modifier = cardModifier,
  ) {
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .aspectRatio(2f / 3f)
          .tvFocusHighlight(RoundedCornerShape(8.dp), focusedScale = 1.03f)
          .then(posterBorderModifier)
          .background(MaterialTheme.colorScheme.surfaceContainerHighest)
          .tvContextMenu(onLongClick)
          .combinedClickable(
            onClick = onClick,
            onLongClick = onLongClick,
          ),
    ) {
      if (!item.primaryImageTag.isNullOrBlank()) {
        RemoteImage(
          url = imageUrl,
          contentDescription = item.name,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
      } else {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center,
        ) {
          val placeholderIcon =
            when {
              item.isAudio -> Icons.RoundedFilled.Audiotrack
              item.isFolder -> Icons.RoundedFilled.Folder
              item.isSeries || (item.type == "Episode" && !item.seriesName.isNullOrBlank()) -> Icons.RoundedFilled.Tv
              else -> Icons.RoundedFilled.Movie
            }
          Icon(
            imageVector = placeholderIcon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(36.dp),
          )
        }
      }

      // Top badge: Quality on left
      item.qualityBadge?.let { qBadge ->
        Surface(
          shape = RoundedCornerShape(4.dp),
          color = Color.Black.copy(alpha = 0.7f),
          modifier =
            Modifier
              .align(Alignment.TopStart)
              .padding(6.dp),
        ) {
          Text(
            text = qBadge,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
            // Always-dark accent: colorScheme.primary is too dark for the black scrim in light mode.
            color = (LocalDarkAppColorScheme.current ?: MaterialTheme.colorScheme).primary,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
          )
        }
      }

      if (isDownloaded) {
        DownloadedBadge(modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
      }

      // Progress bar if partially watched
      if (item.progressPercent > 0.02f && !item.isPlayed) {
        WatchProgressOverlayBar(
          progress = item.progressPercent,
          modifier =
            Modifier
              .fillMaxWidth()
              .align(Alignment.BottomCenter),
        )
      }

      // Selection / Played Check badge
      if (isSelected) {
        Surface(
          shape = CircleShape,
          color = MaterialTheme.colorScheme.primary,
          modifier =
            Modifier
              .padding(6.dp)
              .size(24.dp)
              .align(Alignment.BottomEnd),
        ) {
          Icon(
            imageVector = Icons.RoundedFilled.Check,
            contentDescription = "Selected",
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.padding(3.dp),
          )
        }
      } else if (item.isPlayed) {
        Surface(
          shape = CircleShape,
          color = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f),
          modifier =
            Modifier
              .padding(6.dp)
              .size(20.dp)
              .align(Alignment.BottomEnd),
        ) {
          Icon(
            imageVector = Icons.RoundedFilled.Check,
            contentDescription = "Played",
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.padding(3.dp),
          )
        }
      }
    }

    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(top = 6.dp),
      horizontalAlignment = Alignment.Start,
    ) {
      val title = if (item.type == "Episode" && !item.seriesName.isNullOrBlank()) item.seriesName else item.name
      Text(
        text = title,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Start,
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.fillMaxWidth(),
      )
      val subtitle =
        run {
          val before = buildList {
            item.productionYear?.let { add(it.toString()) }
            if (item.isSeries && item.childCount != null && item.childCount > 0) {
              add(if (item.childCount == 1) "1 Season" else "${item.childCount} Seasons")
            } else if (item.type == "Episode") {
              if (item.parentIndexNumber != null && item.indexNumber != null) {
                add("S${item.parentIndexNumber}:E${item.indexNumber}")
              } else {
                add("Episode")
              }
            } else if (item.productionYear == null) {
              add(item.type)
            }
          }
          buildStarSubtitle(before, item.communityRating, item.criticRating)
        }
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Start,
        modifier = Modifier.fillMaxWidth(),
      )
    }
  }
}

// ============================================================================
// Music Card (1:1 Aspect Ratio Square Artwork)
// ============================================================================

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun JellyfinMusicCard(
  item: JellyfinItem,
  server: JellyfinServer,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  cardWidth: androidx.compose.ui.unit.Dp = 140.dp,
  onLongClick: (() -> Unit)? = null,
  isSelected: Boolean = false,
) {
  val imageUrl =
    remember(server.serverUrl, item.id, item.primaryImageTag, server.accessToken) {
      JellyfinClient.getImageUrl(
        serverUrl = server.serverUrl,
        itemId = item.id,
        imageTag = item.primaryImageTag,
        maxWidth = 400,
        token = server.accessToken,
      )
    }

  val posterBorderModifier =
    if (isSelected) {
      Modifier.clip(RoundedCornerShape(8.dp)).border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
    } else {
      Modifier.clip(RoundedCornerShape(8.dp))
    }

  Column(
    modifier = modifier.width(cardWidth),
  ) {
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .aspectRatio(1f)
          .tvFocusHighlight(RoundedCornerShape(8.dp), focusedScale = 1.03f)
          .then(posterBorderModifier)
          .background(MaterialTheme.colorScheme.surfaceContainerHighest)
          .tvContextMenu(onLongClick)
          .combinedClickable(
            onClick = onClick,
            onLongClick = onLongClick,
          ),
    ) {
      if (!item.primaryImageTag.isNullOrBlank()) {
        RemoteImage(
          url = imageUrl,
          contentDescription = item.name,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
      } else {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.RoundedFilled.Audiotrack,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(40.dp),
          )
        }
      }

      if (isSelected) {
        Surface(
          shape = CircleShape,
          color = MaterialTheme.colorScheme.primary,
          modifier =
            Modifier
              .padding(6.dp)
              .size(24.dp)
              .align(Alignment.BottomEnd),
        ) {
          Icon(
            imageVector = Icons.RoundedFilled.Check,
            contentDescription = "Selected",
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.padding(3.dp),
          )
        }
      }
    }

    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(top = 6.dp),
      horizontalAlignment = Alignment.Start,
    ) {
      Text(
        text = item.name,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Start,
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.fillMaxWidth(),
      )
      val isArtist = item.type == "MusicArtist" || item.type == "Artist" || item.type == "AlbumArtist"
      if (!isArtist) {
        val subtitle = item.seriesName ?: item.productionYear?.toString() ?: "Music"
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          textAlign = TextAlign.Start,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }
  }
}

// ============================================================================
// Library Filter Chips Row
// ============================================================================

@Composable
fun JellyfinLibraryChipRow(
  libraries: List<JellyfinItem>,
  selectedLibraryId: String?,
  onSelectLibrary: (String?) -> Unit,
  modifier: Modifier = Modifier,
) {
  if (libraries.isEmpty()) return

  Row(
    modifier =
      modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    FilterChip(
      selected = selectedLibraryId == null,
      onClick = { onSelectLibrary(null) },
      label = { Text("All", fontWeight = if (selectedLibraryId == null) FontWeight.Bold else FontWeight.Normal) },
      shape = RoundedCornerShape(12.dp),
      colors =
        FilterChipDefaults.filterChipColors(
          selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
          selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
        ),
    )

    libraries.forEach { library ->
      val isSelected = selectedLibraryId == library.id
      val colType = library.collectionType?.lowercase() ?: library.type.lowercase()
      val libName = library.name.lowercase()
      val icon =
        when {
          libName.contains("anime") || colType.contains("anime") -> Icons.RoundedFilled.Movie
          colType == "movies" || library.type.lowercase() == "movie" -> Icons.RoundedFilled.Movie
          colType == "tvshows" || library.type.lowercase() == "series" -> Icons.RoundedFilled.Tv
          colType == "music" || library.type.lowercase() == "audio" -> Icons.RoundedFilled.Audiotrack
          else -> Icons.RoundedFilled.Folder
        }

      FilterChip(
        selected = isSelected,
        onClick = { onSelectLibrary(if (isSelected) null else library.id) },
        leadingIcon = {
          Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
          )
        },
        label = { Text(library.name, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
        shape = RoundedCornerShape(12.dp),
        colors =
          FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
          ),
      )
    }
  }
}

@Composable
fun JellyfinGenreChipRow(
  genres: List<String>,
  selectedGenre: String?,
  onSelectGenre: (String?) -> Unit,
  modifier: Modifier = Modifier,
) {
  if (genres.isEmpty()) return

  Row(
    modifier =
      modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    FilterChip(
      selected = selectedGenre == null,
      onClick = { onSelectGenre(null) },
      label = { Text("All", fontWeight = if (selectedGenre == null) FontWeight.Bold else FontWeight.Normal) },
      shape = RoundedCornerShape(12.dp),
      colors =
        FilterChipDefaults.filterChipColors(
          selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
          selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
        ),
    )

    genres.forEach { genre ->
      val isSelected = selectedGenre == genre
      FilterChip(
        selected = isSelected,
        onClick = { onSelectGenre(if (isSelected) null else genre) },
        label = { Text(genre, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
        shape = RoundedCornerShape(12.dp),
        colors =
          FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
          ),
      )
    }
  }
}

// ============================================================================
// Library Card (Directory Card)
// ============================================================================

@Composable
fun JellyfinLibraryCard(
  item: JellyfinItem,
  server: JellyfinServer,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  cardWidth: androidx.compose.ui.unit.Dp = 220.dp,
) {
  val imageUrl =
    remember(server.serverUrl, item.id, item.primaryImageTag, item.backdropImageTag, server.accessToken) {
      if (!item.primaryImageTag.isNullOrBlank()) {
        JellyfinClient.getImageUrl(
          serverUrl = server.serverUrl,
          itemId = item.id,
          imageTag = item.primaryImageTag,
          maxWidth = 800,
          token = server.accessToken,
        )
      } else if (!item.backdropImageTag.isNullOrBlank()) {
        JellyfinClient.getBackdropUrl(
          serverUrl = server.serverUrl,
          itemId = item.id,
          imageTag = item.backdropImageTag,
          maxWidth = 1000,
          token = server.accessToken,
        )
      } else {
        JellyfinClient.getImageUrl(
          serverUrl = server.serverUrl,
          itemId = item.id,
          imageTag = null,
          maxWidth = 800,
          token = server.accessToken,
        )
      }
    }

  val colType = item.collectionType?.lowercase() ?: item.type.lowercase()
  val itemName = item.name.lowercase()
  val icon =
    when {
      itemName.contains("anime") || colType.contains("anime") -> Icons.RoundedFilled.Movie
      colType == "movies" || item.type.lowercase() == "movie" -> Icons.RoundedFilled.Movie
      colType == "tvshows" || item.type.lowercase() == "series" -> Icons.RoundedFilled.Tv
      colType == "music" || item.type.lowercase() == "audio" -> Icons.RoundedFilled.Audiotrack
      else -> Icons.RoundedFilled.Folder
    }

  Column(
    modifier =
      modifier
        .width(cardWidth)
        .clickable(onClick = onClick),
  ) {
    Card(
      modifier =
        Modifier
          .fillMaxWidth()
          .aspectRatio(16f / 9f)
          .tvFocusHighlight(RoundedCornerShape(10.dp), focusedScale = 1.03f)
          .clip(RoundedCornerShape(10.dp)),
      shape = RoundedCornerShape(10.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHighest),
    ) {
      Box(modifier = Modifier.fillMaxSize()) {
        if (!item.primaryImageTag.isNullOrBlank() || !item.backdropImageTag.isNullOrBlank()) {
          RemoteImage(
            url = imageUrl,
            contentDescription = item.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
          )
        } else {
          Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = icon,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(40.dp),
            )
          }
        }

        Surface(
          shape = RoundedCornerShape(6.dp),
          color = Color.Black.copy(alpha = 0.65f),
          modifier =
            Modifier
              .padding(8.dp)
              .align(Alignment.BottomEnd),
        ) {
          Box(
            modifier = Modifier.padding(5.dp),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = icon,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(15.dp),
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = item.name,
      style = MaterialTheme.typography.labelMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

// ============================================================================
// Episode Card (For Series Episodes View)
// ============================================================================

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun JellyfinEpisodeCard(
  item: JellyfinItem,
  server: JellyfinServer,
  onPlay: () -> Unit,
  modifier: Modifier = Modifier,
  onLongClick: (() -> Unit)? = null,
  isSelected: Boolean = false,
  downloadState: EpisodeDownloadState? = null,
  downloadProgress: Float? = null,
  onDownload: (() -> Unit)? = null,
  onCancelDownload: (() -> Unit)? = null,
) {
  val imageUrl =
    remember(server.serverUrl, item.id, item.primaryImageTag, server.accessToken) {
      JellyfinClient.getImageUrl(
        serverUrl = server.serverUrl,
        itemId = item.id,
        imageTag = item.primaryImageTag,
        maxWidth = 480,
        token = server.accessToken,
      )
    }

  val backgroundColor =
    if (isSelected) {
      MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
    } else {
      Color.Transparent
    }

  Surface(
    modifier =
      modifier
        .fillMaxWidth()
        .tvFocusHighlight(RoundedCornerShape(8.dp), focusedScale = 1.02f)
        .clip(RoundedCornerShape(8.dp))
        .tvContextMenu(onLongClick)
        .combinedClickable(
          onClick = onPlay,
          onLongClick = onLongClick,
        ),
    shape = RoundedCornerShape(8.dp),
    color = backgroundColor,
  ) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
      val thumbnailWidth = (maxWidth * 0.32f).coerceIn(80.dp, 140.dp)
      Row(
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Box(
          modifier =
            Modifier
              .width(thumbnailWidth)
              .aspectRatio(16f / 9f)
              .clip(RoundedCornerShape(8.dp))
              .background(MaterialTheme.colorScheme.surfaceContainerHighest),
        ) {
          if (!item.primaryImageTag.isNullOrBlank()) {
            RemoteImage(
              url = imageUrl,
              contentDescription = item.name,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
          } else {
            Box(
              modifier = Modifier.fillMaxSize(),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.RoundedFilled.PlayArrow,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(32.dp),
              )
            }
          }

          // Progress bar
          if (item.progressPercent > 0.02f && !item.isPlayed) {
            WatchProgressOverlayBar(
              progress = item.progressPercent,
              modifier =
                Modifier
                  .fillMaxWidth()
                  .align(Alignment.BottomCenter),
            )
          }

          if (isSelected) {
            Surface(
              shape = CircleShape,
              color = MaterialTheme.colorScheme.primary,
              modifier =
                Modifier
                  .padding(6.dp)
                  .size(22.dp)
                  .align(Alignment.TopEnd),
            ) {
              Icon(
                imageVector = Icons.RoundedFilled.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.padding(3.dp),
              )
            }
          } else if (item.isPlayed) {
            Surface(
              shape = CircleShape,
              color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
              modifier =
                Modifier
                  .padding(6.dp)
                  .size(18.dp)
                  .align(Alignment.TopEnd),
            ) {
              Icon(
                imageVector = Icons.RoundedFilled.Check,
                contentDescription = "Played",
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.padding(2.dp),
              )
            }
          }
        }

        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
          val epPrefix = if (item.indexNumber != null) "EPISODE ${item.indexNumber} • " else ""
          Text(
            text = "$epPrefix${item.name}",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
          )
          if (!item.overview.isNullOrBlank()) {
            Text(
              text = item.overview,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 3,
              overflow = TextOverflow.Ellipsis,
            )
          }
          val epMeta =
            run {
              val after = buildList {
                val dur = item.formattedDuration
                if (dur.isNotBlank()) add(dur)
              }
              buildStarSubtitle(emptyList(), item.communityRating, item.criticRating, after)
            }
          if (epMeta.isNotBlank()) {
            Text(
              text = epMeta,
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(top = 2.dp),
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            when (downloadState) {
              EpisodeDownloadState.NOT_DOWNLOADED ->
                IconButton(onClick = { onDownload?.invoke() }) {
                  Icon(
                    imageVector = Icons.RoundedFilled.Download,
                    contentDescription = stringResource(R.string.downloads_download),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(22.dp),
                  )
                }
              EpisodeDownloadState.ACTIVE ->
                IconButton(onClick = { onCancelDownload?.invoke() }) {
                  HotstarDownloadProgressCircle(
                    progress = downloadProgress ?: 0f,
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.5.dp,
                  )
                }
              EpisodeDownloadState.DOWNLOADED ->
                IconButton(onClick = {}) {
                  Icon(
                    imageVector = Icons.RoundedFilled.CheckCircle,
                    contentDescription = stringResource(R.string.downloads_downloaded),
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp),
                  )
                }
              null -> {}
            }

            IconButton(onClick = onPlay) {
              Icon(
                imageVector = Icons.RoundedFilled.PlayArrow,
                contentDescription = "Play",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(26.dp),
              )
            }
          }
        }
      }
    }
  }
}

/**
 * Hotstar-style clockwise circular download progress indicator.
 * Displays a subtle background track ring, a clockwise sweeping progress arc starting at 12 o'clock (-90°),
 * and a rounded stop square in the center.
 */
@Composable
fun HotstarDownloadProgressCircle(
  progress: Float,
  modifier: Modifier = Modifier,
  strokeWidth: Dp = 2.5.dp,
  trackColor: Color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.25f),
  progressColor: Color = MaterialTheme.colorScheme.primary,
  showStopSquare: Boolean = true,
) {
  val animatedProgress by animateFloatAsState(
    targetValue = progress.coerceIn(0f, 1f),
    animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
    label = "download_progress",
  )

  val infiniteTransition = rememberInfiniteTransition(label = "indeterminate_spin")
  val indeterminateRotation by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = LinearEasing),
      repeatMode = RepeatMode.Restart,
    ),
    label = "spin_angle",
  )

  Box(
    modifier = modifier,
    contentAlignment = Alignment.Center,
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val diameter = size.minDimension
      val strokePx = strokeWidth.toPx()
      val arcSize = Size(diameter - strokePx, diameter - strokePx)
      val topLeft = Offset(strokePx / 2f, strokePx / 2f)

      // 1. Subtle background track
      drawArc(
        color = trackColor,
        startAngle = 0f,
        sweepAngle = 360f,
        useCenter = false,
        topLeft = topLeft,
        size = arcSize,
        style = Stroke(width = strokePx, cap = StrokeCap.Round),
      )

      // 2. Clockwise progress fill starting at 12 o'clock (-90 degrees)
      if (progress > 0f) {
        val sweepAngle = (animatedProgress * 360f).coerceIn(4f, 360f)
        drawArc(
          color = progressColor,
          startAngle = -90f,
          sweepAngle = sweepAngle,
          useCenter = false,
          topLeft = topLeft,
          size = arcSize,
          style = Stroke(width = strokePx, cap = StrokeCap.Round),
        )
      } else {
        // Queued / initial state: smoothly spinning arc
        drawArc(
          color = progressColor,
          startAngle = -90f + indeterminateRotation,
          sweepAngle = 70f,
          useCenter = false,
          topLeft = topLeft,
          size = arcSize,
          style = Stroke(width = strokePx, cap = StrokeCap.Round),
        )
      }
    }

    if (showStopSquare) {
      val centerSquareSize = (strokeWidth * 2.4f).coerceAtLeast(6.dp).coerceAtMost(8.dp)
      Box(
        modifier = Modifier
          .size(centerSquareSize)
          .background(progressColor, shape = RoundedCornerShape(1.5.dp)),
      )
    }
  }
}

/** Download indicator shown at the trailing edge of an episode row. */
enum class EpisodeDownloadState {
  NOT_DOWNLOADED,
  ACTIVE,
  DOWNLOADED,
}

/** Small overlay badge marking items with a completed local download. */
@Composable
private fun DownloadedBadge(modifier: Modifier = Modifier) {
  Surface(
    shape = CircleShape,
    color = Color.Black.copy(alpha = 0.7f),
    modifier = modifier.size(20.dp),
  ) {
    Box(contentAlignment = Alignment.Center) {
      Icon(
        imageVector = Icons.RoundedFilled.Download,
        contentDescription = null,
        // Always-dark accent keeps the badge readable on the black scrim in light mode.
        tint = (LocalDarkAppColorScheme.current ?: MaterialTheme.colorScheme).primary,
        modifier = Modifier.size(13.dp),
      )
    }
  }
}

// ============================================================================
// List Item Card (List Mode in Browsing)
// ============================================================================

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun JellyfinListItemCard(
  item: JellyfinItem,
  server: JellyfinServer,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  onLongClick: (() -> Unit)? = null,
  isSelected: Boolean = false,
  isDownloaded: Boolean = false,
) {
  val imageUrl =
    remember(server.serverUrl, item.id, item.primaryImageTag, server.accessToken) {
      JellyfinClient.getImageUrl(
        serverUrl = server.serverUrl,
        itemId = item.id,
        imageTag = item.primaryImageTag,
        maxWidth = 300,
        token = server.accessToken,
      )
    }

  val backgroundColor =
    if (isSelected) {
      MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
    } else {
      Color.Transparent
    }

  Surface(
    modifier =
      modifier
        .fillMaxWidth()
        .tvFocusHighlight(RoundedCornerShape(8.dp), focusedScale = 1.02f)
        .clip(RoundedCornerShape(8.dp))
        .tvContextMenu(onLongClick)
        .combinedClickable(
          onClick = onClick,
          onLongClick = onLongClick,
        ),
    shape = RoundedCornerShape(8.dp),
    color = backgroundColor,
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Box(
        modifier =
          Modifier
            .size(width = 84.dp, height = 120.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHighest),
      ) {
        if (!item.primaryImageTag.isNullOrBlank()) {
          RemoteImage(
            url = imageUrl,
            contentDescription = item.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
          )
        } else {
          Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
          ) {
            val placeholderIcon =
              when {
                item.isAudio -> Icons.RoundedFilled.Audiotrack
                item.isFolder -> Icons.RoundedFilled.Folder
                item.isSeries -> Icons.RoundedFilled.Tv
                else -> Icons.RoundedFilled.Movie
              }
            Icon(
              imageVector = placeholderIcon,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(34.dp),
            )
          }
        }

        if (item.progressPercent > 0.02f && !item.isPlayed) {
          WatchProgressOverlayBar(
            progress = item.progressPercent,
            modifier =
              Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
          )
        }

        if (isDownloaded) {
          DownloadedBadge(modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp))
        }

        if (isSelected) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primary,
            modifier =
              Modifier
                .padding(6.dp)
                .size(22.dp)
                .align(Alignment.TopEnd),
          ) {
            Icon(
              imageVector = Icons.RoundedFilled.Check,
              contentDescription = "Selected",
              tint = MaterialTheme.colorScheme.onPrimary,
              modifier = Modifier.padding(3.dp),
            )
          }
        } else if (item.isPlayed) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
            modifier =
              Modifier
                .padding(6.dp)
                .size(18.dp)
                .align(Alignment.TopEnd),
          ) {
            Icon(
              imageVector = Icons.RoundedFilled.Check,
              contentDescription = "Played",
              tint = MaterialTheme.colorScheme.onPrimary,
              modifier = Modifier.padding(2.dp),
            )
          }
        }
      }

      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(5.dp),
      ) {
        Text(
          text = item.name,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        val details =
          run {
            val before = buildList {
              item.productionYear?.let { add(it.toString()) }
              if (item.isSeries && item.childCount != null) {
                add("${item.childCount} Seasons")
              } else if (item.productionYear == null) {
                add(item.type)
              }
            }
            val after = buildList {
              item.qualityBadge?.let { add(it) }
            }
            buildStarSubtitle(before, item.communityRating, item.criticRating, after)
          }

        Text(
          text = details,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )

        if (!item.overview.isNullOrBlank()) {
          Text(
            text = item.overview,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.outline,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      Icon(
        imageVector = Icons.RoundedFilled.ChevronRight,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(22.dp),
      )
    }
  }
}
