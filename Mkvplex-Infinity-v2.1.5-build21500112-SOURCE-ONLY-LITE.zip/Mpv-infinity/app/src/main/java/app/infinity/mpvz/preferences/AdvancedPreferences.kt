/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.preferences

import app.infinity.mpvz.BuildConfig
import app.infinity.mpvz.preferences.preference.PreferenceStore
import app.infinity.mpvz.preferences.preference.getEnum
import app.infinity.mpvz.ui.player.NotificationStyle

class AdvancedPreferences(
  preferenceStore: PreferenceStore,
) {
  val mpvConfStorageUri = preferenceStore.getString("mpv_conf_storage_location_uri")
  val mpvConf = preferenceStore.getString("mpv.conf")
  val inputConf = preferenceStore.getString("input.conf")
  val mpvConfOverrides = preferenceStore.getStringSet("mpv_conf_overrides", emptySet())

  val verboseLogging = preferenceStore.getBoolean("verbose_logging", BuildConfig.BUILD_TYPE != "release")

  val enabledStatisticsPage = preferenceStore.getInt("enabled_stats_page", 0)

  val enableRecentlyPlayed = preferenceStore.getBoolean("enable_recently_played", true)

  val enableLuaScripts = preferenceStore.getBoolean("enable_lua_scripts", false)
  val selectedLuaScripts = preferenceStore.getStringSet("selected_lua_scripts", emptySet())

  val enableP2pStreaming = preferenceStore.getBoolean("enable_p2p_streaming", true)

  // Checks are opt-in. Zero keeps all returned links; a positive limit caps retained candidates.
  val checkWorkingLinks = preferenceStore.getBoolean("jellyfin_check_working_links", false)
  val maxFetchedLinks = preferenceStore.getInt("jellyfin_max_fetched_links", 0)
  val maxCheckedLinks = preferenceStore.getInt("jellyfin_max_checked_links", 0)
  val autoSwitchFailedLinks = preferenceStore.getBoolean("jellyfin_auto_switch_failed_links", false)
  val showServerSearchProgress = preferenceStore.getBoolean("mkvplex_server_search_progress", false)
  val copyStreamLinks = preferenceStore.getBoolean("mkvplex_copy_stream_links", false)
  val castStreamLinks = preferenceStore.getBoolean("mkvplex_cast_stream_links", false)
  val showManualLinkChecks = preferenceStore.getBoolean("mkvplex_manual_link_checks", false)
  val showBufferingSpeed = preferenceStore.getBoolean("mkvplex_buffering_speed", false)
  val showDolbyVisionPopup = preferenceStore.getBoolean("mkvplex_dolby_vision_popup", false)
  val showDolbyAtmosPopup = preferenceStore.getBoolean("mkvplex_dolby_atmos_popup", false)

  val enableHlsProxy = preferenceStore.getBoolean("enable_hls_proxy", true)

  val enableSmartCollections = preferenceStore.getBoolean("enable_smart_collections", false)
  val enableWatchStatistics = preferenceStore.getBoolean("enable_watch_statistics", false)
  val enablePlaybackDiagnostics = preferenceStore.getBoolean("enable_playback_diagnostics", false)
  val enableLibraryHealthReport = preferenceStore.getBoolean("enable_library_health_report", false)
  val enableMediaQualityFilters = preferenceStore.getBoolean("enable_media_quality_filters", false)
  val enableLibraryActivityLog = preferenceStore.getBoolean("enable_library_activity_log", false)

  /** Notification style for the playback service (Media vs Progress-centric on Android 16+). */
  val notificationStyle = preferenceStore.getEnum("notification_style", NotificationStyle.Media)
}
