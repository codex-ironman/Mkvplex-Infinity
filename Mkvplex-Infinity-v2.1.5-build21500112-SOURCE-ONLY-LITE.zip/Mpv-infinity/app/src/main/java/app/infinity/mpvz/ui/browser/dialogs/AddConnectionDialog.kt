/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.ui.browser.dialogs

import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenu
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.infinity.mpvz.domain.network.NetworkConnection
import app.infinity.mpvz.domain.network.NetworkProtocol

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddConnectionSheet(
  isOpen: Boolean,
  onDismiss: () -> Unit,
  onSave: (NetworkConnection) -> Unit,
  modifier: Modifier = Modifier,
) {
  if (!isOpen) return

  var name by remember { mutableStateOf("") }
  var protocol by remember { mutableStateOf(NetworkProtocol.SMB) }
  var host by remember { mutableStateOf("") }
  var port by remember { mutableStateOf(protocol.defaultPort.toString()) }
  var username by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var path by remember { mutableStateOf("/") }
  var isAnonymous by remember { mutableStateOf(false) }
  var useHttps by remember { mutableStateOf(false) }
  var sftpHostKeyFingerprint by remember { mutableStateOf("") }
  var protocolMenuExpanded by remember { mutableStateOf(false) }
  val validSftpFingerprint = sftpHostKeyFingerprint.trim().matches(Regex("""SHA256:[A-Za-z0-9+/]{43}"""))

  val handleDismiss = {
    onDismiss()
  }

  val handleSave = {
    val connection =
      NetworkConnection(
        name = name.ifBlank { "${protocol.displayName} - $host" },
        protocol = protocol,
        host = host.trim(),
        port = port.toIntOrNull() ?: protocol.defaultPort,
        username = if (isAnonymous) "" else username.trim(),
        password = if (isAnonymous) "" else password,
        path = path.ifBlank { "/" },
        isAnonymous = isAnonymous,
        useHttps = useHttps,
        sftpHostKeyFingerprint = sftpHostKeyFingerprint.trim(),
      )
    onSave(connection)
  }
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  ModalBottomSheet(
    onDismissRequest = handleDismiss,
    sheetState = sheetState,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
    dragHandle = { BottomSheetDefaults.DragHandle() },
  ) {
    Column(
      modifier = modifier.fillMaxWidth().imePadding().navigationBarsPadding(),
    ) {
      Column(
        modifier =
          Modifier
            .widthIn(max = 640.dp)
            .align(Alignment.CenterHorizontally)
            .padding(horizontal = 24.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
      Text(
        text =
          androidx.compose.ui.res
            .stringResource(app.infinity.mpvz.R.string.ui_add_network_connection),
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Medium,
      )
      Column(
        modifier =
          Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        // Name and Protocol in one row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          // Connection Name
          OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_name),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            },
            modifier = Modifier.weight(0.50f),
            singleLine = true,
          )

          // Protocol Dropdown
          ExposedDropdownMenuBox(
            expanded = protocolMenuExpanded,
            onExpandedChange = { protocolMenuExpanded = it },
            modifier = Modifier.weight(0.50f),
          ) {
            OutlinedTextField(
              value = protocol.displayName,
              onValueChange = { },
              readOnly = true,
              label = {
                Text(
                  androidx.compose.ui.res
                    .stringResource(app.infinity.mpvz.R.string.ui_protocol),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = protocolMenuExpanded) },
              modifier =
                Modifier
                  .fillMaxWidth()
                  .menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable),
            )
            ExposedDropdownMenu(
              expanded = protocolMenuExpanded,
              onDismissRequest = { protocolMenuExpanded = false },
            ) {
              NetworkProtocol.entries.forEach { proto ->
                DropdownMenuItem(
                  text = { Text(proto.displayName) },
                  onClick = {
                    protocol = proto
                    port = proto.defaultPort.toString()
                    protocolMenuExpanded = false
                  },
                )
              }
            }
          }
        }

        // Host
        OutlinedTextField(
          value = host,
          onValueChange = { host = it },
          label = {
            Text(
              androidx.compose.ui.res
                .stringResource(app.infinity.mpvz.R.string.ui_host_ip_address),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
          placeholder = { Text("192.168.1.100", maxLines = 1, overflow = TextOverflow.Ellipsis) },
        )

        // Port and Path in one row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          // Port
          OutlinedTextField(
            value = port,
            onValueChange = { port = it },
            label = {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_port),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            },
            modifier = Modifier.weight(0.3f),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          )

          // Path
          OutlinedTextField(
            value = path,
            onValueChange = { path = it },
            label = {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_path),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            },
            modifier = Modifier.weight(0.7f),
            singleLine = true,
            placeholder = { Text("/", maxLines = 1, overflow = TextOverflow.Ellipsis) },
          )
        }

        if (protocol == NetworkProtocol.SFTP) {
          OutlinedTextField(
            value = sftpHostKeyFingerprint,
            onValueChange = { sftpHostKeyFingerprint = it.trim() },
            label = { Text("SFTP host-key SHA-256 fingerprint") },
            placeholder = { Text("SHA256:...") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            supportingText = { Text("Verify this fingerprint with the server administrator before saving.") },
          )
        }

        // Anonymous and HTTPS checkboxes
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Checkbox(
            checked = isAnonymous,
            onCheckedChange = { isAnonymous = it },
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            androidx.compose.ui.res
              .stringResource(app.infinity.mpvz.R.string.ui_anonymous_guest_access),
          )
        }

        // HTTPS checkbox (only for WebDAV)
        if (protocol == NetworkProtocol.WEBDAV) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Checkbox(
              checked = useHttps,
              onCheckedChange = {
                useHttps = it
                // Auto-update port when toggling HTTPS
                if (it && port == "80") {
                  port = "443"
                } else if (!it && port == "443") {
                  port = "80"
                }
              },
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              androidx.compose.ui.res
                .stringResource(app.infinity.mpvz.R.string.ui_use_https_secure_connection),
            )
          }
        }

        // Username and Password in one row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          // Username
          OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_username),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            },
            modifier = Modifier.weight(0.50f),
            singleLine = true,
            enabled = !isAnonymous,
          )

          // Password
          OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_password),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            },
            modifier = Modifier.weight(0.50f),
            singleLine = true,
            enabled = !isAnonymous,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
          )
        }
      }
        Row(
          modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
          horizontalArrangement = Arrangement.End,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          TextButton(onClick = handleDismiss) {
            Text(
              text =
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.generic_cancel),
              fontWeight = FontWeight.Medium,
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = handleSave,
            enabled =
              host.isNotBlank() &&
                (isAnonymous || username.isNotBlank()) &&
                (protocol != NetworkProtocol.SFTP || validSftpFingerprint),
          ) {
            Text(
              text =
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_save),
              fontWeight = FontWeight.SemiBold,
            )
          }
        }
      }
    }
  }
}
