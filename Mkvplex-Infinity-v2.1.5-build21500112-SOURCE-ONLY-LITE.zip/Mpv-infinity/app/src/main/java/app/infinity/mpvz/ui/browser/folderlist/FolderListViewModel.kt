/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.ui.browser.folderlist

import android.app.Application
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import app.infinity.mpvz.domain.media.model.VideoFolder
import app.infinity.mpvz.domain.playbackstate.repository.PlaybackStateRepository
import app.infinity.mpvz.database.entities.PlaybackStateEntity
import app.infinity.mpvz.preferences.AppearancePreferences
import app.infinity.mpvz.preferences.FoldersPreferences
import app.infinity.mpvz.repository.MediaFileRepository
import app.infinity.mpvz.ui.browser.base.BaseBrowserViewModel
import app.infinity.mpvz.ui.player.PlaybackIdentity
import app.infinity.mpvz.utils.media.MediaLibraryEvents
import app.infinity.mpvz.utils.media.MetadataRetrieval
import app.infinity.mpvz.utils.media.PlaybackStateEvents
import app.infinity.mpvz.utils.permission.PermissionUtils.StorageOps
import app.infinity.mpvz.utils.storage.FolderViewScanner
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.util.Locale

data class FolderWithNewCount(
  val folder: VideoFolder,
  val newVideoCount: Int = 0,
)

class FolderListViewModel(
  application: Application,
  private val audioOnly: Boolean = false,
  private val rootPath: String? = null,
) : BaseBrowserViewModel(application),
  KoinComponent {
  private val foldersPreferences: FoldersPreferences by inject()
  private val appearancePreferences: AppearancePreferences by inject()
  private val browserPreferences: app.infinity.mpvz.preferences.BrowserPreferences by inject()
  private val playbackStateRepository: PlaybackStateRepository by inject()

  private val _allVideoFolders = MutableStateFlow<List<VideoFolder>>(emptyList())
  private val _videoFolders = MutableStateFlow<List<VideoFolder>>(emptyList())
  val videoFolders: StateFlow<List<VideoFolder>> = _videoFolders.asStateFlow()

  private val _foldersWithNewCount = MutableStateFlow<List<FolderWithNewCount>>(emptyList())
  val foldersWithNewCount: StateFlow<List<FolderWithNewCount>> = _foldersWithNewCount.asStateFlow()
  private val folderWatchedOverrides = MutableStateFlow<Map<String, Boolean>>(loadFolderWatchedOverrides())

  // Only show loading on fresh install (when there's no cached data)
  private val _isLoading = MutableStateFlow(false)
  val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

  // Track if initial load has completed to prevent empty state flicker
  private val _hasCompletedInitialLoad = MutableStateFlow(false)
  val hasCompletedInitialLoad: StateFlow<Boolean> = _hasCompletedInitialLoad.asStateFlow()

  // Track if folders were deleted leaving list empty
  private val _foldersWereDeleted = MutableStateFlow(false)
  val foldersWereDeleted: StateFlow<Boolean> = _foldersWereDeleted.asStateFlow()

  // Track previous folder count to detect if all folders were deleted
  private var previousFolderCount = 0

  /*
   * TRACKING LOADING STATE
   */
  private val _scanStatus = MutableStateFlow<String?>(null)
  val scanStatus: StateFlow<String?> = _scanStatus.asStateFlow()

  private val _isEnriching = MutableStateFlow(false)
  val isEnriching: StateFlow<Boolean> = _isEnriching.asStateFlow()

  // Track the current scan job to prevent concurrent scans
  private var currentScanJob: Job? = null
  // The newest manual refresh wins. This prevents rapid gestures or repeated taps from starting
  // competing MediaStore/provider scans and emitting stale lists while Compose is animating.
  private var refreshJob: Job? = null
  private var newCountJob: Job? = null
  private var cacheWriteJob: Job? = null
  private var newCountGeneration = 0L

    companion object {
    private const val TAG = "FolderListViewModel"
    private const val MEDIA_LIBRARY_REFRESH_DEBOUNCE_MS = 750L

    fun factory(
      application: Application,
      audioOnly: Boolean = false,
      rootPath: String? = null,
    ) = object : ViewModelProvider.Factory {
      @Suppress("UNCHECKED_CAST")
      override fun <T : ViewModel> create(modelClass: Class<T>): T = FolderListViewModel(application, audioOnly, rootPath) as T
    }
  }

  private fun loadFolderWatchedOverrides(): Map<String, Boolean> {
    val stored =
      getApplication<Application>()
        .getSharedPreferences("folder_watched_overrides", android.content.Context.MODE_PRIVATE)
        .getStringSet("values", emptySet<String>())
        ?: emptySet<String>()
    return stored.mapNotNull { value ->
      val split = value.split("\u001f", limit = 2)
      if (split.size == 2) split[0] to (split[1] == "1") else null
    }.toMap()
  }

  private fun saveFolderWatchedOverrides(values: Map<String, Boolean>) {
    val encoded = values.map { (key, watched) -> key + "\u001f" + if (watched) "1" else "0" }.toSet()
    getApplication<Application>()
      .getSharedPreferences("folder_watched_overrides", android.content.Context.MODE_PRIVATE)
      .edit().putStringSet("values", encoded).apply()
  }

  init {
    // Load cached folders instantly for immediate display
    val hasCachedData = loadCachedFolders()

    // If no cached data (first launch), scan immediately. Otherwise defer to not slow down app launch
    if (!hasCachedData) {
      loadVideoFolders()
    } else {
      viewModelScope.launch(Dispatchers.IO) {
        kotlinx.coroutines.delay(2000) // Wait 2 seconds before refreshing
        loadVideoFolders()
      }
    }

    // Refresh on media events and every preference that changes scan/index semantics. Settings UI
    // may emit both; collectLatest plus the debounce collapses them into one refresh.
    viewModelScope.launch(Dispatchers.IO) {
      val scanPreferenceChanges =
        combine(
          foldersPreferences.includeNoMediaFolders.changes(),
          foldersPreferences.hiddenFolderMarkerNames.changes(),
          browserPreferences.includeAudioBrowser.changes(),
          browserPreferences.minimumAudioDurationSeconds.changes(),
        ) { _, _, _, _ -> Unit }
          .drop(1)

      merge(MediaLibraryEvents.changes, scanPreferenceChanges).collectLatest {
        delay(MEDIA_LIBRARY_REFRESH_DEBOUNCE_MS)
        // A media event affects the MediaStore snapshot, not the tree cache or persisted
        // .nomedia fingerprints. Known hidden roots will be checked incrementally below.
        MediaFileRepository.invalidateFolderCache()
        loadVideoFolders()
      }
    }

    // Filter folders based on blacklist (video vs audio scope)
    val blacklistFlow = if (audioOnly) {
      foldersPreferences.blacklistedAudioFolders.changes()
    } else {
      foldersPreferences.blacklistedFolders.changes()
    }

    viewModelScope.launch {
      combine(_allVideoFolders, blacklistFlow) { folders, blacklist ->
        folders.filter { folder ->
          (rootPath.isNullOrBlank() || folder.path.equals(rootPath, ignoreCase = true) ||
            folder.path.startsWith(rootPath.trimEnd('/') + "/", ignoreCase = true)) &&
          blacklist.none { blacklisted ->
            folder.path.equals(blacklisted, ignoreCase = true) ||
              folder.path.startsWith(if (blacklisted.endsWith("/")) blacklisted else "$blacklisted/", ignoreCase = true)
          }
        }
      }.collectLatest { filteredFolders ->
        // Check if folders became empty after having folders
        if (previousFolderCount > 0 && filteredFolders.isEmpty()) {
          _foldersWereDeleted.value = true
          Log.d(TAG, "Folders became empty (had $previousFolderCount folders before)")
        } else if (filteredFolders.isNotEmpty()) {
          // Reset flag if folders now exist
          _foldersWereDeleted.value = false
        }

        // Update previous count
        previousFolderCount = filteredFolders.size

        _videoFolders.value = filteredFolders
        // Calculate new video counts for each folder
        calculateNewVideoCounts(filteredFolders)

        // Save to cache for next app launch (save unfiltered list)
        saveFoldersToCache(_allVideoFolders.value)
      }
    }
  }

  private fun loadCachedFolders(): Boolean {
    var hasCachedData = false
    val prefs =
      getApplication<Application>().getSharedPreferences("folder_cache", android.content.Context.MODE_PRIVATE)
    val cachedJson = prefs.getString(currentFolderCacheKey(), null)

    if (cachedJson != null) {
      try {
        // Parse JSON and restore folders
        val folders = parseFoldersFromJson(cachedJson)
        if (folders.isNotEmpty()) {
          Log.d(TAG, "Loaded ${folders.size} folders from cache instantly")
          hasCachedData = true
          viewModelScope.launch(Dispatchers.IO) {
            _allVideoFolders.value = folders
            _hasCompletedInitialLoad.value = true
          }
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error loading cached folders", e)
      }
    }

    return hasCachedData
  }

  private fun saveFoldersToCache(folders: List<VideoFolder>) {
    cacheWriteJob?.cancel()
    cacheWriteJob =
      viewModelScope.launch(Dispatchers.IO) {
        delay(750)
        try {
          val prefs =
            getApplication<Application>().getSharedPreferences("folder_cache", android.content.Context.MODE_PRIVATE)
          val json = serializeFoldersToJson(folders)
          prefs.edit().putString(currentFolderCacheKey(), json).apply()
          Log.d(TAG, "Saved ${folders.size} folders to cache")
        } catch (e: Exception) {
          Log.e(TAG, "Error saving folders to cache", e)
        }
      }
  }

  private fun currentFolderCacheKey(): String =
    "folders_${if (audioOnly) "audioOnly" else "video"}" +
      "_${if (foldersPreferences.includeNoMediaFolders.get()) "with_nomedia" else "exclude_nomedia"}" +
      "_audio_${browserPreferences.includeAudioBrowser.get()}_${browserPreferences.minimumAudioDurationSeconds.get()}"

  private fun serializeFoldersToJson(folders: List<VideoFolder>): String {
    // Simple JSON serialization
    return folders.joinToString(separator = "|") { folder ->
      "${folder.bucketId}::${folder.name}::${folder.path}::${folder.videoCount}::${folder.totalSize}::${folder.totalDuration}::${folder.lastModified}"
    }
  }

  private fun parseFoldersFromJson(json: String): List<VideoFolder> =
    try {
      json.split("|").mapNotNull { item ->
        val parts = item.split("::")
        if (parts.size == 7) {
          VideoFolder(
            bucketId = parts[0],
            name = parts[1],
            path = parts[2],
            videoCount = parts[3].toIntOrNull() ?: 0,
            totalSize = parts[4].toLongOrNull() ?: 0L,
            totalDuration = parts[5].toLongOrNull() ?: 0L,
            lastModified = parts[6].toLongOrNull() ?: 0L,
          )
        } else {
          null
        }
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error parsing cached folders", e)
      emptyList()
    }

  private fun calculateNewVideoCounts(folders: List<VideoFolder>) {
    newCountJob?.cancel()
    val generation = ++newCountGeneration
    newCountJob =
      viewModelScope.launch(Dispatchers.IO) {
        delay(400)
        try {
          val showLabel = appearancePreferences.showUnplayedOldVideoLabel.get()
          if (!showLabel) {
            // If feature is disabled, just return folders with 0 count
            if (generation == newCountGeneration) {
              _foldersWithNewCount.value = folders.map { FolderWithNewCount(it, 0) }
            }
            return@launch
          }

          val thresholdDays = appearancePreferences.unplayedOldVideoDays.get()
          val thresholdMillis = thresholdDays * 24 * 60 * 60 * 1000L
          val watchedThreshold = browserPreferences.watchedThreshold.get()
          val currentTime = System.currentTimeMillis()

          val foldersWithCounts =
            folders.map { folder ->
              try {
                // Get all videos in this folder
                val videos =
                  app.infinity.mpvz.repository.MediaFileRepository
                    .getVideosInFolder(getApplication(), folder.bucketId)

                // Count new unplayed videos. A watched folder is the default state, but an
                // explicit child swipe-to-unwatched must override that default for the folder
                // badge as well.
                val watchedOverride = folderWatchedOverrides.value[folder.bucketId]
                val newCount =
                  if (watchedOverride == true) {
                    videos.count { video ->
                      val durationSeconds = video.duration / 1000L
                      val explicitOverride =
                        getApplication<Application>()
                          .getSharedPreferences("video_watched_overrides", android.content.Context.MODE_PRIVATE)
                          .getStringSet("values", emptySet())
                          ?.contains("${video.path}\u001f0") == true
                      val playbackState = playbackStateRepository.getVideoDataByTitle(PlaybackIdentity.forLocalPath(video.path))
                        ?: playbackStateRepository.getVideoDataByTitle(PlaybackIdentity.forUri(video.uri.toString()))
                        ?: playbackStateRepository.getVideoDataByTitle(PlaybackIdentity.forUri(video.path))
                        ?: playbackStateRepository.getVideoDataByTitle(PlaybackIdentity.forUri("file://${video.path}"))
                      explicitOverride || (
                        playbackState != null &&
                          !playbackState.hasBeenWatched &&
                          playbackState.lastPosition <= 0 &&
                          playbackState.timeRemaining >= durationSeconds - 1
                      )
                    }
                  } else if (watchedOverride == false) {
                    videos.count { video ->
                      // An unwatched folder makes children NEW by default, but an explicit
                      // child swipe-to-watched must remove that child from the folder badge.
                      getApplication<Application>()
                        .getSharedPreferences("video_watched_overrides", android.content.Context.MODE_PRIVATE)
                        .getStringSet("values", emptySet())
                        ?.contains("${video.path}\u001f1") != true
                    }
                  } else {
                  videos.count { video ->
                    // Check if video was modified within threshold days unless the user
                    // explicitly marked the whole folder as unwatched.
                    val videoAge = currentTime - (video.dateModified * 1000)
                    val isRecent = videoAge <= thresholdMillis

                    // A video counts as "unplayed" until it has been watched to the
                    // configured threshold. Threshold 0 ("Infinitely") keeps it unplayed.
                    val playbackState = playbackStateRepository.getVideoDataByTitle(PlaybackIdentity.forLocalPath(video.path))
                      ?: playbackStateRepository.getVideoDataByTitle(PlaybackIdentity.forUri(video.uri.toString()))
                      ?: playbackStateRepository.getVideoDataByTitle(PlaybackIdentity.forUri(video.path))
                      ?: playbackStateRepository.getVideoDataByTitle(PlaybackIdentity.forUri("file://${video.path}"))
                    val explicitlyUnwatched =
                      getApplication<Application>()
                        .getSharedPreferences("video_watched_overrides", android.content.Context.MODE_PRIVATE)
                        .getStringSet("values", emptySet())
                        ?.contains("${video.path}\u001f0") == true
                    val isUnplayed =
                      explicitlyUnwatched || if (playbackState != null && video.duration > 0) {
                        val durationSeconds = video.duration / 1000
                        val watched = durationSeconds - playbackState.timeRemaining.toLong()
                        val progressValue =
                          (watched.toFloat() / durationSeconds.toFloat()).coerceIn(0f, 1f)
                        watchedThreshold <= 0 || progressValue < (watchedThreshold / 100f)
                      } else {
                        playbackState == null
                      }

                    if (watchedOverride == false) true else explicitlyUnwatched || (isRecent && isUnplayed)
                  }
                }

                FolderWithNewCount(folder, newCount)
              } catch (e: CancellationException) {
                throw e
              } catch (e: Exception) {
                Log.e(TAG, "Error counting new videos for folder ${folder.name}", e)
                FolderWithNewCount(folder, 0)
              }
            }

          if (generation == newCountGeneration) {
            _foldersWithNewCount.value = foldersWithCounts
          }
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          Log.e(TAG, "Error calculating new video counts", e)
          if (generation == newCountGeneration) {
            _foldersWithNewCount.value = folders.map { FolderWithNewCount(it, 0) }
          }
        }
      }
  }

  override fun refresh() {
    Log.d(TAG, "Hard refreshing folder list")

    // Set loading state
    _isLoading.value = true
    refreshJob?.cancel()

    // Cache invalidation and the root MediaStore scan both cross into Android's content-provider
    // service. Keep the complete refresh behavior, but never run those calls on the Compose/UI
    // thread; a slow provider transaction can otherwise stall the renderer.
    refreshJob = viewModelScope.launch(Dispatchers.IO) {
      // Clear all caches to force fresh data from filesystem
      MediaFileRepository.clearCache()
      FolderViewScanner.clearCache()

      // Force the direct hidden index first; MediaScanner cannot see .nomedia trees.
      loadVideoFolders(forceFileSystemCheck = true)

      // Preserve full Refresh semantics for ordinary files copied by other apps. Completion emits
      // a debounced MediaLibraryEvents update, while this asynchronous pass never blocks the UI.
      triggerMediaScan()
    }
  }

  private fun triggerMediaScan() {
    try {
      val externalStorage = android.os.Environment.getExternalStorageDirectory()
      android.media.MediaScannerConnection.scanFile(
        getApplication(),
        arrayOf(externalStorage.absolutePath),
        null,
      ) { path, uri ->
        Log.d(TAG, "Media scan completed for: $path -> $uri")
      }
    } catch (error: Exception) {
      Log.e(TAG, "Failed to trigger media scan", error)
    }
  }

  /**
   * Recalculate new video counts without refreshing the entire folder list
   * Useful when returning to the screen after playing videos
   */
  fun recalculateNewVideoCounts() {
    calculateNewVideoCounts(_videoFolders.value)
  }

  fun setFolderWatched(folder: VideoFolder, watched: Boolean) {
    newCountGeneration++
    val updatedOverrides = folderWatchedOverrides.value + (folder.bucketId to watched)
    folderWatchedOverrides.value = updatedOverrides
    saveFolderWatchedOverrides(updatedOverrides)
    newCountJob?.cancel()
    _foldersWithNewCount.value =
      _foldersWithNewCount.value.map { entry ->
        if (entry.folder.bucketId == folder.bucketId) {
          entry.copy(newVideoCount = if (watched) 0 else folder.videoCount)
        } else {
          entry
        }
      }
    viewModelScope.launch(Dispatchers.IO) {
      val videos = MediaFileRepository.getVideosInFolder(getApplication(), folder.bucketId)
      val videoOverrides =
        getApplication<Application>()
          .getSharedPreferences("video_watched_overrides", android.content.Context.MODE_PRIVATE)
      val overrideValues = videoOverrides.getStringSet("values", emptySet())?.toMutableSet() ?: mutableSetOf()
      videos.forEach { video ->
        overrideValues.removeIf { it.startsWith("${video.path}\u001f") }
        if (!watched) {
          overrideValues.add("${video.path}\u001f0")
        }
      }
      videoOverrides.edit().putStringSet("values", overrideValues).apply()
      videos.forEach { video ->
        val durationSeconds = (video.duration / 1000L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        val identifier = PlaybackIdentity.forLocalPath(video.path)
        val existing = playbackStateRepository.getVideoDataByTitle(identifier)
        playbackStateRepository.upsert(
          (existing ?: PlaybackStateEntity(
            mediaTitle = identifier,
            lastPosition = 0,
            playbackSpeed = 1.0,
            sid = -1,
            secondarySid = -1,
            subDelay = 0,
            subSpeed = 1.0,
            aid = -1,
            audioDelay = 0,
            timeRemaining = durationSeconds,
            hasBeenWatched = false,
          )).copy(
            mediaTitle = identifier,
            lastPosition = if (watched) 0 else durationSeconds,
            timeRemaining = if (watched) 0 else durationSeconds,
            hasBeenWatched = watched,
          ),
        )
        PlaybackStateEvents.notifyChanged(identifier)
      }
      // A video screen can remain retained in Navigation3 while the folder screen is visible.
      // Notify it after the complete batch so it reloads the folder override and child NEW state.
      MediaLibraryEvents.notifyChanged()
    }
  }

  suspend fun renameFolder(
    folder: VideoFolder,
    newName: String,
  ): Boolean {
    val ok = StorageOps.renameFolder(getApplication(), folder.path, newName)
    if (ok) {
      _foldersWereDeleted.value = true
    }
    return ok
  }

  /** Publishes MediaStore immediately, then merges indexed .nomedia folders in the background. */
  private fun loadVideoFolders(forceFileSystemCheck: Boolean = false) {
    currentScanJob?.cancel()

    if (audioOnly) {
      currentScanJob =
        viewModelScope.launch(Dispatchers.IO) {
          try {
            _isLoading.value = _allVideoFolders.value.isEmpty()
            _scanStatus.value = "Reading music library..."
            val folders =
              MediaFileRepository.getAllAudioFolders(
                context = getApplication(),
                minimumAudioDurationSeconds = browserPreferences.minimumAudioDurationSeconds.get(),
              )
            _allVideoFolders.value = folders
            _isLoading.value = false
            _hasCompletedInitialLoad.value = true
          } catch (e: Exception) {
            Log.e(TAG, "Error loading audio folders", e)
            _hasCompletedInitialLoad.value = true
          } finally {
            _isLoading.value = false
            _isEnriching.value = false
            _scanStatus.value = null
          }
        }
      return
    }

    currentScanJob =
      viewModelScope.launch(Dispatchers.IO) {
        try {
          val hasExistingData = _allVideoFolders.value.isNotEmpty()
          if (!hasExistingData) {
            _isLoading.value = true
            _scanStatus.value = "Reading media library..."
          }

          val previousFolders = _allVideoFolders.value.associateBy(::folderKey)
          val mediaStoreFolders =
            MediaFileRepository.getAllVideoFoldersFast(
              context = getApplication(),
              onProgress = { count ->
                if (!hasExistingData) _scanStatus.value = "Found $count folders"
              },
              forceFileSystemCheck = forceFileSystemCheck,
              includeAudioOverride = browserPreferences.includeAudioBrowser.get(),
            )
          // This is the important latency boundary: never wait for a filesystem walk.
          _allVideoFolders.value = mediaStoreFolders
          _isLoading.value = false
          _hasCompletedInitialLoad.value = true

          val indexedFolders = MediaFileRepository.getIndexedNoMediaFolders()
          var visibleFolders = mergeFolders(mediaStoreFolders, indexedFolders)
          _allVideoFolders.value = visibleFolders
          Log.d(TAG, "Published ${mediaStoreFolders.size} MediaStore and ${indexedFolders.size} indexed folders")

          if (foldersPreferences.includeNoMediaFolders.get()) {
            _scanStatus.value =
              if (forceFileSystemCheck || indexedFolders.isEmpty()) {
                "Discovering hidden folders..."
              } else {
                "Checking hidden folders..."
              }
            MediaFileRepository
              .scanNoMediaFoldersIncrementally(
                context = getApplication(),
                forceDiscovery = forceFileSystemCheck,
              ).collect { batch ->
                visibleFolders = mergeFolders(visibleFolders, batch)
                _allVideoFolders.value = visibleFolders
                _scanStatus.value = "Found ${visibleFolders.size} folders"
              }

            // Replace the old indexed snapshot after the scan, removing deleted/stale folders.
            visibleFolders = mergeFolders(mediaStoreFolders, MediaFileRepository.getIndexedNoMediaFolders())
            _allVideoFolders.value = visibleFolders
          }

          if (visibleFolders.isEmpty()) return@launch

          var needsEnrichment = false
          val foldersForEnrichment =
            visibleFolders.map { folder ->
              val cached = previousFolders[folderKey(folder)]
              val cachedIsComplete = cached != null && (cached.videoCount == 0 || cached.totalDuration > 0)
              if (cached != null &&
                cached.videoCount == folder.videoCount &&
                cached.lastModified == folder.lastModified &&
                cachedIsComplete
              ) {
                cached
              } else {
                needsEnrichment = true
                folder
              }
            }
          _allVideoFolders.value = foldersForEnrichment

          val needsDurationEnrichment = needsEnrichment && MetadataRetrieval.isFolderMetadataNeeded(browserPreferences)
          if (!needsDurationEnrichment) return@launch

          _isEnriching.value = true
          _scanStatus.value = "Processing metadata..."
          val enrichedFolders =
            MetadataRetrieval.enrichFoldersIfNeeded(
              context = getApplication(),
              folders = foldersForEnrichment,
              browserPreferences = browserPreferences,
              metadataCache = metadataCache,
              onProgress = { processed, total ->
                _scanStatus.value = "Processing metadata $processed/$total"
              },
            )

          _allVideoFolders.value = enrichedFolders
        } catch (e: kotlinx.coroutines.CancellationException) {
          Log.d(TAG, "Scan cancelled (new scan started)")
          throw e
        } catch (e: Exception) {
          Log.e(TAG, "Error loading video folders", e)
          _hasCompletedInitialLoad.value = true
        } finally {
          _isLoading.value = false
          _isEnriching.value = false
          _scanStatus.value = null
        }
      }
  }

  private fun folderKey(folder: VideoFolder): String =
    folder.path
      .replace('\\', '/')
      .trimEnd('/')
      .lowercase(Locale.ROOT)

  private fun mergeFolders(vararg groups: List<VideoFolder>): List<VideoFolder> {
    val merged = linkedMapOf<String, VideoFolder>()
    groups.forEach { folders -> folders.forEach { folder -> merged[folderKey(folder)] = folder } }
    return merged.values.sortedBy { it.name.lowercase(Locale.getDefault()) }
  }
}
