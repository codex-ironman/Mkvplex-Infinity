/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.preferences

import androidx.annotation.StringRes
import app.infinity.mpvz.R
import app.infinity.mpvz.preferences.preference.PreferenceStore
import app.infinity.mpvz.preferences.preference.getEnum

class AudioPreferences(
  preferenceStore: PreferenceStore,
) {
  val preferredLanguages = preferenceStore.getString("audio_preferred_languages")
  val defaultAudioDelay = preferenceStore.getInt("audio_delay_default")
  val pickerPath = preferenceStore.getString("audio_picker_path")
  val audioPitchCorrection = preferenceStore.getBoolean("audio_pitch_correction", true)
  val audioChannels = preferenceStore.getEnum("audio_channels", AudioChannels.AutoSafe)
  val volumeBoostCap = preferenceStore.getInt("audio_volume_boost_cap", 30)
  val backgroundPlayback = preferenceStore.getBoolean("automatic_background_playback", false)
  /** Audio-player-only background playback; video retains [backgroundPlayback]. */
  val audioBackgroundPlayback = preferenceStore.getBoolean("audio_player_background_playback", false)
  val volumeNormalization = preferenceStore.getBoolean("audio_volume_normalization", false)
  val drcEnabled = preferenceStore.getBoolean("audio_drc_enabled", false)
  val showAudioVisualizer = preferenceStore.getBoolean("show_audio_visualizer", false)
  val audioVisualizerStyle = preferenceStore.getEnum("audio_visualizer_style", AudioVisualizerStyle.Blob)
  val audioOrientation = preferenceStore.getEnum("audio_player_orientation", AudioPlayerOrientation.Auto)
  val audioAmbientMode = preferenceStore.getBoolean("audio_ambient_mode", true)
  /** Use artwork-derived colors for the music player background instead of the app theme. */
  val audioPaletteBackground = preferenceStore.getBoolean("audio_palette_background", true)
  val audioStandbyMode = preferenceStore.getBoolean("audio_standby_mode", true)
  val audioStandbyDelaySeconds = preferenceStore.getInt("audio_standby_delay_seconds", 5)
  val audioWavySeekbar = preferenceStore.getBoolean("audio_wavy_seekbar", true)
  val enabledMusicTabs = preferenceStore.getStringSet(
    "enabled_music_tabs",
    setOf("SONGS", "ALBUMS", "ARTISTS", "PLAYLISTS", "FOLDERS"),
  )
  val musicTabOrder = preferenceStore.getObject(
    key = "music_tab_order",
    defaultValue = listOf("SONGS", "ALBUMS", "ARTISTS", "PLAYLISTS", "FOLDERS"),
    serializer = { list -> list.joinToString(",") },
    deserializer = { str ->
      val parsed = str.split(",").map { it.trim() }.filter { it.isNotEmpty() }
      val missing = listOf("SONGS", "ALBUMS", "ARTISTS", "PLAYLISTS", "FOLDERS") - parsed.toSet()
      parsed + missing
    },
  )

  val lyricsAutoTranslate = preferenceStore.getBoolean("lyrics_auto_translate", false)
  val lyricsTargetLanguage = preferenceStore.getString("lyrics_target_language", "en")
  val lyricsTranslationDisplayMode = preferenceStore.getEnum("lyrics_translation_display_mode", LyricsTranslationDisplayMode.DualLine)

  init {
    // Consolidate the old audio-only screen-lock switch into the single global setting.
    val legacyScreenLockPlayback = preferenceStore.getBoolean("play_audio_after_screen_lock", false)
    if (legacyScreenLockPlayback.get()) backgroundPlayback.set(true)
    if (legacyScreenLockPlayback.isSet()) legacyScreenLockPlayback.delete()
  }
}

enum class LyricsTranslationDisplayMode(
  @StringRes val title: Int,
) {
  DualLine(R.string.pref_lyrics_display_dual_line),
  Replace(R.string.pref_lyrics_display_replace),
}

enum class AudioPlayerOrientation(
  @StringRes val titleRes: Int,
) {
  Auto(R.string.pref_audio_channels_auto),
  Portrait(R.string.pref_player_orientation_portrait),
  Landscape(R.string.pref_player_orientation_landscape),
}

enum class AudioVisualizerStyle(
  @StringRes val title: Int,
) {
  Blob(R.string.pref_audio_visualizer_style_blob),
  Galaxy(R.string.pref_audio_visualizer_style_galaxy),
  Cuboid(R.string.pref_audio_visualizer_style_cuboid),
  Particle(R.string.pref_audio_visualizer_style_particle),
}


enum class AudioChannels(
  @StringRes val title: Int,
  val property: String,
  val value: String,
) {
  /** Let mpv prefer the source layout when the output device reports that it is supported. */
  Auto(R.string.pref_audio_channels_auto, "audio-channels", "auto"),
  /** Use the system-preferred layout and safely fall back to stereo. This is mpv's default. */
  AutoSafe(R.string.pref_audio_channels_auto_safe, "audio-channels", "auto-safe"),
  Mono(R.string.pref_audio_channels_mono, "audio-channels", "mono"),
  Stereo(R.string.pref_audio_channels_stereo, "audio-channels", "stereo"),
  ReverseStereo(R.string.pref_audio_channels_stereo_reversed, "af", "pan=[stereo|c0=c1|c1=c0]"),
}
