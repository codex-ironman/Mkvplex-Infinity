/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.ui.browser.jellyfin

import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import app.infinity.mpvz.ui.icons.Icons
import app.infinity.mpvz.ui.icons.Icon
import app.infinity.mpvz.domain.jellyfin.JellyfinLinkStatus
import androidx.compose.ui.unit.dp
import app.infinity.mpvz.domain.jellyfin.JellyfinSourceFilter

@Composable
fun JellyfinSourceDialog(
  selection: JellyfinSourceSelection,
  onDismiss: () -> Unit,
  onRetry: () -> Unit,
  onCheck: (String) -> Unit,
  showManualChecks: Boolean,
  showCopy: Boolean,
  onCopy: (String) -> Unit,
  showCast: Boolean,
  onCast: (String) -> Unit,
  onSelect: (String) -> Unit,
) {
  var query by rememberSaveable(selection.serverId, selection.item.id) { mutableStateOf("") }
  var language by rememberSaveable(selection.serverId, selection.item.id) { mutableStateOf<String?>(null) }
  var languageMenu by remember { mutableStateOf(false) }
  var sourceMenu by remember(selection.requestId) { mutableStateOf<String?>(null) }
  val entries = remember(selection.sources) { JellyfinSourceFilter.index(selection.sources) }
  val languages = remember(entries) { JellyfinSourceFilter.availableLanguages(entries) }
  val selectedLanguage = language?.takeIf { it in languages }
  val filtered = remember(entries, selectedLanguage, query, selection.isLoading) {
    if (selection.isLoading) selection.sources else JellyfinSourceFilter.filter(entries, selectedLanguage, query)
  }
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Available links") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(selection.item.displayTitle, style = MaterialTheme.typography.titleSmall)
        if (!selection.isLoading && selection.sources.isNotEmpty()) {
          OutlinedTextField(
            value = query, onValueChange = { query = it }, label = { Text("Search links") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
          )
          Box {
            TextButton(onClick = { languageMenu = true }) {
              Text("Language: ${selectedLanguage ?: "All languages"} ▾")
            }
            DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
              DropdownMenuItem(
                text = { Text("All languages (${entries.size})") },
                onClick = { language = null; languageMenu = false },
              )
              languages.forEach { option ->
                DropdownMenuItem(
                  text = { Text("$option (${entries.count { option in it.languages }})") },
                  onClick = { language = option; languageMenu = false },
                )
              }
            }
          }
        }
        if (selection.sources.isNotEmpty()) {
          Text("${filtered.size} of ${selection.sources.size} links • Choose one to play")
          if (filtered.isEmpty()) Text("No links match these filters.")
          LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(max = 400.dp)) {
            // IDs preserve separate versions with identical names and keep rows stable as links arrive.
            itemsIndexed(filtered, key = { _, source -> source.id }) { index, source ->
              val status = selection.linkStatus[source.id]
              Column(
                modifier = Modifier.fillMaxWidth().combinedClickable(
                  onClick = { onSelect(source.id) },
                  onLongClickLabel = if (showCast) "Source actions" else null,
                  onLongClick = if (showCast) ({ sourceMenu = source.id }) else null,
                ).padding(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  DropdownMenu(expanded = showCast && sourceMenu == source.id, onDismissRequest = { sourceMenu = null }) {
                    DropdownMenuItem(text = { Text("Cast…") }, onClick = { sourceMenu = null; onCast(source.id) })
                  }
                  Text("${index + 1}. ${source.name}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                  if (showCopy) {
                    IconButton(onClick = { onCopy(source.id) }) {
                      Icon(imageVector = Icons.RoundedFilled.ContentCopy, contentDescription = "Copy video link", modifier = Modifier.size(22.dp))
                    }
                  }
                  if (showManualChecks) {
                  IconButton(
                    onClick = { onCheck(source.id) },
                    enabled = status != JellyfinLinkStatus.CHECKING,
                    modifier = Modifier.semantics {
                      contentDescription = when (status) {
                        JellyfinLinkStatus.CHECKING -> "Checking working link"
                        JellyfinLinkStatus.REACHABLE -> "Media sample checked; check again"
                        else -> "Check working link"
                      }
                    },
                  ) {
                    if (status == JellyfinLinkStatus.CHECKING) {
                      CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                      Icon(
                        imageVector = if (status == JellyfinLinkStatus.REACHABLE) Icons.RoundedFilled.CheckCircle else Icons.RoundedFilled.Refresh,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp),
                      )
                    }
                  }
                  } else if (status == JellyfinLinkStatus.REACHABLE) {
                    Icon(imageVector = Icons.RoundedFilled.CheckCircle, contentDescription = "Media sample checked", tint = MaterialTheme.colorScheme.primary)
                  }
                }
                if (selection.checkingEnabled || status != null) {
                  val label = when (status) {
                    JellyfinLinkStatus.CHECKING -> "Checking working link…"
                    JellyfinLinkStatus.REACHABLE -> "Media sample checked ✓"
                    JellyfinLinkStatus.UNAVAILABLE -> "Link did not respond successfully"
                    JellyfinLinkStatus.UNKNOWN -> "Could not verify; you can still try playing"
                    null -> if (source.id in selection.checkSourceIds) "Waiting to check…" else "Not checked (check limit)"
                  }
                  Text(label, style = MaterialTheme.typography.bodySmall)
                }
                if (source.description.isNotBlank()) Text(source.description, style = MaterialTheme.typography.bodySmall)
              }
              HorizontalDivider()
            }
          }
        }
        if (selection.isLoading) {
          CircularProgressIndicator()
          Text(when {
            selection.retryAttempt > 0 -> "Refreshing links automatically (${selection.retryAttempt}/2)…"
            selection.sources.isEmpty() -> "Finding links…"
            else -> "Checking for more links…"
          })
        }
        selection.error?.let { error ->
          Text(error, color = MaterialTheme.colorScheme.error)
          TextButton(onClick = onRetry) { Text("Retry") }
        }
      }
    },
    confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
  )
}
