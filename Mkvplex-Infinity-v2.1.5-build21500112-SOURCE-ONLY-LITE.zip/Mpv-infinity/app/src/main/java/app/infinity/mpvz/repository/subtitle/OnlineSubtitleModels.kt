/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.repository.subtitle

import android.net.Uri

enum class SubtitleProvider(
  val displayName: String,
) {
  WYZIE("Wyzie"),
  MPV_INFINITY_SUBTITLE_HUB("SubHub"),
}

enum class OnlineSubtitleSearchMode(
  val displayName: String,
) {
  WYZIE("Wyzie"),
  SUBHUB("SubHub"),
  HYBRID("Hybrid"),
}

data class OnlineSubtitleSearchRequest(
  val query: String,
  val tmdbId: Int? = null,
  val imdbId: String? = null,
  val season: Int? = null,
  val episode: Int? = null,
  val year: String? = null,
  val movieHash: String? = null,
)

data class OnlineSubtitle(
  val provider: SubtitleProvider,
  val id: String? = null,
  val url: String,
  val fileName: String? = null,
  val release: String? = null,
  val media: String? = null,
  val displayName: String,
  val displayLanguage: String,
  val language: String? = null,
  val source: String? = null,
  val format: String? = null,
  val encoding: String? = null,
  val downloadCount: Int? = null,
  val isHashMatch: Boolean = false,
  val isHearingImpaired: Boolean = false,
  val metadata: Map<String, String> = emptyMap(),
)

fun OnlineSubtitle.subdlGroupEpisodeRange(): IntRange? {
  if (provider != SubtitleProvider.MPV_INFINITY_SUBTITLE_HUB || source != "SubDL.com") return null
  val start = metadata[SUBDL_GROUP_EPISODE_START_KEY]?.toIntOrNull() ?: return null
  val end = metadata[SUBDL_GROUP_EPISODE_END_KEY]?.toIntOrNull() ?: return null
  if (start <= 0 || end < start || end - start >= MAX_SUBDL_GROUP_EPISODES) return null
  return start..end
}

fun OnlineSubtitle.selectedSubdlGroupEpisode(): Int? = metadata[SUBDL_SELECTED_EPISODE_KEY]?.toIntOrNull()

fun OnlineSubtitle.withSelectedSubdlGroupEpisode(episode: Int): OnlineSubtitle =
  copy(metadata = metadata + (SUBDL_SELECTED_EPISODE_KEY to episode.toString()))

const val SUBDL_GROUP_EPISODE_START_KEY = "subdlGroupEpisodeStart"
const val SUBDL_GROUP_EPISODE_END_KEY = "subdlGroupEpisodeEnd"
const val SUBDL_SELECTED_EPISODE_KEY = "subdlSelectedEpisode"

private const val MAX_SUBDL_GROUP_EPISODES = 500

interface OnlineSubtitleProvider {
  val provider: SubtitleProvider

  suspend fun search(request: OnlineSubtitleSearchRequest): Result<List<OnlineSubtitle>>

  suspend fun searchIncrementally(
    request: OnlineSubtitleSearchRequest,
    onResults: suspend (List<OnlineSubtitle>) -> Unit,
  ): Result<List<OnlineSubtitle>> =
    search(request).also { result ->
      result.getOrNull()?.let { onResults(it) }
    }

  suspend fun download(
    subtitle: OnlineSubtitle,
    mediaTitle: String,
  ): Result<Uri>
}
