/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.domain.jellyfin

/** Distinguish an empty source list from a failed request without showing URLs or credentials. */
internal object JellyfinSourceErrors {
  fun emptySelectionMessage(error: Throwable?): String {
    when ((error as? app.infinity.mpvz.data.jellyfin.JellyfinSourceRequestException)?.serverCode) {
      "RateLimitExceeded" -> return "The server's playback limit was reached. Stop another playback and retry."
      "NotAllowed", "AccessDenied" -> return "The server did not allow playback of this item. Check this account's permissions."
    }
    val status = Regex("Unable to load links: HTTP ([0-9]{3})")
      .matchEntire(error?.message.orEmpty())?.groupValues?.get(1)?.toIntOrNull()
    return when {
      status == 401 || status == 403 -> "Server sign-in failed (HTTP $status). Reconnect in Media Servers."
      status != null -> "Link request failed (HTTP $status). Retry or check the server."
      error == null || error.message == "No playable links were returned by the server" ->
        "The server returned no playable links for this item. Retry to check again."
      else -> "Links could not be loaded. Check the connection and retry."
    }
  }
}
