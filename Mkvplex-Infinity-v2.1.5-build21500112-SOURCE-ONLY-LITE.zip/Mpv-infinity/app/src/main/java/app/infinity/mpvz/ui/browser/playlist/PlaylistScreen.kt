/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.ui.browser.playlist

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.infinity.mpvz.R
import app.infinity.mpvz.preferences.BrowserPreferences
import app.infinity.mpvz.preferences.MediaLayoutMode
import app.infinity.mpvz.preferences.preference.collectAsState
import app.infinity.mpvz.presentation.Screen
import app.infinity.mpvz.presentation.components.pullrefresh.PullRefreshBox
import app.infinity.mpvz.ui.browser.cards.PlaylistCard
import app.infinity.mpvz.ui.browser.components.BrowserTopBar
import app.infinity.mpvz.ui.browser.components.ExpressiveScrollBar
import app.infinity.mpvz.ui.browser.components.fastScrollGlyph
import app.infinity.mpvz.ui.browser.dialogs.DeleteConfirmationDialog
import app.infinity.mpvz.ui.browser.selection.rememberSelectionManager
import app.infinity.mpvz.ui.browser.sheets.PlaylistActionSheet
import app.infinity.mpvz.ui.browser.states.EmptyState
import app.infinity.mpvz.ui.components.InlineSearchBar
import app.infinity.mpvz.ui.icons.Icon
import app.infinity.mpvz.ui.icons.Icons
import app.infinity.mpvz.ui.utils.LocalBackStack
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import org.koin.compose.koinInject

@Serializable
object PlaylistScreen : Screen {
  @OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
  @Composable
  override fun Content() {
    val context = LocalContext.current
    val browserPreferences = koinInject<BrowserPreferences>()
    val backStack = LocalBackStack.current
    val scope = rememberCoroutineScope()

    // ViewModel
    val viewModel: PlaylistViewModel =
      viewModel(
        factory = PlaylistViewModel.factory(context.applicationContext as android.app.Application),
      )

    val playlistsWithCount by viewModel.playlistsWithCount.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val hasCompletedInitialLoad by viewModel.hasCompletedInitialLoad.collectAsState()

    // Search state
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var isSearching by rememberSaveable { mutableStateOf(false) }
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusRequester = remember { FocusRequester() }

    // Filter playlists based on search query
    val filteredPlaylists =
      if (isSearching && searchQuery.isNotBlank()) {
        playlistsWithCount.filter { playlistWithCount ->
          playlistWithCount.playlist.name.contains(searchQuery, ignoreCase = true)
        }
      } else {
        playlistsWithCount
      }

    // Request focus when search is activated
    LaunchedEffect(isSearching) {
      if (isSearching) {
        focusRequester.requestFocus()
        keyboardController?.show()
      }
    }

    // Selection manager - use filtered list
    val selectionManager =
      rememberSelectionManager(
        items = filteredPlaylists,
        getId = { it.playlist.id },
        onDeleteItems = { itemsToDelete, _ ->
          // Delete all items sequentially (this is a suspend function, so it blocks until complete)
          itemsToDelete.forEach { item ->
            viewModel.deletePlaylist(item.playlist)
          }
          Pair(itemsToDelete.size, 0)
        },
        onOperationComplete = { viewModel.refresh() },
      )

    val listState = rememberLazyListState()
    val gridState = rememberLazyGridState()
    val isRefreshing = remember { mutableStateOf(false) }
    var showRenameDialog by rememberSaveable { mutableStateOf(false) }
    var showDeleteDialog by rememberSaveable { mutableStateOf(false) }
    // Playlist action sheet state
    var showPlaylistActionSheet by remember { mutableStateOf(false) }
    val hasProtectedSelection =
      selectionManager.getSelectedItems().any { item -> viewModel.isProtectedPlaylist(item.playlist) }

    // FAB visibility for scroll-based hiding
    val isFabVisible = remember { mutableStateOf(true) }

    // Predictive back: Intercept when in selection mode or searching
    BackHandler(enabled = selectionManager.isInSelectionMode || isSearching) {
      when {
        isSearching -> {
          isSearching = false
          searchQuery = ""
        }

        selectionManager.isInSelectionMode -> selectionManager.clear()
      }
    }

    // Synchronize NavigationBarState when selection mode changes
    SideEffect {
      app.infinity.mpvz.ui.browser.NavigationBarState.updateSelectionState(
        inSelectionMode = selectionManager.isInSelectionMode,
        onlyVideos = true,
      )
    }

    // Track scroll for FAB visibility
    val mediaLayoutMode by browserPreferences.mediaLayoutMode.collectAsState()
    app.infinity.mpvz.ui.browser.fab.FabScrollHelper.trackScrollForFabVisibility(
      listState = listState,
      gridState = if (mediaLayoutMode == MediaLayoutMode.GRID) gridState else null,
      isFabVisible = isFabVisible,
      expanded = false,
      onExpandedChange = {},
    )

    Scaffold(
      topBar = {
        if (isSearching) {
          // Search mode - show search bar
          InlineSearchBar(
            query = searchQuery,
            onQueryChange = { searchQuery = it },
            onSearch = { },
            modifier =
              Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            inputFieldModifier = Modifier.focusRequester(focusRequester),
            placeholder = {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_search_playlists),
              )
            },
            leadingIcon = {
              Icon(
                imageVector = Icons.RoundedFilled.Search,
                contentDescription =
                  androidx.compose.ui.res.stringResource(
                    app.infinity.mpvz.R.string.settings_search_title,
                  ),
              )
            },
            trailingIcon = {
              IconButton(
                onClick = {
                  isSearching = false
                  searchQuery = ""
                },
              ) {
                Icon(
                  imageVector = Icons.RoundedFilled.Close,
                  contentDescription =
                    androidx.compose.ui.res.stringResource(
                      app.infinity.mpvz.R.string.generic_cancel,
                    ),
                )
              }
            },
            shape = RoundedCornerShape(28.dp),
            tonalElevation = 6.dp,
          )
        } else {
          BrowserTopBar(
            title = stringResource(R.string.ui_playlists),
            isInSelectionMode = selectionManager.isInSelectionMode,
            selectedCount = selectionManager.selectedCount,
            totalCount = playlistsWithCount.size,
            onBackClick = null,
            onCancelSelection = { selectionManager.clear() },
            isSingleSelection = selectionManager.isSingleSelection,
            onSearchClick = { isSearching = true },
            onSettingsClick = {
              backStack.add(app.infinity.mpvz.ui.preferences.PreferencesScreen)
            },
            onRenameClick =
              if (selectionManager.isSingleSelection && !hasProtectedSelection) {
                { showRenameDialog = true }
              } else {
                null
              },
            onDeleteClick = if (hasProtectedSelection) null else ({ showDeleteDialog = true }),
            onSelectAll = { selectionManager.selectAll() },
            onInvertSelection = { selectionManager.invertSelection() },
            onDeselectAll = { selectionManager.clear() },
          )
        }
      },
      floatingActionButton = {
        val navigationBarHeight = app.infinity.mpvz.ui.browser.LocalNavigationBarHeight.current
        if (!selectionManager.isInSelectionMode && isFabVisible.value) {
          ExtendedFloatingActionButton(
            onClick = { showPlaylistActionSheet = true },
            icon = { Icon(Icons.RoundedFilled.Add, contentDescription = null) },
            text = {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_create_playlist),
              )
            },
            modifier = Modifier.padding(bottom = (navigationBarHeight - 16.dp).coerceAtLeast(0.dp)),
          )
        }
      },
    ) { paddingValues ->
      if (isSearching && filteredPlaylists.isEmpty() && searchQuery.isNotBlank()) {
        // Show "no results" for search
        Box(
          modifier =
            Modifier
              .fillMaxSize()
              .padding(paddingValues),
          contentAlignment = Alignment.Center,
        ) {
          EmptyState(
            icon = Icons.RoundedFilled.Search,
            title = stringResource(R.string.ui_no_playlists_found),
            message = "Try a different search term",
          )
        }
      } else if (playlistsWithCount.isEmpty() && hasCompletedInitialLoad) {
        Box(
          modifier =
            Modifier
              .fillMaxSize()
              .padding(paddingValues),
          contentAlignment = Alignment.Center,
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
          ) {
            EmptyState(
              icon = Icons.RoundedFilled.PlaylistAdd,
              title = stringResource(R.string.ui_no_playlists_yet),
              message = "Create a playlist or add one from an m3u URL",
            )
          }
        }
      } else {
        PlaylistListContent(
          playlistsWithCount = filteredPlaylists,
          listState = listState,
          gridState = gridState,
          isRefreshing = isRefreshing,
          onRefresh = { viewModel.refresh() },
          selectionManager = selectionManager,
          onPlaylistClick = { playlistWithCount ->
            if (selectionManager.isInSelectionMode) {
              selectionManager.toggle(playlistWithCount)
            } else {
              backStack.add(PlaylistDetailScreen(playlistWithCount.playlist.id))
            }
          },
          onPlaylistLongClick = { playlistWithCount ->
            selectionManager.handleLongClick(playlistWithCount)
          },
          modifier = Modifier.padding(paddingValues),
          isInSelectionMode = selectionManager.isInSelectionMode,
        )
      }
    }

    // Create playlist and M3U playlist dialogs moved to MainScreen

    // Playlist action sheets
    PlaylistActionSheet(
      isOpen = showPlaylistActionSheet,
      onDismiss = { showPlaylistActionSheet = false },
      onCreatePlaylist = viewModel::createPlaylist,
      onCreateM3UPlaylistFromFile = { uri ->
        viewModel.createM3UPlaylistFromFile(uri).also { result ->
          if (result.isSuccess) viewModel.refresh()
        }
      },
      onCreateM3UPlaylist = { url, userAgent ->
        viewModel.createM3UPlaylist(url, userAgent).also { result ->
          if (result.isSuccess) viewModel.refresh()
        }
      },
      context = context,
    )

    if (showRenameDialog && selectionManager.isSingleSelection) {
      val selectedPlaylist = selectionManager.getSelectedItems().firstOrNull()
      if (selectedPlaylist != null) {
        var playlistName by remember { mutableStateOf(selectedPlaylist.playlist.name) }
        androidx.compose.material3.AlertDialog(
          onDismissRequest = { showRenameDialog = false },
          title = {
            Text(
              androidx.compose.ui.res
                .stringResource(app.infinity.mpvz.R.string.ui_rename_playlist),
            )
          },
          text = {
            androidx.compose.material3.OutlinedTextField(
              value = playlistName,
              onValueChange = { playlistName = it },
              label = {
                Text(
                  androidx.compose.ui.res
                    .stringResource(app.infinity.mpvz.R.string.ui_playlist_name),
                )
              },
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
            )
          },
          confirmButton = {
            androidx.compose.material3.TextButton(
              onClick = {
                if (playlistName.isNotBlank()) {
                  scope.launch {
                    viewModel.updatePlaylist(selectedPlaylist.playlist.copy(name = playlistName.trim()))
                    showRenameDialog = false
                    selectionManager.clear()
                  }
                }
              },
              enabled = playlistName.isNotBlank(),
            ) {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.rename),
              )
            }
          },
          dismissButton = {
            androidx.compose.material3.TextButton(
              onClick = { showRenameDialog = false },
            ) {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.generic_cancel),
              )
            }
          },
        )
      }
    }

    if (showDeleteDialog) {
      DeleteConfirmationDialog(
        isOpen = true,
        onDismiss = { showDeleteDialog = false },
        onConfirm = {
          selectionManager.deleteSelected()
          showDeleteDialog = false
        },
        itemCount = selectionManager.selectedCount,
        itemType = "playlist",
        itemNames = selectionManager.getSelectedItems().map { it.playlist.name },
      )
    }
  }

  @Composable
  private fun PlaylistListContent(
    playlistsWithCount: List<PlaylistWithCount>,
    listState: LazyListState,
    gridState: androidx.compose.foundation.lazy.grid.LazyGridState,
    isRefreshing: androidx.compose.runtime.MutableState<Boolean>,
    onRefresh: suspend () -> Unit,
    selectionManager: app.infinity.mpvz.ui.browser.selection.SelectionManager<PlaylistWithCount, Int>,
    onPlaylistClick: (PlaylistWithCount) -> Unit,
    onPlaylistLongClick: (PlaylistWithCount) -> Unit,
    modifier: Modifier = Modifier,
    isInSelectionMode: Boolean = false,
  ) {
    val browserPreferences = koinInject<app.infinity.mpvz.preferences.BrowserPreferences>()
    val mediaLayoutMode by browserPreferences.mediaLayoutMode.collectAsState()
    val manualGridColumnsEnabled by browserPreferences.manualGridColumnsEnabled.collectAsState()
    val folderGridColumnsPortrait by browserPreferences.folderGridColumnsPortrait.collectAsState()
    val folderGridColumnsLandscape by browserPreferences.folderGridColumnsLandscape.collectAsState()

    val isGridMode = mediaLayoutMode == MediaLayoutMode.GRID

    // Only show scrollbar if list has more than 20 items
    val hasEnoughItems = playlistsWithCount.size > 20

    // Animate scrollbar alpha
    val scrollbarAlpha by androidx.compose.animation.core.animateFloatAsState(
      targetValue = if (hasEnoughItems) 1f else 0f,
      animationSpec =
        androidx.compose.animation.core.spring(
          dampingRatio = app.infinity.mpvz.ui.theme.AppMotion.Effect.Alpha.dampingRatio,
          stiffness = app.infinity.mpvz.ui.theme.AppMotion.Effect.Alpha.stiffness,
        ),
      label = "scrollbarAlpha",
    )

    PullRefreshBox(
      isRefreshing = isRefreshing,
      onRefresh = onRefresh,
      listState = listState,
      modifier = modifier.fillMaxSize(),
    ) {
      if (isGridMode) {
        // Grid layout
        val navigationBarHeight = app.infinity.mpvz.ui.browser.LocalNavigationBarHeight.current
        BoxWithConstraints(
          modifier =
            Modifier
              .fillMaxSize(),
        ) {
          val configuration = androidx.compose.ui.platform.LocalConfiguration.current
          val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
          val folderGridColumnsPref = if (isLandscape) folderGridColumnsLandscape else folderGridColumnsPortrait
          val folderGridColumns =
            if (manualGridColumnsEnabled) {
              folderGridColumnsPref.coerceAtLeast(1)
            } else {
              val contentHorizontalPadding = 8.dp
              val itemSpacing = 8.dp
              val usableWidth = maxWidth - (contentHorizontalPadding * 2) - itemSpacing
              val folderMinWidth = 100.dp
              (usableWidth / folderMinWidth).toInt().coerceAtLeast(1)
            }

          LazyVerticalGrid(
            columns = GridCells.Fixed(folderGridColumns),
            state = gridState,
            modifier = Modifier.fillMaxSize(),
            contentPadding =
              PaddingValues(
                start = 8.dp,
                end = 8.dp,
                bottom = if (isInSelectionMode) 88.dp else navigationBarHeight,
              ),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            items(
              count = playlistsWithCount.size,
              key = { playlistsWithCount[it].playlist.id },
            ) { index ->
              val playlistWithCount = playlistsWithCount[index]
              PlaylistCard(
                playlist = playlistWithCount.playlist,
                itemCount = playlistWithCount.itemCount,
                isSelected = selectionManager.isSelected(playlistWithCount),
                onClick = { onPlaylistClick(playlistWithCount) },
                onLongClick = { onPlaylistLongClick(playlistWithCount) },
                onThumbClick = { onPlaylistClick(playlistWithCount) },
                isGridMode = true,
              )
            }
          }
          if (hasEnoughItems && scrollbarAlpha > 0.01f) {
            ExpressiveScrollBar(
              gridState = gridState,
              dragLabelProvider = { index: Int ->
                fastScrollGlyph(playlistsWithCount.getOrNull(index)?.playlist?.name)
              },
              modifier =
                Modifier
                  .align(Alignment.CenterEnd)
                  .padding(end = 2.dp, top = 6.dp, bottom = navigationBarHeight + 6.dp)
                  .graphicsLayer { alpha = scrollbarAlpha },
            )
          }
        }
      } else {
        // List layout
        val navigationBarHeight = app.infinity.mpvz.ui.browser.LocalNavigationBarHeight.current
        Box(
          modifier =
            Modifier
              .fillMaxSize(),
        ) {
          LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding =
              PaddingValues(
                start = 8.dp,
                end = 8.dp,
                bottom = if (isInSelectionMode) 88.dp else navigationBarHeight,
              ),
            verticalArrangement = Arrangement.spacedBy(0.dp),
          ) {
            items(playlistsWithCount, key = { it.playlist.id }) { playlistWithCount ->
              PlaylistCard(
                playlist = playlistWithCount.playlist,
                itemCount = playlistWithCount.itemCount,
                isSelected = selectionManager.isSelected(playlistWithCount),
                onClick = { onPlaylistClick(playlistWithCount) },
                onLongClick = { onPlaylistLongClick(playlistWithCount) },
                onThumbClick = { onPlaylistClick(playlistWithCount) },
                isGridMode = false,
              )
            }
          }
          if (hasEnoughItems && scrollbarAlpha > 0.01f) {
            ExpressiveScrollBar(
              listState = listState,
              dragLabelProvider = { index: Int ->
                fastScrollGlyph(playlistsWithCount.getOrNull(index)?.playlist?.name)
              },
              modifier =
                Modifier
                  .align(Alignment.CenterEnd)
                  .padding(end = 2.dp, top = 6.dp, bottom = navigationBarHeight + 6.dp)
                  .graphicsLayer { alpha = scrollbarAlpha },
            )
          }
        }
      }
    }
  }
}
