/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.domain.jellyfin

/** A snapshot of the explicitly selected version; casting never starts the phone player. */
data class JellyfinCastMedia(
  val url: String,
  val title: String,
  val contentType: String,
  val durationMs: Long,
  val positionMs: Long,
)

internal object JellyfinCastPolicy {
  fun contentType(container: String?): String = when (container?.lowercase(java.util.Locale.ROOT)) {
    "mkv", "matroska" -> "video/x-matroska"
    "webm" -> "video/webm"
    "m3u8", "hls" -> "application/x-mpegURL"
    "mpd", "dash" -> "application/dash+xml"
    "ts", "mpegts", "m2ts" -> "video/mp2t"
    "avi" -> "video/x-msvideo"
    else -> "video/mp4"
  }

  fun positionMs(ticks: Long?, durationMs: Long, fromBeginning: Boolean): Long {
    if (fromBeginning) return 0
    val position = (ticks ?: 0).coerceAtLeast(0) / 10_000
    return if (durationMs > 0) position.coerceAtMost(durationMs) else position
  }
}
