/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.ui.browser.dialogs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenu
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.infinity.mpvz.domain.network.NetworkConnection
import app.infinity.mpvz.domain.network.NetworkProtocol

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditConnectionSheet(
  connection: NetworkConnection,
  isOpen: Boolean,
  onDismiss: () -> Unit,
  onSave: (NetworkConnection, Boolean) -> Unit,
  modifier: Modifier = Modifier,
) {
  if (!isOpen) return

  var name by remember(connection.id) { mutableStateOf(connection.name) }
  var protocol by remember(connection.id) { mutableStateOf(connection.protocol) }
  var host by remember(connection.id) { mutableStateOf(connection.host) }
  var port by remember(connection.id) { mutableStateOf(connection.port.toString()) }
  var username by remember(connection.id) { mutableStateOf(connection.username) }
  var password by remember(connection.id) { mutableStateOf("") }
  var clearPassword by remember(connection.id) { mutableStateOf(false) }
  var path by remember(connection.id) { mutableStateOf(connection.path) }
  var isAnonymous by remember(connection.id) { mutableStateOf(connection.isAnonymous) }
  var useHttps by remember(connection.id) { mutableStateOf(connection.useHttps) }
  var sftpHostKeyFingerprint by remember(connection.id) { mutableStateOf(connection.sftpHostKeyFingerprint) }
  var protocolMenuExpanded by remember { mutableStateOf(false) }
  val validSftpFingerprint = sftpHostKeyFingerprint.trim().matches(Regex("""SHA256:[A-Za-z0-9+/]{43}"""))

  val handleDismiss = {
    onDismiss()
  }

  val handleSave = {
    val updatedConnection =
      connection.copy(
        name = name.trim(),
        protocol = protocol,
        host = host.trim(),
        port = port.toIntOrNull() ?: protocol.defaultPort,
        username = if (isAnonymous) "" else username.trim(),
        password = if (isAnonymous) "" else password,
        path = path.ifBlank { "/" },
        isAnonymous = isAnonymous,
        useHttps = useHttps,
        sftpHostKeyFingerprint = sftpHostKeyFingerprint.trim(),
      )
    onSave(updatedConnection, isAnonymous || clearPassword)
  }
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  ModalBottomSheet(
    onDismissRequest = handleDismiss,
    sheetState = sheetState,
    modifier = modifier,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
    dragHandle = { BottomSheetDefaults.DragHandle() },
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().imePadding().navigationBarsPadding(),
    ) {
      Column(
        modifier =
          Modifier
            .widthIn(max = 640.dp)
            .align(Alignment.CenterHorizontally)
            .padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
      Text(
        text =
          androidx.compose.ui.res
            .stringResource(app.infinity.mpvz.R.string.ui_edit_connection),
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Medium,
      )
      Column(
        modifier =
          Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        // Name and Protocol in one row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          // Connection Name
          OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_name),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            },
            modifier = Modifier.weight(0.60f),
            singleLine = true,
          )

          // Protocol Dropdown
          ExposedDropdownMenuBox(
            expanded = protocolMenuExpanded,
            onExpandedChange = { protocolMenuExpanded = it },
            modifier = Modifier.weight(0.40f),
          ) {
            OutlinedTextField(
              value = protocol.displayName,
              onValueChange = { },
              readOnly = true,
              label = {
                Text(
                  androidx.compose.ui.res
                    .stringResource(app.infinity.mpvz.R.string.ui_protocol),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = protocolMenuExpanded) },
              modifier =
                Modifier
                  .fillMaxWidth()
                  .menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable),
            )
            ExposedDropdownMenu(
              expanded = protocolMenuExpanded,
              onDismissRequest = { protocolMenuExpanded = false },
            ) {
              NetworkProtocol.entries.forEach { proto ->
                DropdownMenuItem(
                  text = { Text(proto.displayName) },
                  onClick = {
                    protocol = proto
                    port = proto.defaultPort.toString()
                    protocolMenuExpanded = false
                  },
                )
              }
            }
          }
        }

        // Host
        OutlinedTextField(
          value = host,
          onValueChange = { host = it },
          label = {
            Text(
              androidx.compose.ui.res
                .stringResource(app.infinity.mpvz.R.string.ui_host_ip_address),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
          placeholder = { Text("192.168.1.100", maxLines = 1, overflow = TextOverflow.Ellipsis) },
        )

        // Port and Path in one row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          // Port
          OutlinedTextField(
            value = port,
            onValueChange = { port = it },
            label = {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_port),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            },
            modifier = Modifier.weight(0.3f),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          )

          // Path
          OutlinedTextField(
            value = path,
            onValueChange = { path = it },
            label = {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_path),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            },
            modifier = Modifier.weight(0.7f),
            singleLine = true,
            placeholder = { Text("/", maxLines = 1, overflow = TextOverflow.Ellipsis) },
          )
        }

        if (protocol == NetworkProtocol.SFTP) {
          OutlinedTextField(
            value = sftpHostKeyFingerprint,
            onValueChange = { sftpHostKeyFingerprint = it.trim() },
            label = { Text("SFTP host-key SHA-256 fingerprint") },
            placeholder = { Text("SHA256:...") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            supportingText = { Text("Verify this fingerprint with the server administrator before saving.") },
          )
        }

        // Anonymous checkbox
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Checkbox(
            checked = isAnonymous,
            onCheckedChange = { isAnonymous = it },
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            androidx.compose.ui.res
              .stringResource(app.infinity.mpvz.R.string.ui_anonymous_guest_access),
          )
        }

        // HTTPS checkbox (only for WebDAV)
        if (protocol == NetworkProtocol.WEBDAV) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Checkbox(
              checked = useHttps,
              onCheckedChange = {
                useHttps = it
                // Auto-update port when toggling HTTPS
                if (it && port == "80") {
                  port = "443"
                } else if (!it && port == "443") {
                  port = "80"
                }
              },
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              androidx.compose.ui.res
                .stringResource(app.infinity.mpvz.R.string.ui_use_https_secure_connection),
            )
          }
        }

        // Username and Password in one row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          // Username
          OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = {
              Text(
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_username),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            },
            modifier = Modifier.weight(0.50f),
            singleLine = true,
            enabled = !isAnonymous,
          )

          // Password
          OutlinedTextField(
            value = password,
            onValueChange = {
              password = it
              if (it.isNotEmpty()) clearPassword = false
            },
            label = {
              Text(
                androidx.compose.ui.res
                  .stringResource(
                    app.infinity.mpvz.R.string.ui_new_password_keep_existing,
                  ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            },
            modifier = Modifier.weight(0.50f),
            singleLine = true,
            enabled = !isAnonymous && !clearPassword,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
          )
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Checkbox(
            checked = clearPassword,
            onCheckedChange = { clear ->
              clearPassword = clear
              if (clear) password = ""
            },
            enabled = !isAnonymous,
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            androidx.compose.ui.res
              .stringResource(app.infinity.mpvz.R.string.ui_clear_saved_password),
          )
        }
        Row(
          modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
          horizontalArrangement = Arrangement.End,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          TextButton(onClick = handleDismiss) {
            Text(
              text =
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.generic_cancel),
              fontWeight = FontWeight.Medium,
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = handleSave,
            enabled =
              host.isNotBlank() &&
                (isAnonymous || username.isNotBlank()) &&
                (protocol != NetworkProtocol.SFTP || validSftpFingerprint),
          ) {
            Text(
              text =
                androidx.compose.ui.res
                  .stringResource(app.infinity.mpvz.R.string.ui_save),
              fontWeight = FontWeight.SemiBold,
            )
          }
        }
      }
    }
  }
}
}
