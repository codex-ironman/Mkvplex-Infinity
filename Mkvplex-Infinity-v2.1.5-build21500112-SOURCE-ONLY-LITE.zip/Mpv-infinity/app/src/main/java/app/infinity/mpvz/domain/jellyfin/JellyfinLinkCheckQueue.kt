/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.domain.jellyfin

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/** One chooser owns both automatic and explicitly requested checks, including their cancellation. */
internal class JellyfinLinkCheckQueue(
  parentScope: CoroutineScope,
  private val onStatus: (String, JellyfinLinkStatus) -> Unit,
  private val check: suspend (JellyfinMediaSource) -> JellyfinLinkStatus,
) {
  private val job = SupervisorJob(parentScope.coroutineContext[Job])
  private val scope = CoroutineScope(parentScope.coroutineContext + job + Dispatchers.IO)
  private val slots = Semaphore(2)
  private val attempted = mutableSetOf<String>()
  private val pending = mutableSetOf<String>()

  /** Explicit checks may retry a completed attempt, independently of the automatic check budget. */
  fun enqueue(source: JellyfinMediaSource, manual: Boolean = false): Boolean {
    synchronized(pending) {
      if (!job.isActive || source.id in pending || (!manual && source.id in attempted)) return false
      attempted += source.id
      pending += source.id
    }
    onStatus(source.id, JellyfinLinkStatus.CHECKING)
    scope.launch {
      try {
        slots.withPermit {
          val status = try {
            check(source)
          } catch (cancelled: CancellationException) {
            throw cancelled
          } catch (_: Exception) {
            JellyfinLinkStatus.UNKNOWN
          }
          if (job.isActive) onStatus(source.id, status)
        }
      } finally {
        synchronized(pending) { pending -= source.id }
      }
    }
    return true
  }

  fun cancel() = job.cancel()
}
