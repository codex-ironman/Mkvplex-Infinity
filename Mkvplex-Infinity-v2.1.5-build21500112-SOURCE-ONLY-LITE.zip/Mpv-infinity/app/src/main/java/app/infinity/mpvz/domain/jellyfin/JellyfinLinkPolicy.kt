/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.domain.jellyfin

enum class JellyfinLinkStatus { CHECKING, REACHABLE, UNAVAILABLE, UNKNOWN }

object JellyfinLinkPolicy {
  const val MAX_LINKS = 500
  fun validLimit(value: Int): Boolean = value in 0..MAX_LINKS
  fun <T> limited(items: List<T>, limit: Int): List<T> =
    if (limit in 1..MAX_LINKS) items.take(limit) else items

  // A small media read verifies reachability, never full-file/codec compatibility.
  fun mediaPrefix(bytes: ByteArray): Boolean {
    fun starts(vararg values: Int) = bytes.size >= values.size && values.indices.all {
      (bytes[it].toInt() and 255) == values[it]
    }
    if (starts(0x1a, 0x45, 0xdf, 0xa3) || starts(0x46, 0x4c, 0x56) ||
      starts(0x4f, 0x67, 0x67, 0x53) || starts(0x52, 0x49, 0x46, 0x46)) return true
    if (bytes.size >= 8 && bytes.copyOfRange(4, 8).toString(Charsets.US_ASCII) in
      setOf("ftyp", "styp", "moov", "mdat", "free")) return true
    if (bytes.size > 188 && (bytes[0].toInt() and 255) == 0x47 &&
      (bytes[188].toInt() and 255) == 0x47) return true
    return bytes.toString(Charsets.UTF_8).trimStart().startsWith("#EXTM3U")
  }
}
