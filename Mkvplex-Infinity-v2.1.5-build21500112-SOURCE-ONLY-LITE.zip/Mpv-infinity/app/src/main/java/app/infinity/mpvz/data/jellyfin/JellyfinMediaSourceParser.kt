/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.data.jellyfin

import app.infinity.mpvz.domain.jellyfin.JellyfinMediaSource
import app.infinity.mpvz.domain.jellyfin.JellyfinMediaStream
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.longOrNull
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.UUID

internal object JellyfinMediaSourceParser {
  fun parse(root: JsonObject, itemId: String): List<JellyfinMediaSource> {
    val sources = (root["MediaSources"] as? JsonArray).orEmpty()
    val stubId = remuxSecondStubId(itemId)
    fun isSecondStub(source: JsonObject): Boolean = stubId != null &&
      source.text("Id")?.let(::uuidText) == stubId && source.text("Path") == null &&
      source.text("Container") == null && (source["MediaStreams"] as? JsonArray).isNullOrEmpty() &&
      source["Size"].let { it == null || it.toString() == "null" }
    val hasSecondStub = sources.any { it is JsonObject && isSecondStub(it) }
    return sources.mapIndexedNotNull { index, element ->
      val source = element as? JsonObject ?: return@mapIndexedNotNull null
      // Remux creates a deterministic, empty "(2)" source to expose version pickers.
      // Detect its identity and path shape, never names, missing codecs, or source count alone.
      if (isSecondStub(source) || (hasSecondStub &&
          source.text("Id")?.let(::uuidText) == uuidText(itemId) &&
          isRemuxItemPath(source.text("Path"), itemId))) return@mapIndexedNotNull null
      // Remux uses this sentinel when its providers have returned no playable stream.
      if (source.text("Path")?.substringBefore('?')?.trimEnd('/')?.endsWith("/videos/no-streams", ignoreCase = true) == true) {
        return@mapIndexedNotNull null
      }
      // The items endpoint can also return this explicit no-result sentinel at /remux/{itemId}.
      if (source.text("Name") == "No streams found" && isRemuxItemPath(source.text("Path"), itemId)) {
        return@mapIndexedNotNull null
      }
      // The server's source ID, rather than its path or list position, selects the version.
      val id = source.text("Id") ?: itemId.takeIf { it.isNotBlank() } ?: return@mapIndexedNotNull null
      JellyfinMediaSource(
        id = id,
        name = source.text("Name") ?: "Link ${index + 1}",
        container = source.text("Container"),
        size = (source["Size"] as? JsonPrimitive)?.longOrNull,
        bitrate = (source["Bitrate"] as? JsonPrimitive)?.longOrNull,
        streams = parseStreams(source["MediaStreams"] as? JsonArray),
      )
    }
  }

  private fun uuidText(value: String): String = value.replace("-", "").lowercase(java.util.Locale.ROOT)

  private fun isRemuxItemPath(value: String?, itemId: String): Boolean {
    if (value == null) return false
    val path = runCatching { java.net.URI(value).path }.getOrNull() ?: return false
    val parts = path.trimEnd('/').split('/')
    return parts.size >= 2 && parts[parts.lastIndex - 1].equals("remux", ignoreCase = true) &&
      uuidText(parts.last()) == uuidText(itemId)
  }

  // uuid v5(NAMESPACE_OID, "{hyphenated item UUID}-stub2"), matching Remux v0.37's stub_sources.
  private fun remuxSecondStubId(itemId: String): String? {
    val compact = uuidText(itemId)
    if (!compact.matches(Regex("[0-9a-f]{32}"))) return null
    val canonical = "${compact.take(8)}-${compact.substring(8, 12)}-${compact.substring(12, 16)}-" +
      "${compact.substring(16, 20)}-${compact.substring(20)}"
    val namespace = UUID.fromString("6ba7b812-9dad-11d1-80b4-00c04fd430c8")
    val digest = MessageDigest.getInstance("SHA-1")
    digest.update(ByteBuffer.allocate(16).putLong(namespace.mostSignificantBits).putLong(namespace.leastSignificantBits).array())
    val hash = digest.digest("$canonical-stub2".toByteArray(Charsets.UTF_8))
    hash[6] = ((hash[6].toInt() and 0x0f) or 0x50).toByte()
    hash[8] = ((hash[8].toInt() and 0x3f) or 0x80).toByte()
    val bytes = ByteBuffer.wrap(hash)
    return uuidText(UUID(bytes.long, bytes.long).toString())
  }

  fun parseStreams(streams: JsonArray?): List<JellyfinMediaStream> =
    streams.orEmpty().mapNotNull { element ->
      val stream = element as? JsonObject ?: return@mapNotNull null
      val index = (stream["Index"] as? JsonPrimitive)?.intOrNull ?: return@mapNotNull null
      val type = stream.text("Type") ?: return@mapNotNull null
      JellyfinMediaStream(
        index = index,
        type = type,
        codec = stream.text("Codec"),
        language = stream.text("Language"),
        displayTitle = stream.text("DisplayTitle"),
        isExternal = (stream["IsExternal"] as? JsonPrimitive)?.booleanOrNull ?: false,
        deliveryUrl = stream.text("DeliveryUrl"),
      )
    }

  private fun JsonObject.text(key: String): String? =
    (this[key] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }
}
