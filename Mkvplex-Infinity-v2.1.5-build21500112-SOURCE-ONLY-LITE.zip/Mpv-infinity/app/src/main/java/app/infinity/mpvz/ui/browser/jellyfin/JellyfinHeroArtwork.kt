/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.ui.browser.jellyfin

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import app.infinity.mpvz.data.jellyfin.JellyfinClient
import app.infinity.mpvz.domain.jellyfin.JellyfinItem
import app.infinity.mpvz.domain.jellyfin.JellyfinServer
import app.infinity.mpvz.network.SharedHttpClient
import app.infinity.mpvz.presentation.components.RemoteImageLoader
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Dispatcher
import java.util.concurrent.TimeUnit

internal data class JellyfinHeroArtwork(
  val backdrop: String?,
  val poster: String?,
  val logo: String?,
) {
  val preferred: String? get() = backdrop ?: poster
}

internal fun heroArtwork(server: JellyfinServer, item: JellyfinItem): JellyfinHeroArtwork {
  val base = server.serverUrl
  val token = server.accessToken
  val backdrop = item.backdropImageTag?.takeIf(String::isNotBlank)?.let {
    JellyfinClient.getBackdropUrl(base, item.id, it, maxWidth = 960, token = token)
  }
  // Same URL as the home poster cards, so their already cached image can be used immediately.
  val poster = item.primaryImageTag?.takeIf(String::isNotBlank)?.let {
    JellyfinClient.getImageUrl(base, item.id, it, maxWidth = 400, token = token)
  }
  val logo = when {
    !item.logoImageTag.isNullOrBlank() ->
      JellyfinClient.getLogoUrl(base, item.id, item.logoImageTag, maxWidth = 480, token = token)
    !item.parentLogoItemId.isNullOrBlank() && !item.parentLogoImageTag.isNullOrBlank() ->
      JellyfinClient.getLogoUrl(base, item.parentLogoItemId, item.parentLogoImageTag, maxWidth = 480, token = token)
    else -> null
  }
  return JellyfinHeroArtwork(backdrop, poster, logo)
}

// Keep visible hero art out of the queue used by library rows and playback metadata.
// This retains the app's shared connection pool and image caches.
private val heroImageClient by lazy {
  SharedHttpClient.derive {
    dispatcher(Dispatcher().apply {
      maxRequests = 3
      maxRequestsPerHost = 3
    })
    callTimeout(15, TimeUnit.SECONDS)
  }
}

/** A slow backdrop may be previewed with a poster, but always wins if it arrives. */
internal suspend fun <T : Any> loadJellyfinHeroArtwork(
  backdrop: String?,
  poster: String?,
  previewDelayMs: Long = 350L,
  load: suspend (String) -> T?,
  publish: (T) -> Unit,
): Unit = coroutineScope {
  if (backdrop == null) {
    poster?.let { load(it) }?.let(publish)
    return@coroutineScope
  }
  val failed = CompletableDeferred<Unit>()
  val preview = poster?.takeIf { it != backdrop }?.let { url ->
    launch {
      withTimeoutOrNull(previewDelayMs) { failed.await() }
      load(url)?.let(publish)
    }
  }
  val result = load(backdrop)
  if (result == null) {
    failed.complete(Unit)
    preview?.join()
  } else {
    preview?.cancelAndJoin()
    publish(result)
  }
}

@Composable
internal fun JellyfinHeroBackdrop(
  artwork: JellyfinHeroArtwork,
  title: String,
  onReady: () -> Unit,
) {
  val context = LocalContext.current.applicationContext
  var finished by remember(artwork.backdrop, artwork.poster) { mutableStateOf(false) }
  var bitmap by remember(artwork.backdrop, artwork.poster) {
    mutableStateOf(
      artwork.backdrop?.let(RemoteImageLoader::getFromMemory)
        ?: artwork.poster?.let(RemoteImageLoader::getFromMemory),
    )
  }
  LaunchedEffect(artwork.backdrop, artwork.poster) {
    loadJellyfinHeroArtwork(
      backdrop = artwork.backdrop,
      poster = artwork.poster,
      load = { RemoteImageLoader.load(context, heroImageClient, it) },
      publish = { bitmap = it },
    )
    // If neither URL works, the title remains usable and the carousel can recover.
    finished = true
  }
  if (bitmap != null || finished) SideEffect(onReady)
  bitmap?.let {
    Image(
      bitmap = remember(it) { it.asImageBitmap() },
      contentDescription = title,
      contentScale = ContentScale.Crop,
      modifier = Modifier.fillMaxSize(),
    )
  }
}

@Composable
internal fun rememberJellyfinHeroLogo(url: String?, artworkReady: Boolean): Bitmap? {
  val context = LocalContext.current.applicationContext
  var bitmap by remember(url) { mutableStateOf(url?.let(RemoteImageLoader::getFromMemory)) }
  LaunchedEffect(url, artworkReady) {
    if (artworkReady && url != null && bitmap == null) {
      bitmap = RemoteImageLoader.load(context, heroImageClient, url)
    }
  }
  return bitmap
}

@Composable
internal fun PrefetchJellyfinHeroBackdrop(url: String?) {
  val context = LocalContext.current.applicationContext
  LaunchedEffect(url) {
    if (url != null) RemoteImageLoader.load(context, heroImageClient, url)
  }
}
