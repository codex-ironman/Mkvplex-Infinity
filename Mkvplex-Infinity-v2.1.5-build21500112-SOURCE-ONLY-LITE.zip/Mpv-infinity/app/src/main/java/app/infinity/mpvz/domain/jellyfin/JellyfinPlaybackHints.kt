/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.domain.jellyfin

/** For Infinity AUTO routing only. Decoder/HDR info still comes from the live player. */
object JellyfinPlaybackHints {
  private val hdr = Regex("(?i)\\b(?:hdr(?:10\\+?)?|dolby\\s*vision|dovi(?:withhdr10|withsdr)?|hlg|dv)\\b")
  private val sdr = Regex("(?i)\\bsdr\\b")
  private fun parse(value: String?): Boolean? = when {
    value.isNullOrBlank() -> null
    sdr.containsMatchIn(value) -> false
    hdr.containsMatchIn(value) -> true
    else -> null
  }
  fun hdr(item: JellyfinItem, source: JellyfinMediaSource?): Boolean? {
    if (source == null) return parse(item.videoHdrType)
    val video = source.streams.firstOrNull { it.type.equals("Video", true) }
    return parse(video?.displayTitle) ?: parse(source.name + " " + source.description)
  }
}
