/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.data.jellyfin

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

internal object JellyfinPlaybackUrls {
  fun streamUrl(
    base: String,
    itemId: String,
    token: String,
    isAudio: Boolean = false,
    mediaSourceId: String? = null,
  ): String = base.toHttpUrl().newBuilder()
    .addPathSegment(if (isAudio) "Audio" else "Videos")
    .addPathSegment(itemId)
    .addPathSegment("stream")
    .addQueryParameter("static", "true")
    .addQueryParameter("api_key", token)
    .addQueryParameter("ApiKey", token)
    .apply { mediaSourceId?.takeIf { it.isNotBlank() }?.let { addQueryParameter("MediaSourceId", it) } }
    .build().toString()

  /** The generated URL authenticates itself. Account headers can force relaying or leak on redirects. */
  fun streamRequestHeaders(url: String, headers: Map<String, String>): Map<String, String> {
    val target = url.toHttpUrlOrNull() ?: return headers
    if (!target.encodedPath.matches(Regex(".*/(?:Videos|Audio)/[^/]+/stream", RegexOption.IGNORE_CASE)) ||
      target.queryParameter("static") != "true") return headers
    val token = target.queryParameter("ApiKey")?.takeIf { it.isNotBlank() } ?: return headers
    if (token != target.queryParameter("api_key")) return headers
    val tokenParameter = Regex("(?:^|,)\\s*Token\\s*=\\s*\"${Regex.escape(token)}\"\\s*(?:,|$)", RegexOption.IGNORE_CASE)
    return headers.filterNot { (name, value) ->
      when (name.lowercase(java.util.Locale.ROOT)) {
        "x-emby-token", "x-mediabrowser-token" -> value == token
        "authorization", "x-emby-authorization" ->
          value.substringBefore(' ').lowercase(java.util.Locale.ROOT) in setOf("mediabrowser", "emby") &&
            tokenParameter.containsMatchIn(value.substringAfter(' ', ""))
        else -> false
      }
    }
  }

  fun subtitleUrl(
    base: String,
    itemId: String,
    token: String,
    mediaSourceId: String,
    index: Int,
    codec: String,
    deliveryUrl: String? = null,
  ): String {
    val server = base.toHttpUrl()
    val delivery = deliveryUrl?.takeIf { it.isNotBlank() }?.let { value ->
      value.toHttpUrlOrNull() ?: if (value.startsWith(server.encodedPath.trimEnd('/') + "/")) {
        server.resolve(value)
      } else {
        (base.trimEnd('/') + "/" + value.trimStart('/')).toHttpUrlOrNull()
      }
    }
    val url = delivery ?: server.newBuilder()
      .addPathSegment("Videos").addPathSegment(itemId).addPathSegment(mediaSourceId)
      .addPathSegment("Subtitles").addPathSegment(index.toString()).addPathSegment("Stream.$codec")
      .build()
    // External subtitle hosts must never receive the Jellyfin account token.
    return if (url.scheme == server.scheme && url.host == server.host && url.port == server.port) {
      url.newBuilder().setQueryParameter("api_key", token)
        .setQueryParameter("ApiKey", token).build().toString()
    } else url.toString()
  }
}
