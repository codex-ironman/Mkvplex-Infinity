/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.di

import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import app.infinity.mpvz.data.network.credentials.AndroidNetworkCredentialKey
import app.infinity.mpvz.data.network.credentials.NetworkCredentialCipher
import app.infinity.mpvz.database.MpvInfinityDatabase
import app.infinity.mpvz.database.repository.NetworkStreamEntryRepository
import app.infinity.mpvz.database.repository.PlaybackStateRepositoryImpl
import app.infinity.mpvz.database.repository.PlaylistRepository
import app.infinity.mpvz.database.repository.RecentlyPlayedRepositoryImpl
import app.infinity.mpvz.domain.playbackstate.repository.PlaybackStateRepository
import app.infinity.mpvz.domain.recentlyplayed.repository.RecentlyPlayedRepository
import app.infinity.mpvz.domain.thumbnail.ThumbnailRepository
import kotlinx.serialization.json.Json
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.bind
import org.koin.dsl.module

/**
 * Migration from version 1 (v1.0.0) to version 2 (v1.1.0)
 *
 * This is a squashed migration that handles ALL schema changes between v1.0.0 and v1.1.0
 *
 * Version 1 (v1.0.0) had 3 tables:
 * - PlaybackStateEntity (with secondarySid and secondarySubDelay columns, no videoZoom)
 * - RecentlyPlayedEntity (with columns: id, filePath, fileName, timestamp, launchSource)
 * - ExternalSubtitleEntity
 *
 * Version 2 (v1.1.0) changes:
 * - PlaybackStateEntity: Removes secondarySid and secondarySubDelay, adds videoZoom
 * - Removes ExternalSubtitleEntity table
 * - Adds video_metadata_cache table (for MediaInfo caching)
 * - Adds network_connections table (for SMB/FTP/WebDAV)
 * - Adds PlaylistEntity table (for custom playlists)
 * - Adds PlaylistItemEntity table (playlist items with foreign key)
 * - Adds 6 new columns to RecentlyPlayedEntity (videoTitle, duration, fileSize, width, height, playlistId)
 */
val MIGRATION_1_2 =
  object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
      try {
        android.util.Log.d("Migration_1_2", "Starting migration from v1.0.0 to v1.1.0")

        // ===== 1. Update PlaybackStateEntity: Remove secondarySid/secondarySubDelay, add videoZoom =====
        android.util.Log.d("Migration_1_2", "Updating PlaybackStateEntity schema")

        // Create new PlaybackStateEntity table with correct schema
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `PlaybackStateEntity_new` (
            `mediaTitle` TEXT NOT NULL,
            `lastPosition` INTEGER NOT NULL,
            `playbackSpeed` REAL NOT NULL,
            `videoZoom` REAL NOT NULL DEFAULT 0.0,
            `sid` INTEGER NOT NULL,
            `subDelay` INTEGER NOT NULL,
            `subSpeed` REAL NOT NULL,
            `aid` INTEGER NOT NULL,
            `audioDelay` INTEGER NOT NULL,
            `timeRemaining` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`mediaTitle`)
          )
          """.trimIndent(),
        )

        // Copy data from old table (excluding secondarySid and secondarySubDelay, adding videoZoom with default)
        db.execSQL(
          """
          INSERT INTO `PlaybackStateEntity_new` 
          (`mediaTitle`, `lastPosition`, `playbackSpeed`, `videoZoom`, `sid`, `subDelay`, 
           `subSpeed`, `aid`, `audioDelay`, `timeRemaining`)
          SELECT `mediaTitle`, `lastPosition`, `playbackSpeed`, 0.0, `sid`, `subDelay`, 
                 `subSpeed`, `aid`, `audioDelay`, `timeRemaining`
          FROM `PlaybackStateEntity`
          """.trimIndent(),
        )

        // Drop old table and rename new one
        db.execSQL("DROP TABLE `PlaybackStateEntity`")
        db.execSQL("ALTER TABLE `PlaybackStateEntity_new` RENAME TO `PlaybackStateEntity`")

        // ===== 2. Drop ExternalSubtitleEntity table =====
        android.util.Log.d("Migration_1_2", "Removing ExternalSubtitleEntity table")
        db.execSQL("DROP TABLE IF EXISTS `ExternalSubtitleEntity`")

        // ===== 3. Create video_metadata_cache table =====
        android.util.Log.d("Migration_1_2", "Creating video_metadata_cache table")
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `video_metadata_cache` (
            `path` TEXT NOT NULL,
            `size` INTEGER NOT NULL,
            `dateModified` INTEGER NOT NULL,
            `duration` INTEGER NOT NULL,
            `width` INTEGER NOT NULL,
            `height` INTEGER NOT NULL,
            `fps` REAL NOT NULL,
            `lastScanned` INTEGER NOT NULL,
            PRIMARY KEY(`path`)
          )
          """.trimIndent(),
        )

        // ===== 4. Create network_connections table =====
        android.util.Log.d("Migration_1_2", "Creating network_connections table")
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `network_connections` (
            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            `name` TEXT NOT NULL,
            `protocol` TEXT NOT NULL,
            `host` TEXT NOT NULL,
            `port` INTEGER NOT NULL,
            `username` TEXT NOT NULL DEFAULT '',
            `password` TEXT NOT NULL DEFAULT '',
            `path` TEXT NOT NULL DEFAULT '/',
            `isAnonymous` INTEGER NOT NULL DEFAULT 0,
            `lastConnected` INTEGER NOT NULL DEFAULT 0,
            `autoConnect` INTEGER NOT NULL DEFAULT 0
          )
          """.trimIndent(),
        )

        // ===== 5. Create PlaylistEntity table =====
        android.util.Log.d("Migration_1_2", "Creating PlaylistEntity table")
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `PlaylistEntity` (
            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            `name` TEXT NOT NULL,
            `createdAt` INTEGER NOT NULL,
            `updatedAt` INTEGER NOT NULL
          )
          """.trimIndent(),
        )

        // ===== 6. Create PlaylistItemEntity table with foreign key =====
        android.util.Log.d("Migration_1_2", "Creating PlaylistItemEntity table")
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `PlaylistItemEntity` (
            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            `playlistId` INTEGER NOT NULL,
            `filePath` TEXT NOT NULL,
            `fileName` TEXT NOT NULL,
            `position` INTEGER NOT NULL,
            `addedAt` INTEGER NOT NULL,
            `lastPlayedAt` INTEGER NOT NULL DEFAULT 0,
            `playCount` INTEGER NOT NULL DEFAULT 0,
            `lastPosition` INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(`playlistId`) REFERENCES `PlaylistEntity`(`id`) ON DELETE CASCADE
          )
          """.trimIndent(),
        )

        // Create index for PlaylistItemEntity foreign key
        db.execSQL(
          "CREATE INDEX IF NOT EXISTS `index_PlaylistItemEntity_playlistId` ON `PlaylistItemEntity` (`playlistId`)",
        )

        // ===== 7. Add new columns to RecentlyPlayedEntity =====
        android.util.Log.d("Migration_1_2", "Adding columns to RecentlyPlayedEntity")
        db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `videoTitle` TEXT")
        db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `duration` INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `fileSize` INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `width` INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `height` INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `playlistId` INTEGER")

        android.util.Log.d("Migration_1_2", "Migration completed successfully")
      } catch (e: Exception) {
        android.util.Log.e("Migration_1_2", "Migration failed", e)
        throw e
      }
    }
  }

/**
 * Migration from version 2 to version 3
 *
 * Changes:
 * - Adds externalSubtitles column to PlaybackStateEntity to persist external subtitle URIs
 */
val MIGRATION_2_3 =
  object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
      try {
        android.util.Log.d("Migration_2_3", "Starting migration from version 2 to version 3")

        // Add externalSubtitles column to PlaybackStateEntity
        db.execSQL("ALTER TABLE `PlaybackStateEntity` ADD COLUMN `externalSubtitles` TEXT NOT NULL DEFAULT ''")

        // Add subtitleCodec column to video_metadata_cache
        db.execSQL("ALTER TABLE video_metadata_cache ADD COLUMN subtitleCodec TEXT NOT NULL DEFAULT ''")

        android.util.Log.d("Migration_2_3", "Migration completed successfully")
      } catch (e: Exception) {
        android.util.Log.e("Migration_2_3", "Migration failed", e)
        throw e
      }
    }
  }

/**
 * Migration from version 3 to version 4
 *
 * Changes:
 * - Adds m3uSourceUrl and isM3uPlaylist columns to PlaylistEntity for M3U/M3U8 playlist support
 */
val MIGRATION_3_4 =
  object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
      try {
        android.util.Log.d("Migration_3_4", "Starting migration from version 3 to version 4")

        // Add M3U-related columns to PlaylistEntity
        db.execSQL(
          "ALTER TABLE `PlaylistEntity` ADD COLUMN `m3uSourceUrl` TEXT DEFAULT NULL",
        )
        db.execSQL(
          "ALTER TABLE `PlaylistEntity` ADD COLUMN `isM3uPlaylist` INTEGER NOT NULL DEFAULT 0",
        )

        android.util.Log.d("Migration_3_4", "Migration completed successfully")
      } catch (e: Exception) {
        android.util.Log.e("Migration_3_4", "Migration failed", e)
        throw e
      }
    }
  }

/**
 * Migration from version 4 to version 5
 *
 * Changes:
 * - Adds secondarySid column to PlaybackStateEntity to persist secondary subtitle track
 *   This allows saving and restoring both primary and secondary subtitle selections
 */
val MIGRATION_4_5 =
  object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
      try {
        android.util.Log.d("Migration_4_5", "Starting migration from version 4 to version 5")

        // Add secondarySid column to PlaybackStateEntity (-1 means disabled)
        db.execSQL(
          "ALTER TABLE `PlaybackStateEntity` ADD COLUMN `secondarySid` INTEGER NOT NULL DEFAULT -1",
        )

        android.util.Log.d("Migration_4_5", "Migration completed successfully")
      } catch (e: Exception) {
        android.util.Log.e("Migration_4_5", "Migration failed", e)
        throw e
      }
    }
  }

val MIGRATION_5_6 =
  object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
      try {
        android.util.Log.d("Migration_5_6", "Starting migration from version 5 to 6")

        // Get existing columns to check what needs to be added
        val cursor = db.query("PRAGMA table_info(video_metadata_cache)")
        val existingColumns = mutableSetOf<String>()
        while (cursor.moveToNext()) {
          val columnName = cursor.getString(cursor.getColumnIndexOrThrow("name"))
          existingColumns.add(columnName)
        }
        cursor.close()

        // Add subtitleCodec if it doesn't exist yet (should have been added in MIGRATION_2_3 but might be missing)
        if (!existingColumns.contains("subtitleCodec")) {
          try {
            db.execSQL("ALTER TABLE `video_metadata_cache` ADD COLUMN `subtitleCodec` TEXT NOT NULL DEFAULT ''")
            android.util.Log.d("Migration_5_6", "Added subtitleCodec column")
          } catch (e: Exception) {
            android.util.Log.w("Migration_5_6", "Error adding subtitleCodec column, may already exist", e)
          }
        } else {
          android.util.Log.d("Migration_5_6", "subtitleCodec column already exists, skipping")
        }

        // Add hasEmbeddedSubtitles if it doesn't exist
        if (!existingColumns.contains("hasEmbeddedSubtitles")) {
          try {
            db.execSQL(
              "ALTER TABLE `video_metadata_cache` ADD COLUMN `hasEmbeddedSubtitles` INTEGER NOT NULL DEFAULT 0",
            )
            android.util.Log.d("Migration_5_6", "Added hasEmbeddedSubtitles column")
          } catch (e: Exception) {
            android.util.Log.w("Migration_5_6", "Error adding hasEmbeddedSubtitles column, may already exist", e)
          }
        } else {
          android.util.Log.d("Migration_5_6", "hasEmbeddedSubtitles column already exists, skipping")
        }

        android.util.Log.d("Migration_5_6", "Migration completed successfully")
      } catch (e: Exception) {
        android.util.Log.e("Migration_5_6", "Migration failed", e)
        throw e
      }
    }
  }

/**
 * Migration from version 6 to version 7
 *
 * Changes:
 * - Adds useHttps column to network_connections table for explicit HTTPS control on WebDAV
 */
val MIGRATION_6_7 =
  object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) {
      try {
        android.util.Log.d("Migration_6_7", "Starting migration from version 6 to 7")

        // Add useHttps column to network_connections table
        db.execSQL("ALTER TABLE `network_connections` ADD COLUMN `useHttps` INTEGER NOT NULL DEFAULT 0")

        android.util.Log.d("Migration_6_7", "Migration completed successfully")
      } catch (e: Exception) {
        android.util.Log.e("Migration_6_7", "Migration failed", e)
        throw e
      }
    }
  }

/**
 * Migration from version 7 to version 8
 *
 * Changes:
 * - Adds hasBeenWatched column to PlaybackStateEntity to persist watched status
 */
val MIGRATION_7_8 =
  object : Migration(7, 8) {
    override fun migrate(db: SupportSQLiteDatabase) {
      try {
        android.util.Log.d("Migration_7_8", "Starting migration from version 7 to 8")

        // Add hasBeenWatched column to PlaybackStateEntity
        db.execSQL("ALTER TABLE `PlaybackStateEntity` ADD COLUMN `hasBeenWatched` INTEGER NOT NULL DEFAULT 0")

        android.util.Log.d("Migration_7_8", "Migration completed successfully")
      } catch (e: Exception) {
        android.util.Log.e("Migration_7_8", "Migration failed", e)
        throw e
      }
    }
  }

/**
 * Migration from version 8 to version 9
 *
 * This is a repair migration to fix databases that have incorrect schema at version 6/7/8.
 * Some users have databases that claim to be version 6+ but still have the old v1 schema
 * with secondarySubDelay column instead of externalSubtitles.
 *
 * Changes:
 * - Ensures PlaybackStateEntity has the correct schema by recreating the table
 * - Preserves all existing data during the migration
 */
val MIGRATION_8_9 =
  object : Migration(8, 9) {
    override fun migrate(db: SupportSQLiteDatabase) {
      try {
        android.util.Log.d("Migration_8_9", "Starting migration from version 8 to 9 (schema repair)")

        // Check current schema to see if we need to repair
        val cursor = db.query("PRAGMA table_info(PlaybackStateEntity)")
        val existingColumns = mutableSetOf<String>()
        while (cursor.moveToNext()) {
          val columnName = cursor.getString(cursor.getColumnIndexOrThrow("name"))
          existingColumns.add(columnName)
        }
        cursor.close()

        android.util.Log.d("Migration_8_9", "Existing columns: $existingColumns")

        // Check if we have the wrong schema (secondarySubDelay instead of externalSubtitles)
        val hasSecondarySubDelay = existingColumns.contains("secondarySubDelay")
        val hasExternalSubtitles = existingColumns.contains("externalSubtitles")
        val hasHasBeenWatched = existingColumns.contains("hasBeenWatched")

        if (hasSecondarySubDelay || !hasExternalSubtitles || !hasHasBeenWatched) {
          android.util.Log.d("Migration_8_9", "Schema mismatch detected, recreating table")

          // Create new table with correct schema
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `PlaybackStateEntity_new` (
              `mediaTitle` TEXT NOT NULL,
              `lastPosition` INTEGER NOT NULL,
              `playbackSpeed` REAL NOT NULL,
              `videoZoom` REAL NOT NULL DEFAULT 0.0,
              `sid` INTEGER NOT NULL,
              `secondarySid` INTEGER NOT NULL DEFAULT -1,
              `subDelay` INTEGER NOT NULL,
              `subSpeed` REAL NOT NULL,
              `aid` INTEGER NOT NULL,
              `audioDelay` INTEGER NOT NULL,
              `timeRemaining` INTEGER NOT NULL DEFAULT 0,
              `externalSubtitles` TEXT NOT NULL DEFAULT '',
              `hasBeenWatched` INTEGER NOT NULL DEFAULT 0,
              PRIMARY KEY(`mediaTitle`)
            )
            """.trimIndent(),
          )

          // Copy data from old table, handling missing columns
          if (hasExternalSubtitles && hasHasBeenWatched) {
            // Schema is correct, just copy everything
            db.execSQL(
              """
              INSERT INTO `PlaybackStateEntity_new` 
              SELECT * FROM `PlaybackStateEntity`
              """.trimIndent(),
            )
          } else if (hasExternalSubtitles && !hasHasBeenWatched) {
            // Missing hasBeenWatched only
            db.execSQL(
              """
              INSERT INTO `PlaybackStateEntity_new` 
              (`mediaTitle`, `lastPosition`, `playbackSpeed`, `videoZoom`, `sid`, `secondarySid`, 
               `subDelay`, `subSpeed`, `aid`, `audioDelay`, `timeRemaining`, `externalSubtitles`, `hasBeenWatched`)
              SELECT `mediaTitle`, `lastPosition`, `playbackSpeed`, `videoZoom`, `sid`, `secondarySid`, 
                     `subDelay`, `subSpeed`, `aid`, `audioDelay`, `timeRemaining`, `externalSubtitles`, 0
              FROM `PlaybackStateEntity`
              """.trimIndent(),
            )
          } else {
            // Has old schema with secondarySubDelay, need to map columns
            db.execSQL(
              """
              INSERT INTO `PlaybackStateEntity_new` 
              (`mediaTitle`, `lastPosition`, `playbackSpeed`, `videoZoom`, `sid`, `secondarySid`, 
               `subDelay`, `subSpeed`, `aid`, `audioDelay`, `timeRemaining`, `externalSubtitles`, `hasBeenWatched`)
              SELECT `mediaTitle`, `lastPosition`, `playbackSpeed`, 
                     COALESCE(`videoZoom`, 0.0), 
                     `sid`, 
                     COALESCE(`secondarySid`, -1), 
                     `subDelay`, `subSpeed`, `aid`, `audioDelay`, 
                     COALESCE(`timeRemaining`, 0), 
                     '', 
                     0
              FROM `PlaybackStateEntity`
              """.trimIndent(),
            )
          }

          // Drop old table and rename new one
          db.execSQL("DROP TABLE `PlaybackStateEntity`")
          db.execSQL("ALTER TABLE `PlaybackStateEntity_new` RENAME TO `PlaybackStateEntity`")

          android.util.Log.d("Migration_8_9", "Table recreated successfully")
        } else {
          android.util.Log.d("Migration_8_9", "Schema is correct, no repair needed")
        }

        // Add M3U-specific metadata columns to PlaylistItemEntity
        android.util.Log.d("Migration_8_9", "Adding M3U metadata columns to PlaylistItemEntity")

        val itemCursor = db.query("PRAGMA table_info(PlaylistItemEntity)")
        val itemColumns = mutableSetOf<String>()
        while (itemCursor.moveToNext()) {
          itemColumns.add(itemCursor.getString(itemCursor.getColumnIndexOrThrow("name")))
        }
        itemCursor.close()

        if (!itemColumns.contains("tvgId")) {
          db.execSQL("ALTER TABLE `PlaylistItemEntity` ADD COLUMN `tvgId` TEXT DEFAULT NULL")
        }
        if (!itemColumns.contains("tvgLogo")) {
          db.execSQL("ALTER TABLE `PlaylistItemEntity` ADD COLUMN `tvgLogo` TEXT DEFAULT NULL")
        }
        if (!itemColumns.contains("groupTitle")) {
          db.execSQL("ALTER TABLE `PlaylistItemEntity` ADD COLUMN `groupTitle` TEXT DEFAULT NULL")
        }
        if (!itemColumns.contains("licenseType")) {
          db.execSQL("ALTER TABLE `PlaylistItemEntity` ADD COLUMN `licenseType` TEXT DEFAULT NULL")
        }
        if (!itemColumns.contains("licenseKey")) {
          db.execSQL("ALTER TABLE `PlaylistItemEntity` ADD COLUMN `licenseKey` TEXT DEFAULT NULL")
        }
        if (!itemColumns.contains("userAgent")) {
          db.execSQL("ALTER TABLE `PlaylistItemEntity` ADD COLUMN `userAgent` TEXT DEFAULT NULL")
        }
        if (!itemColumns.contains("isFavorite")) {
          db.execSQL("ALTER TABLE `PlaylistItemEntity` ADD COLUMN `isFavorite` INTEGER NOT NULL DEFAULT 0")
        }

        // Create index for isFavorite
        db.execSQL(
          "CREATE INDEX IF NOT EXISTS `index_PlaylistItemEntity_isFavorite` ON `PlaylistItemEntity` (`isFavorite`)",
        )

        // Add userAgent column to PlaylistEntity
        val playlistCursor = db.query("PRAGMA table_info(PlaylistEntity)")
        val playlistColumns = mutableSetOf<String>()
        while (playlistCursor.moveToNext()) {
          playlistColumns.add(playlistCursor.getString(playlistCursor.getColumnIndexOrThrow("name")))
        }
        playlistCursor.close()

        if (!playlistColumns.contains("userAgent")) {
          db.execSQL("ALTER TABLE `PlaylistEntity` ADD COLUMN `userAgent` TEXT DEFAULT NULL")
        }

        android.util.Log.d("Migration_8_9", "Migration completed successfully")
      } catch (e: Exception) {
        android.util.Log.e("Migration_8_9", "Migration failed", e)
        throw e
      }
    }
  }

val MIGRATION_9_10 =
  object : Migration(9, 10) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL(
        """
        CREATE TABLE IF NOT EXISTS `directory_scan_index` (
          `scanKey` TEXT NOT NULL,
          `path` TEXT NOT NULL,
          `rootPath` TEXT NOT NULL,
          `fingerprint` TEXT NOT NULL,
          `isNoMediaRoot` INTEGER NOT NULL,
          `videoCount` INTEGER NOT NULL,
          `totalSize` INTEGER NOT NULL,
          `totalDuration` INTEGER NOT NULL,
          `lastModified` INTEGER NOT NULL,
          `hasSubfolders` INTEGER NOT NULL,
          `lastScanned` INTEGER NOT NULL,
          PRIMARY KEY(`scanKey`, `path`)
        )
        """.trimIndent(),
      )
      db.execSQL(
        "CREATE INDEX IF NOT EXISTS `index_directory_scan_index_scanKey_rootPath` ON `directory_scan_index` (`scanKey`, `rootPath`)",
      )
      db.execSQL(
        "CREATE INDEX IF NOT EXISTS `index_directory_scan_index_scanKey_isNoMediaRoot` ON `directory_scan_index` (`scanKey`, `isNoMediaRoot`)",
      )
    }
  }

/**
 * Migration from version 10 to version 11
 *
 * Changes:
 * - Adds secure_media table for the Secure Folder feature (hidden, app-private media)
 */
val MIGRATION_10_11 =
  object : Migration(10, 11) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL(
        """
        CREATE TABLE IF NOT EXISTS `secure_media` (
          `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
          `originalPath` TEXT NOT NULL,
          `secureFilePath` TEXT NOT NULL,
          `fileName` TEXT NOT NULL,
          `fileSize` INTEGER NOT NULL,
          `mimeType` TEXT NOT NULL,
          `dateHidden` INTEGER NOT NULL
        )
        """.trimIndent(),
      )
      db.execSQL(
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_secure_media_secureFilePath` ON `secure_media` (`secureFilePath`)",
      )
    }
  }

val MIGRATION_11_12 =
  object : Migration(11, 12) {
    override fun migrate(db: SupportSQLiteDatabase) {
      val cursor = db.query("PRAGMA table_info(PlaylistEntity)")
      val columns = mutableSetOf<String>()
      while (cursor.moveToNext()) {
        columns.add(cursor.getString(cursor.getColumnIndexOrThrow("name")))
      }
      cursor.close()

      if (!columns.contains("isAudio")) {
        db.execSQL("ALTER TABLE `PlaylistEntity` ADD COLUMN `isAudio` INTEGER NOT NULL DEFAULT 0")
      }
    }
  }
val MIGRATION_12_13 =
  object : Migration(12, 13) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL(
        """
        CREATE TABLE IF NOT EXISTS `network_stream_entries` (
          `stableKey` TEXT NOT NULL,
          `entryType` TEXT NOT NULL,
          `canonicalSourceUri` TEXT NOT NULL,
          `infoHash` TEXT,
          `fileIndex` INTEGER,
          `filePath` TEXT,
          `fileName` TEXT NOT NULL,
          `fileSize` INTEGER NOT NULL,
          `updatedAt` INTEGER NOT NULL,
          PRIMARY KEY(`stableKey`)
        )
        """.trimIndent(),
      )
      db.execSQL(
        "CREATE INDEX IF NOT EXISTS `index_network_stream_entries_entryType_updatedAt` " +
          "ON `network_stream_entries` (`entryType`, `updatedAt`)",
      )
      db.execSQL(
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_network_stream_entries_infoHash_fileIndex` " +
          "ON `network_stream_entries` (`infoHash`, `fileIndex`)",
      )
    }
  }

val MIGRATION_13_14 =
  object : Migration(13, 14) {
    override fun migrate(db: SupportSQLiteDatabase) {
      val cursor = db.query("PRAGMA table_info(network_stream_entries)")
      val columns = mutableSetOf<String>()
      while (cursor.moveToNext()) {
        columns.add(cursor.getString(cursor.getColumnIndexOrThrow("name")))
      }
      cursor.close()

      if (!columns.contains("posterUrl")) {
        db.execSQL("ALTER TABLE `network_stream_entries` ADD COLUMN `posterUrl` TEXT DEFAULT NULL")
      }
      if (!columns.contains("backdropUrl")) {
        db.execSQL("ALTER TABLE `network_stream_entries` ADD COLUMN `backdropUrl` TEXT DEFAULT NULL")
      }
      if (!columns.contains("groupTitle")) {
        db.execSQL("ALTER TABLE `network_stream_entries` ADD COLUMN `groupTitle` TEXT DEFAULT NULL")
      }
      if (!columns.contains("overview")) {
        db.execSQL("ALTER TABLE `network_stream_entries` ADD COLUMN `overview` TEXT DEFAULT NULL")
      }
      if (!columns.contains("releaseYear")) {
        db.execSQL("ALTER TABLE `network_stream_entries` ADD COLUMN `releaseYear` TEXT DEFAULT NULL")
      }
      if (!columns.contains("mediaType")) {
        db.execSQL("ALTER TABLE `network_stream_entries` ADD COLUMN `mediaType` TEXT DEFAULT NULL")
      }
    }
  }

val MIGRATION_14_15 =
  object : Migration(14, 15) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL(
        """
        CREATE TABLE IF NOT EXISTS `jellyfin_servers` (
          `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
          `name` TEXT NOT NULL,
          `serverUrl` TEXT NOT NULL,
          `userId` TEXT NOT NULL,
          `username` TEXT NOT NULL,
          `accessToken` TEXT NOT NULL,
          `lastConnected` INTEGER NOT NULL DEFAULT 0
        )
        """.trimIndent(),
      )
    }
  }

val MIGRATION_15_16 =
  object : Migration(15, 16) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL(
        "CREATE INDEX IF NOT EXISTS `index_RecentlyPlayedEntity_filePath` ON `RecentlyPlayedEntity` (`filePath`)",
      )
      db.execSQL(
        "CREATE INDEX IF NOT EXISTS `index_RecentlyPlayedEntity_timestamp` ON `RecentlyPlayedEntity` (`timestamp`)",
      )
    }
  }

val MIGRATION_16_17 =
  object : Migration(16, 17) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL(
        """
        CREATE TABLE IF NOT EXISTS `download_items` (
          `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
          `systemDownloadId` INTEGER NOT NULL DEFAULT -1,
          `url` TEXT NOT NULL,
          `dirPath` TEXT NOT NULL,
          `fileName` TEXT NOT NULL,
          `status` TEXT NOT NULL DEFAULT 'QUEUED',
          `progress` INTEGER NOT NULL DEFAULT 0,
          `totalBytes` INTEGER NOT NULL DEFAULT 0,
          `failureReason` TEXT,
          `timeQueued` INTEGER NOT NULL DEFAULT 0,
          `source` TEXT NOT NULL DEFAULT 'link',
          `title` TEXT NOT NULL DEFAULT '',
          `posterUrl` TEXT,
          `sourceUrl` TEXT,
          `jellyfinServerId` TEXT,
          `jellyfinItemId` TEXT,
          `jellyfinSeriesName` TEXT,
          `seasonNumber` INTEGER,
          `episodeNumber` INTEGER,
          `isAudio` INTEGER NOT NULL DEFAULT 0
        )
        """.trimIndent(),
      )
      db.execSQL("CREATE INDEX IF NOT EXISTS `index_download_items_systemDownloadId` ON `download_items` (`systemDownloadId`)")
      db.execSQL("CREATE INDEX IF NOT EXISTS `index_download_items_jellyfinItemId` ON `download_items` (`jellyfinItemId`)")
    }
  }

val MIGRATION_18_19 =
  object : Migration(18, 19) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL("ALTER TABLE `PlaybackStateEntity` ADD COLUMN `videoAspect` TEXT NOT NULL DEFAULT 'Fit'")
      db.execSQL("ALTER TABLE `PlaybackStateEntity` ADD COLUMN `customAspectRatio` REAL NOT NULL DEFAULT -1.0")
    }
  }
val MIGRATION_17_18 =
  object : Migration(17, 18) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL("ALTER TABLE `download_items` ADD COLUMN `stagingPath` TEXT")
    }
  }

val MIGRATION_19_20 =
  object : Migration(19, 20) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL(
        """
        CREATE TABLE IF NOT EXISTS `navidrome_servers` (
          `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
          `name` TEXT NOT NULL,
          `serverUrl` TEXT NOT NULL,
          `username` TEXT NOT NULL,
          `password` TEXT NOT NULL,
          `token` TEXT NOT NULL,
          `authMode` TEXT NOT NULL,
          `lastConnected` INTEGER NOT NULL
        )
        """.trimIndent(),
      )
    }
  }

val MIGRATION_20_21 =
  object : Migration(20, 21) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL("""CREATE TABLE IF NOT EXISTS `audiobooks` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sourceKey` TEXT NOT NULL,
        `title` TEXT NOT NULL, `subtitle` TEXT NOT NULL, `author` TEXT NOT NULL,
        `narrator` TEXT NOT NULL, `series` TEXT NOT NULL, `seriesPart` TEXT NOT NULL,
        `description` TEXT NOT NULL, `genre` TEXT NOT NULL, `language` TEXT NOT NULL,
        `publisher` TEXT NOT NULL, `publishedYear` TEXT NOT NULL, `isbn` TEXT NOT NULL,
        `asin` TEXT NOT NULL, `abridged` INTEGER, `coverUri` TEXT, `addedAt` INTEGER NOT NULL,
        `lastPlayedAt` INTEGER NOT NULL, `currentTrackId` INTEGER, `positionMs` INTEGER NOT NULL,
        `progressMs` INTEGER NOT NULL, `finished` INTEGER NOT NULL, `playbackSpeed` REAL NOT NULL,
        `rewindSeconds` INTEGER NOT NULL)""")
      db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_audiobooks_sourceKey` ON `audiobooks` (`sourceKey`)")
      db.execSQL("""CREATE TABLE IF NOT EXISTS `audiobook_tracks` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `bookId` INTEGER NOT NULL,
        `uri` TEXT NOT NULL, `fileName` TEXT NOT NULL, `title` TEXT NOT NULL,
        `position` INTEGER NOT NULL, `durationMs` INTEGER NOT NULL, `size` INTEGER NOT NULL,
        FOREIGN KEY(`bookId`) REFERENCES `audiobooks`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)""")
      db.execSQL("CREATE INDEX IF NOT EXISTS `index_audiobook_tracks_bookId` ON `audiobook_tracks` (`bookId`)")
      db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_audiobook_tracks_bookId_uri` ON `audiobook_tracks` (`bookId`, `uri`)")
      db.execSQL("""CREATE TABLE IF NOT EXISTS `audiobook_chapters` (
        `trackId` INTEGER NOT NULL, `startMs` INTEGER NOT NULL, `endMs` INTEGER NOT NULL, `title` TEXT NOT NULL,
        PRIMARY KEY(`trackId`, `startMs`),
        FOREIGN KEY(`trackId`) REFERENCES `audiobook_tracks`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)""")
      db.execSQL("""CREATE TABLE IF NOT EXISTS `audiobookshelf_servers` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL,
        `serverUrl` TEXT NOT NULL, `username` TEXT NOT NULL, `token` TEXT NOT NULL,
        `userId` TEXT NOT NULL, `activeLibraryId` TEXT, `lastConnected` INTEGER NOT NULL)""")
    }
  }

val MIGRATION_21_22 =
  object : Migration(21, 22) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL("ALTER TABLE `network_connections` ADD COLUMN `sftpHostKeyFingerprint` TEXT NOT NULL DEFAULT ''")
    }
  }

val MIGRATION_22_23 =
  object : Migration(22, 23) {
    override fun migrate(db: SupportSQLiteDatabase) {
      db.execSQL("ALTER TABLE `jellyfin_servers` ADD COLUMN `serverType` TEXT NOT NULL DEFAULT 'JELLYFIN'")
    }
  }

val DatabaseModule =
  module {
    single<Json> {
      Json {
        isLenient = true
        ignoreUnknownKeys = true
      }
    }

    single<MpvInfinityDatabase> {
      val context = androidContext()
      Room
        .databaseBuilder(context, MpvInfinityDatabase::class.java, "Mpv∞.db")
        .setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
        .addMigrations(
          MIGRATION_1_2,
          MIGRATION_2_3,
          MIGRATION_3_4,
          MIGRATION_4_5,
          MIGRATION_5_6,
          MIGRATION_6_7,
          MIGRATION_7_8,
          MIGRATION_8_9,
          MIGRATION_9_10,
          MIGRATION_10_11,
          MIGRATION_11_12,
          MIGRATION_12_13,
          MIGRATION_13_14,
          MIGRATION_14_15,
          MIGRATION_15_16,
          MIGRATION_16_17,
          MIGRATION_17_18,
          MIGRATION_18_19,
          MIGRATION_19_20,
          MIGRATION_20_21,
          MIGRATION_21_22,
          MIGRATION_22_23,
        ).build()
    }

    singleOf(::PlaybackStateRepositoryImpl).bind(PlaybackStateRepository::class)

    single<RecentlyPlayedRepository> {
      RecentlyPlayedRepositoryImpl(get<MpvInfinityDatabase>().recentlyPlayedDao())
    }

    single { ThumbnailRepository(androidContext()) }

    single {
      app.infinity.mpvz.database.repository.VideoMetadataCacheRepository(
        context = androidContext(),
        dao = get<MpvInfinityDatabase>().videoMetadataDao(),
      )
    }

    // MediaFileRepository is a singleton object - no DI needed

    single {
      get<MpvInfinityDatabase>().networkConnectionDao()
    }

    single {
      get<MpvInfinityDatabase>().networkStreamEntryDao()
    }

    single {
      NetworkStreamEntryRepository(get())
    }

    single {
      NetworkCredentialCipher(AndroidNetworkCredentialKey::getOrCreate)
    }

    single {
      app.infinity.mpvz.repository.NetworkRepository(
        dao = get(),
        credentialCipher = get(),
      )
    }

    single {
      PlaylistRepository(
        playlistDao = get<MpvInfinityDatabase>().playlistDao(),
        httpClient = get(),
        applicationContext = androidContext(),
        ytdlPreferences = get(),
      )
    }

    single {
      get<MpvInfinityDatabase>().secureMediaDao()
    }

    single {
      app.infinity.mpvz.database.repository.SecureFolderRepository(
        dao = get<MpvInfinityDatabase>().secureMediaDao(),
      )
    }

    single {
      get<MpvInfinityDatabase>().jellyfinServerDao()
    }

    single {
      app.infinity.mpvz.data.jellyfin.JellyfinClient(
        httpClient = get(),
        json = get(),
      )
    }

    single {
      app.infinity.mpvz.repository.JellyfinRepository(
        dao = get(),
        client = get(),
      )
    }

    single {
      get<MpvInfinityDatabase>().navidromeServerDao()
    }

    single {
      app.infinity.mpvz.data.navidrome.NavidromeClient(
        httpClient = get(),
        json = get(),
      )
    }

    single {
      app.infinity.mpvz.repository.NavidromeRepository(
        dao = get(),
        client = get(),
      )
    }

    single { get<MpvInfinityDatabase>().audiobookDao() }
    single { get<MpvInfinityDatabase>().audiobookshelfServerDao() }
    single {
      app.infinity.mpvz.data.audiobookshelf.AudiobookshelfClient(
        httpClient = get(),
        json = get(),
      )
    }
    single {
      app.infinity.mpvz.repository.AudiobookshelfRepository(
        dao = get(),
        client = get(),
      )
    }
  }
