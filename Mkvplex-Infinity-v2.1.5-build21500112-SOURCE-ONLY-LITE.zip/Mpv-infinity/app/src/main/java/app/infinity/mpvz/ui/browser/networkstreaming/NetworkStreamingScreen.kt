/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.ui.browser.networkstreaming

import android.widget.Toast
import android.content.Context
import android.content.SharedPreferences
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryScrollableTabRow
import androidx.compose.material3.RadioButton
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SheetValue
import androidx.compose.material3.rememberBottomSheetState
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.lifecycle.viewmodel.compose.viewModel
import app.infinity.mpvz.R
import app.infinity.mpvz.database.entities.NetworkStreamEntryEntity
import app.infinity.mpvz.database.repository.NetworkStreamEntryRepository
import app.infinity.mpvz.domain.network.ConnectionStatus
import app.infinity.mpvz.domain.network.NetworkConnection
import app.infinity.mpvz.domain.torrent.TorrentStreamingEngine
import app.infinity.mpvz.domain.torrent.formatTorrentBytes
import app.infinity.mpvz.domain.torrent.isTorrentSource
import app.infinity.mpvz.domain.torrent.normalizeTorrentSource
import app.infinity.mpvz.preferences.YtdlPreferences
import app.infinity.mpvz.preferences.NetworkBookmarkPreferences
import app.infinity.mpvz.preferences.preference.collectAsState
import app.infinity.mpvz.presentation.Screen
import app.infinity.mpvz.presentation.components.RemoteImage
import app.infinity.mpvz.repository.wyzie.WyzieSearchRepository
import app.infinity.mpvz.utils.media.MediaInfoParser
import app.infinity.mpvz.ui.browser.cards.NetworkConnectionCard
import app.infinity.mpvz.ui.browser.components.BrowserTopBar
import app.infinity.mpvz.ui.browser.dialogs.AddConnectionSheet
import app.infinity.mpvz.ui.browser.dialogs.EditConnectionSheet
import app.infinity.mpvz.ui.components.InlineSearchBar
import app.infinity.mpvz.ui.icons.AppIcon
import app.infinity.mpvz.ui.icons.Icon
import app.infinity.mpvz.ui.icons.Icons
import app.infinity.mpvz.ui.player.ytdlp.YtdlpInstallPromptDialog
import app.infinity.mpvz.ui.player.ytdlp.YtdlpInstallProgressDialog
import app.infinity.mpvz.ui.player.ytdlp.YtdlpManager
import app.infinity.mpvz.ui.preferences.YtdlpSettingsScreen
import app.infinity.mpvz.ui.torrent.TorrentSelectionInput
import app.infinity.mpvz.ui.torrent.TorrentSelectionScreen
import app.infinity.mpvz.ui.torrent.TorrentSelectionViewModel
import app.infinity.mpvz.ui.utils.LocalBackStack
import app.infinity.mpvz.utils.media.SharedUrlExtractor
import app.infinity.mpvz.utils.media.MediaUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import org.koin.compose.koinInject

private const val VIEWED_TORRENT_FILES_PREFS = "torrent_viewed_files"

private enum class NetworkTab(val titleResId: Int) {
  LOCAL_NETWORK(R.string.ui_local_network),
  MEDIA(R.string.ui_media),
  SYNC_PLAY(R.string.syncplay_title),
}

@Serializable
object NetworkStreamingScreen : Screen {
  @OptIn(ExperimentalMaterial3Api::class)
  @Composable
  override fun Content() {
    val backstack = LocalBackStack.current
    val context = LocalContext.current
    val viewModel: NetworkStreamingViewModel =
      viewModel(factory = NetworkStreamingViewModel.factory(context.applicationContext as android.app.Application))
    val torrentStreamingEngine = koinInject<TorrentStreamingEngine>()
    val streamEntryRepository = koinInject<NetworkStreamEntryRepository>()
    val ytdlPreferences = koinInject<YtdlPreferences>()
    val bookmarkPreferences = koinInject<NetworkBookmarkPreferences>()
    val wyzieSearchRepository = koinInject<WyzieSearchRepository>()
    val linkDownloadCoordinator = koinInject<app.infinity.mpvz.domain.download.LinkDownloadCoordinator>()
    val torrentPickerViewModel: TorrentSelectionViewModel =
      viewModel(
        key = "network_torrent_picker",
        factory =
          TorrentSelectionViewModel.factory(
            torrentStreamingEngine = torrentStreamingEngine,
            streamEntryRepository = streamEntryRepository,
            wyzieSearchRepository = wyzieSearchRepository,
          ),
      )
    val torrentPickerState by torrentPickerViewModel.uiState.collectAsState()
    val connections by viewModel.connections.collectAsState()
    val folderBookmarks by bookmarkPreferences.bookmarks.collectAsState()
    val connectionStatuses by viewModel.connectionStatuses.collectAsState()
    val recentLinks by viewModel.recentLinks.collectAsState()
    val allMediaGroups by viewModel.allMediaGroups.collectAsState()
    var showAddSheet by remember { mutableStateOf(false) }
    var showAddMediaDialog by remember { mutableStateOf(false) }
    var editingConnection by remember { mutableStateOf<NetworkConnection?>(null) }
    var showTorrentPicker by remember { mutableStateOf(false) }
    val navigationBarHeight = app.infinity.mpvz.ui.browser.LocalNavigationBarHeight.current
    val coroutineScope = rememberCoroutineScope()

    // yt-dlp install gate for the "paste link -> Play" flow: instead of silently installing
    // yt-dlp in the background while the player buffers on first use, we ask up front.
    var pendingYtdlpUrl by remember { mutableStateOf<String?>(null) }
    var showYtdlpInstallPrompt by remember { mutableStateOf(false) }
    var showYtdlpInstallProgress by remember { mutableStateOf(false) }
    var ytdlpInstallLastLog by remember { mutableStateOf("") }
    var ytdlpInstallError by remember { mutableStateOf<String?>(null) }
    var ytdlpInstallJob by remember { mutableStateOf<Job?>(null) }
    var linkPlaybackJob by remember { mutableStateOf<Job?>(null) }
    var pendingYtdlDownloadUrl by remember { mutableStateOf<String?>(null) }
    var showYtdlDownloadQualityDialog by remember { mutableStateOf(false) }

    fun proceedToPlay(url: String) {
      if (linkPlaybackJob?.isActive == true) return
      linkPlaybackJob =
        coroutineScope.launch {
          try {
            val extractedPlaylist =
              if (YtdlpManager.isPotentialPlaylistUrl(url)) {
                YtdlpManager.extractPlaylist(context, url, ytdlPreferences).getOrNull()
              } else {
                null
              }
            viewModel.recordSubmittedLink(url)
            if (extractedPlaylist != null) {
              YtdlpManager.playPlaylist(context, extractedPlaylist, "network_stream")
            } else {
              MediaUtils.playFile(url, context, "network_stream")
            }
          } finally {
            linkPlaybackJob = null
          }
        }
    }

    fun playLinkGatingYtdlp(url: String) {
      if (YtdlpManager.requiresYtdlp(url) && !YtdlpManager.isInstalled(context)) {
        pendingYtdlpUrl = url
        showYtdlpInstallPrompt = true
      } else {
        proceedToPlay(url)
      }
    }

    fun isReadableContentUri(source: String): Boolean {
      val uri = runCatching { android.net.Uri.parse(source) }.getOrNull() ?: return false
      if (uri.scheme?.equals("content", ignoreCase = true) != true) return true
      return runCatching {
        context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { descriptor ->
          descriptor.fileDescriptor.valid()
        } ?: false
      }.getOrDefault(false)
    }

    fun submitPastedLink(url: String) {
      val playableSource = normalizeTorrentSource(url) ?: url.trim()
      if (!isReadableContentUri(playableSource)) {
        Toast.makeText(
          context,
          "This local content link is unavailable on this device",
          Toast.LENGTH_LONG,
        ).show()
        return
      }
      if (
        ytdlPreferences.showDownloadQualityChooser.get() &&
          linkDownloadCoordinator.routeFor(playableSource) ==
            app.infinity.mpvz.domain.download.LinkDownloadCoordinator.Route.YTDLP
      ) {
        pendingYtdlDownloadUrl = playableSource
        showYtdlDownloadQualityDialog = true
      } else {
        playLinkGatingYtdlp(playableSource)
      }
    }

    LaunchedEffect(torrentPickerViewModel) {
      torrentPickerViewModel.launches.collect { request ->
        showTorrentPicker = false
        MediaUtils.playFile(
          source = request.source,
          context = context,
          launchSource = "network_torrent",
          title = request.file.name,
          torrentFileIndex = request.file.index,
          torrentPreparationId = request.preparationId,
        )
      }
    }

    var searchQuery by rememberSaveable { mutableStateOf("") }
    var isSearching by rememberSaveable { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    val filteredConnections =
      remember(connections, searchQuery) {
        if (searchQuery.isBlank()) {
          connections
        } else {
          connections.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
              it.host.contains(searchQuery, ignoreCase = true) ||
              it.protocol.displayName.contains(searchQuery, ignoreCase = true)
          }
        }
      }

    val filteredRecentLinks =
      remember(recentLinks, searchQuery) {
        recentLinks.filter { entry ->
          searchQuery.isBlank() ||
            entry.fileName.contains(searchQuery, ignoreCase = true) ||
            entry.canonicalSourceUri.contains(searchQuery, ignoreCase = true)
        }
      }

    val resolvedFolderBookmarks =
      remember(folderBookmarks, connections) {
        resolveNetworkFolderBookmarks(folderBookmarks, connections)
      }

    val filteredFolderBookmarks =
      remember(resolvedFolderBookmarks, searchQuery) {
        if (searchQuery.isBlank()) {
          resolvedFolderBookmarks
        } else {
          resolvedFolderBookmarks.filter { item ->
            item.bookmark.folderName.contains(searchQuery, ignoreCase = true) ||
              item.connection.name.contains(searchQuery, ignoreCase = true) ||
              item.bookmark.path.contains(searchQuery, ignoreCase = true)
          }
        }
      }

    val filteredMediaGroups =
      remember(allMediaGroups, searchQuery) {
        val query = searchQuery.trim()
        if (query.isEmpty()) {
          allMediaGroups
        } else {
          allMediaGroups.filter { group ->
            group.title.contains(query, ignoreCase = true) ||
              group.infoHash.orEmpty().contains(query, ignoreCase = true) ||
              group.canonicalSourceUri.contains(query, ignoreCase = true) ||
              group.overview.orEmpty().contains(query, ignoreCase = true) ||
              group.releaseYear.orEmpty().contains(query, ignoreCase = true) ||
              group.files.any { entry ->
                entry.fileName.contains(query, ignoreCase = true) ||
                  entry.filePath.orEmpty().contains(query, ignoreCase = true) ||
                  entry.fileIndex?.toString() == query
              }
          }
        }
      }

    BackHandler(enabled = isSearching) {
      isSearching = false
      searchQuery = ""
    }

    val pagerState = rememberPagerState { NetworkTab.entries.size }

    val headerContainerColor =
      if (MaterialTheme.colorScheme.background == Color.Black) Color.Black else MaterialTheme.colorScheme.surfaceContainer

    Scaffold(
      modifier = Modifier.fillMaxSize(),
      topBar = {
        Column(
          modifier =
            Modifier
              .fillMaxWidth()
              .background(headerContainerColor),
        ) {
          if (isSearching) {
            InlineSearchBar(
              query = searchQuery,
              onQueryChange = { searchQuery = it },
              onSearch = { },
              modifier =
                Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 16.dp, vertical = 8.dp),
              inputFieldModifier = Modifier.focusRequester(focusRequester),
              placeholder = {
                Text(stringResource(R.string.settings_search_title))
              },
              leadingIcon = {
                Icon(
                  imageVector = Icons.RoundedFilled.Search,
                  contentDescription = stringResource(R.string.settings_search_title),
                )
              },
              trailingIcon = {
                IconButton(
                  onClick = {
                    isSearching = false
                    searchQuery = ""
                  },
                ) {
                  Icon(
                    imageVector = Icons.RoundedFilled.Close,
                    contentDescription = stringResource(R.string.generic_cancel),
                  )
                }
              },
              shape = RoundedCornerShape(28.dp),
              tonalElevation = 6.dp,
            )
          } else {
            Box {
              BrowserTopBar(
                title = stringResource(R.string.ui_network),
                isInSelectionMode = false,
                selectedCount = 0,
                totalCount = connections.size + recentLinks.size + allMediaGroups.size + resolvedFolderBookmarks.size,
                onBackClick = null,
                onCancelSelection = { },
                onSortClick = null,
                onSearchClick = null,
                onSettingsClick = {
                  backstack.add(app.infinity.mpvz.ui.preferences.PreferencesScreen)
                },
                onDeleteClick = null,
                onRenameClick = null,
                isSingleSelection = false,
                onInfoClick = null,
                onShareClick = null,
                onPlayClick = null,
                onSelectAll = null,
                onInvertSelection = null,
                onDeselectAll = null,
                additionalActions = {
                  IconButton(
                    onClick = { backstack.add(app.infinity.mpvz.ui.downloads.DownloadsScreen) },
                    modifier = Modifier.padding(horizontal = 2.dp),
                  ) {
                    Icon(
                      imageVector = Icons.RoundedFilled.Download,
                      contentDescription = stringResource(R.string.downloads_open_downloads),
                      modifier = Modifier.size(24.dp),
                      tint = MaterialTheme.colorScheme.onSurface,
                    )
                  }
                },
              )
            }
          }

          PrimaryScrollableTabRow(
            selectedTabIndex = pagerState.currentPage.coerceIn(0, (NetworkTab.entries.size - 1).coerceAtLeast(0)),
            edgePadding = 8.dp,
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onSurface,
            divider = {},
          ) {
            NetworkTab.entries.forEachIndexed { index, tab ->
              Tab(
                selected = pagerState.currentPage == index,
                onClick = {
                  coroutineScope.launch { pagerState.animateScrollToPage(index) }
                },
                text = {
                  Text(
                    text = stringResource(tab.titleResId),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = if (pagerState.currentPage == index) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                  )
                },
              )
            }
          }
          HorizontalDivider()
        }
      },
      floatingActionButton = {
        when (pagerState.currentPage) {
          NetworkTab.LOCAL_NETWORK.ordinal -> {
            FloatingActionButton(
              onClick = { showAddSheet = true },
              modifier = Modifier.padding(bottom = navigationBarHeight),
              shape = CircleShape,
            ) {
              Icon(
                Icons.RoundedFilled.Add,
                contentDescription = stringResource(R.string.ui_add_connection),
              )
            }
          }
          NetworkTab.MEDIA.ordinal -> {
            FloatingActionButton(
              onClick = { showAddMediaDialog = true },
              modifier = Modifier.padding(bottom = navigationBarHeight),
              shape = CircleShape,
            ) {
              Icon(Icons.RoundedFilled.Add, contentDescription = "Add media")
            }
          }
        }
      },
    ) { padding ->
      Box(
        modifier =
          Modifier
            .fillMaxSize()
            .padding(padding),
      ) {
        HorizontalPager(
          state = pagerState,
          modifier =
            Modifier
              .fillMaxSize(),
          userScrollEnabled = true,
          beyondViewportPageCount = 1,
        ) { page ->
          when (NetworkTab.entries[page]) {
            NetworkTab.LOCAL_NETWORK -> {
              LocalNetworkContent(
                connections = filteredConnections,
                bookmarks = filteredFolderBookmarks,
                connectionStatuses = connectionStatuses,
                recentLinks = filteredRecentLinks,
                isPreparingLink =
                  showYtdlpInstallPrompt ||
                    showYtdlpInstallProgress ||
                    linkPlaybackJob?.isActive == true,
                onPlayLink = { url ->
                  val playableSource = normalizeTorrentSource(url) ?: url.trim()
                  if (isTorrentSource(playableSource)) {
                    showTorrentPicker = true
                    torrentPickerViewModel.open(TorrentSelectionInput(source = playableSource))
                  } else {
                    submitPastedLink(playableSource)
                  }
                },
                onPlayRecent = { entry ->
                  viewModel.recordExistingLinkPlayed(entry.stableKey)
                  MediaUtils.playFile(
                    source = entry.canonicalSourceUri,
                    context = context,
                    launchSource = "network_recent",
                    title = entry.fileName,
                  )
                },
                onSaveToMedia = { entry ->
                  val playableSource = normalizeTorrentSource(entry.canonicalSourceUri) ?: entry.canonicalSourceUri.trim()
                  if (isTorrentSource(playableSource)) {
                    showTorrentPicker = true
                    torrentPickerViewModel.open(TorrentSelectionInput(source = playableSource, title = entry.fileName))
                  } else {
                    when (linkDownloadCoordinator.enqueue(playableSource, entry.fileName)) {
                      app.infinity.mpvz.domain.download.LinkDownloadCoordinator.Route.UNSUPPORTED ->
                        android.widget.Toast
                          .makeText(context, R.string.downloads_location_invalid, android.widget.Toast.LENGTH_SHORT)
                          .show()
                      else ->
                        android.widget.Toast
                          .makeText(context, R.string.downloads_started, android.widget.Toast.LENGTH_SHORT)
                          .show()
                    }
                  }
                },
                onDeleteRecent = viewModel::deleteStreamEntry,
                showRecentLinks = false,
                onConnect = { viewModel.connect(it) },
                onDisconnect = { viewModel.disconnect(it) },
                onEdit = { editingConnection = it },
                onDelete = { viewModel.deleteConnection(it) },
                onBrowse = { conn, status ->
                  if (status?.isConnected == true) {
                    backstack.add(
                      NetworkBrowserScreen(
                        connectionId = conn.id,
                        connectionName = conn.name,
                        currentPath = "/",
                      ),
                    )
                  }
                },
                onAutoConnectChange = { conn, autoConnect ->
                  viewModel.updateConnection(conn.copy(autoConnect = autoConnect))
                },
                onOpenBookmark = { item ->
                  backstack.add(
                    NetworkBrowserScreen(
                      connectionId = item.connection.id,
                      connectionName = item.connection.name,
                      currentPath = item.bookmark.path,
                    ),
                  )
                },
                onManageBookmarks = { backstack.add(NetworkBookmarksScreen) },
              )
            }
            NetworkTab.MEDIA -> {
              MediaContent(
                mediaGroups = filteredMediaGroups,
                recentLinks = filteredRecentLinks,
                searchQuery = searchQuery,
                onPlayMedia = { entry ->
                  val playableSource = normalizeTorrentSource(entry.canonicalSourceUri) ?: entry.canonicalSourceUri.trim()
                  if (isTorrentSource(playableSource)) {
                    MediaUtils.playFile(
                      source = entry.canonicalSourceUri,
                      context = context,
                      launchSource = "network_torrent",
                      title = entry.fileName,
                      torrentFileIndex = entry.fileIndex,
                    )
                  } else {
                    viewModel.recordExistingLinkPlayed(entry.stableKey)
                    MediaUtils.playFile(
                      source = entry.canonicalSourceUri,
                      context = context,
                      launchSource = "network_media",
                      title = entry.fileName,
                    )
                  }
                },
                onDeleteMediaFile = viewModel::deleteStreamEntry,
                onDeleteMediaGroup = { viewModel.deleteMediaGroup(it) },
                onPlayRecent = { entry ->
                  viewModel.recordExistingLinkPlayed(entry.stableKey)
                  MediaUtils.playFile(source = entry.canonicalSourceUri, context = context, launchSource = "network_media", title = entry.fileName)
                },
                onDeleteRecent = viewModel::deleteStreamEntry,
                onSaveRecent = { entry ->
                  when (linkDownloadCoordinator.enqueue(entry.canonicalSourceUri, entry.fileName)) {
                    app.infinity.mpvz.domain.download.LinkDownloadCoordinator.Route.UNSUPPORTED ->
                      Toast.makeText(context, R.string.downloads_location_invalid, Toast.LENGTH_SHORT).show()
                    else -> Toast.makeText(context, R.string.downloads_started, Toast.LENGTH_SHORT).show()
                  }
                },
              )
            }
            NetworkTab.SYNC_PLAY -> {
              SyncPlayContent()
            }
          }
        }
      }

      AddConnectionSheet(
        isOpen = showAddSheet,
        onDismiss = { showAddSheet = false },
        onSave = { connection ->
          viewModel.addConnection(connection)
          showAddSheet = false
        },
      )

      YtdlpInstallPromptDialog(
        isOpen = showYtdlpInstallPrompt,
        onInstall = {
          showYtdlpInstallPrompt = false
          ytdlpInstallError = null
          ytdlpInstallLastLog = ""
          showYtdlpInstallProgress = true
          ytdlpInstallJob =
            coroutineScope.launch {
              val success =
                YtdlpManager.runInstall(context) { log ->
                  // runInstall logs from an IO dispatcher; hop back to Main before touching state.
                  coroutineScope.launch(Dispatchers.Main) {
                    ytdlpInstallLastLog = log
                  }
                }
              if (success) {
                showYtdlpInstallProgress = false
                pendingYtdlpUrl?.let { proceedToPlay(it) }
                pendingYtdlpUrl = null
              } else {
                // Leave the progress dialog open so the error is visible; Cancel dismisses it.
                ytdlpInstallError = context.getString(R.string.ytdlp_install_failed)
              }
            }
        },
        onConfigure = {
          showYtdlpInstallPrompt = false
          pendingYtdlpUrl = null
          backstack.add(YtdlpSettingsScreen)
        },
        onDismiss = {
          showYtdlpInstallPrompt = false
          pendingYtdlpUrl = null
        },
      )

      YtdlpInstallProgressDialog(
        isOpen = showYtdlpInstallProgress,
        lastLogLine = ytdlpInstallLastLog,
        error = ytdlpInstallError,
        onCancel = {
          ytdlpInstallJob?.cancel()
          ytdlpInstallJob = null
          showYtdlpInstallProgress = false
          pendingYtdlpUrl = null
        },
      )

      AddMediaDialog(
        isOpen = showAddMediaDialog,
        onDismiss = { showAddMediaDialog = false },
        onSubmit = { url ->
          val playableSource = normalizeTorrentSource(url) ?: url.trim()
          if (isTorrentSource(playableSource)) {
            showTorrentPicker = true
            torrentPickerViewModel.open(TorrentSelectionInput(source = playableSource))
          } else {
            submitPastedLink(playableSource)
          }
        },
      )

      YtdlDownloadQualityDialog(
        isOpen = showYtdlDownloadQualityDialog,
        onDismiss = {
          showYtdlDownloadQualityDialog = false
          pendingYtdlDownloadUrl = null
        },
        onDownload = { qualityHeight ->
          val url = pendingYtdlDownloadUrl ?: return@YtdlDownloadQualityDialog
          linkDownloadCoordinator.enqueue(
            url = url,
            title = app.infinity.mpvz.domain.download.LinkDownloadCoordinator.fileNameFromUrl(url),
            qualityHeight = qualityHeight,
          )
          android.widget.Toast.makeText(context, R.string.downloads_started, android.widget.Toast.LENGTH_SHORT).show()
          showYtdlDownloadQualityDialog = false
          pendingYtdlDownloadUrl = null
        },
        onPlay = {
          val url = pendingYtdlDownloadUrl ?: return@YtdlDownloadQualityDialog
          showYtdlDownloadQualityDialog = false
          pendingYtdlDownloadUrl = null
          playLinkGatingYtdlp(url)
        },
      )

      editingConnection?.let { connection ->
        EditConnectionSheet(
          connection = connection,
          isOpen = true,
          onDismiss = { editingConnection = null },
          onSave = { updatedConnection, clearPassword ->
            viewModel.updateConnection(updatedConnection, clearPassword)
            editingConnection = null
          },
        )
      }

      if (showTorrentPicker) {
        TorrentSelectionScreen(
          state = torrentPickerState,
          onBack = {
            showTorrentPicker = false
            torrentPickerViewModel.cancel()
          },
          onRetry = torrentPickerViewModel::retry,
          onSelect = torrentPickerViewModel::select,
        )
      }
    }
  }
}

@Composable
private fun YtdlDownloadQualityDialog(
  isOpen: Boolean,
  onDismiss: () -> Unit,
  onDownload: (Int) -> Unit,
  onPlay: () -> Unit,
) {
  if (!isOpen) return
  val qualityOptions = listOf(-1, 2160, 1440, 1080, 720, 480, 360)
  var selectedQuality by remember(isOpen) { mutableStateOf(-1) }
  val sheetState =
    rememberBottomSheetState(
      initialValue = SheetValue.Hidden,
      enabledValues = setOf(SheetValue.Hidden, SheetValue.Expanded),
    )
  LaunchedEffect(isOpen) {
    if (isOpen) sheetState.expand()
  }
  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
    dragHandle = { BottomSheetDefaults.DragHandle() },
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp).navigationBarsPadding(),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = stringResource(R.string.ytdlp_download_quality_title),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = "Choose the quality for this video",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        TextButton(onClick = onDismiss) { Text("Done") }
      }

      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        qualityOptions.forEach { quality ->
          val selected = selectedQuality == quality
          Surface(
            onClick = { selectedQuality = quality },
            shape = RoundedCornerShape(16.dp),
            color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
              Surface(
                shape = CircleShape,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
                modifier = Modifier.size(40.dp),
              ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                  if (selected) {
                    Icon(Icons.RoundedFilled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(20.dp))
                  } else {
                    RadioButton(selected = false, onClick = null)
                  }
                }
              }
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = if (quality < 0) "Best available" else "Up to ${quality}p",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
                  color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                )
                Text(
                  text = if (quality < 0) "Best video and audio" else "Video with audio, up to ${quality}p",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        }
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(onClick = onPlay, shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f).height(48.dp)) {
          Text(stringResource(R.string.ui_play_now))
        }
        FilledTonalButton(onClick = { onDownload(selectedQuality) }, shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f).height(48.dp)) {
          Icon(Icons.RoundedFilled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(stringResource(R.string.ytdlp_download_quality_download))
        }
      }
      Spacer(modifier = Modifier.height(12.dp))
    }
  }
}

@Composable
private fun AddMediaDialog(
  isOpen: Boolean,
  onDismiss: () -> Unit,
  onSubmit: (String) -> Unit,
) {
  if (!isOpen) return
  var inputUrl by remember { mutableStateOf("") }
  val context = LocalContext.current
  val clipboard = androidx.compose.ui.platform.LocalClipboard.current
  val coroutineScope = rememberCoroutineScope()

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
    dragHandle = { BottomSheetDefaults.DragHandle() },
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp).navigationBarsPadding(),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Text(stringResource(R.string.ui_saved_media), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
      Text(
        text = "Paste a torrent magnet link, direct video stream (HLS, MP4, MKV), or YouTube URL to save and play.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      OutlinedTextField(
        value = inputUrl,
        onValueChange = { inputUrl = it },
        label = { Text("Stream or Magnet URL") },
        placeholder = { Text("magnet:?xt=... or https://...") },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        trailingIcon = {
          if (inputUrl.isBlank()) {
            IconButton(onClick = {
              coroutineScope.launch {
                val clipData = clipboard.getClipEntry()?.clipData
                if (clipData != null && clipData.itemCount > 0) {
                  val clip = clipData.getItemAt(0).coerceToText(context)?.toString()?.trim()
                  if (!clip.isNullOrBlank()) inputUrl = clip
                }
              }
            }) { Icon(Icons.RoundedFilled.ContentPaste, contentDescription = "Paste") }
          } else {
            IconButton(onClick = { inputUrl = "" }) { Icon(Icons.RoundedFilled.Close, contentDescription = "Clear") }
          }
        },
      )
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        TextButton(onClick = onDismiss) { Text(stringResource(R.string.generic_cancel)) }
        Spacer(Modifier.width(8.dp))
        Button(
          onClick = { if (inputUrl.isNotBlank()) { onSubmit(inputUrl.trim()); onDismiss() } },
          enabled = inputUrl.isNotBlank(),
        ) { Text(stringResource(R.string.ui_play_now)) }
      }
      Spacer(Modifier.navigationBarsPadding())
    }
  }
}

@Composable
private fun LocalNetworkContent(
  connections: List<NetworkConnection>,
  bookmarks: List<ResolvedNetworkFolderBookmark>,
  connectionStatuses: Map<Long, ConnectionStatus>,
  recentLinks: List<NetworkStreamEntryEntity>,
  isPreparingLink: Boolean,
  onPlayLink: (String) -> Unit,
  onPlayRecent: (NetworkStreamEntryEntity) -> Unit,
  onSaveToMedia: (NetworkStreamEntryEntity) -> Unit,
  onDeleteRecent: (String) -> Unit,
  showRecentLinks: Boolean = true,
  onConnect: (NetworkConnection) -> Unit,
  onDisconnect: (NetworkConnection) -> Unit,
  onEdit: (NetworkConnection) -> Unit,
  onDelete: (NetworkConnection) -> Unit,
  onBrowse: (NetworkConnection, ConnectionStatus?) -> Unit,
  onAutoConnectChange: (NetworkConnection, Boolean) -> Unit,
  onOpenBookmark: (ResolvedNetworkFolderBookmark) -> Unit,
  onManageBookmarks: () -> Unit,
) {
  val navBarHeight = app.infinity.mpvz.ui.browser.LocalNavigationBarHeight.current.takeIf { it > 0.dp } ?: 88.dp
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 16.dp, top = 12.dp, end = 16.dp, bottom = navBarHeight + 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // 1. Stream Link Section (URL input & recent streams with Save to Media action)
    item {
      StreamLinkSection(
        recentLinks = recentLinks,
        isPreparing = isPreparingLink,
        onPlayLink = onPlayLink,
        onPlayRecent = onPlayRecent,
        onSaveToTorrent = onSaveToMedia,
        onDeleteRecent = onDeleteRecent,
        showRecentLinks = showRecentLinks,
      )
    }

    if (bookmarks.isNotEmpty()) {
      item {
        NetworkBookmarkSection(
          bookmarks = bookmarks,
          onOpen = onOpenBookmark,
          onManage = onManageBookmarks,
        )
      }
    }

    // 2. Saved Network Connections Section
    if (connections.isEmpty()) {
      item {
        EmptyStateCard(
          icon = Icons.RoundedFilled.SignalWifiStatusbarConnectedNoInternet4,
          title = stringResource(R.string.ui_no_network_connections),
          subtitle = stringResource(R.string.ui_add_smb_ftp_or_webdav_connections_to_browse_network_files),
        )
      }
    } else {
      items(connections, key = { it.id }) { connection ->
        val status = connectionStatuses[connection.id]
        NetworkConnectionCard(
          connection = connection,
          onConnect = { onConnect(it) },
          onDisconnect = { onDisconnect(it) },
          onEdit = { onEdit(it) },
          onDelete = { onDelete(it) },
          onBrowse = { onBrowse(it, status) },
          onAutoConnectChange = { conn, autoConnect -> onAutoConnectChange(conn, autoConnect) },
          isConnected = status?.isConnected ?: false,
          isConnecting = status?.isConnecting ?: false,
          error = status?.error,
          modifier = Modifier.padding(bottom = 0.dp),
        )
      }
    }
  }
}

@Composable
private fun SyncPlayContent() {
  SyncplayPanel()
}

@Composable
private fun MediaContent(
  mediaGroups: List<MediaStreamGroup>,
  recentLinks: List<NetworkStreamEntryEntity>,
  searchQuery: String,
  onPlayMedia: (NetworkStreamEntryEntity) -> Unit,
  onDeleteMediaFile: (String) -> Unit,
  onDeleteMediaGroup: (MediaStreamGroup) -> Unit,
  onPlayRecent: (NetworkStreamEntryEntity) -> Unit,
  onDeleteRecent: (String) -> Unit,
  onSaveRecent: (NetworkStreamEntryEntity) -> Unit,
) {
  val context = LocalContext.current
  val viewedPreferences =
    remember(context) {
      context.getSharedPreferences(VIEWED_TORRENT_FILES_PREFS, Context.MODE_PRIVATE)
    }

  var selectedDetailGroup by remember { mutableStateOf<MediaStreamGroup?>(null) }
  val navBarHeight = app.infinity.mpvz.ui.browser.LocalNavigationBarHeight.current.takeIf { it > 0.dp } ?: 88.dp

  val heroGroups =
    remember(mediaGroups) {
      mediaGroups.filter { !it.backdropUrl.isNullOrBlank() || !it.posterUrl.isNullOrBlank() }
        .ifEmpty { mediaGroups }
    }

  val recentViewedFiles =
    remember(mediaGroups) {
      mediaGroups.flatMap { group ->
        val infoHash = group.infoHash
        val viewed = if (infoHash != null) loadViewedFileIndices(viewedPreferences, infoHash) else emptySet()
        group.files.filter { it.fileIndex in viewed || group.groupType != MediaGroupType.TORRENT }
      }.sortedByDescending { it.updatedAt }
        .distinctBy { it.stableKey }
    }

  val onPlayWithHistory: (NetworkStreamEntryEntity, String?) -> Unit = { file, infoHash ->
    val fileIdx = file.fileIndex ?: 0
    if (infoHash != null) {
      val viewed = loadViewedFileIndices(viewedPreferences, infoHash)
      saveViewedFileIndices(viewedPreferences, infoHash, viewed + fileIdx)
    }
    onPlayMedia(file)
  }

  Box(modifier = Modifier.fillMaxSize()) {
    if (mediaGroups.isEmpty() && recentLinks.isEmpty()) {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = navBarHeight + 16.dp),
      ) {
        item {
          EmptyStateCard(
            icon = Icons.RoundedFilled.Movie,
            title = stringResource(R.string.ui_no_saved_media_title),
            subtitle = stringResource(R.string.ui_no_saved_media_description),
          )
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 16.dp, bottom = navBarHeight + 24.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
      ) {
        if (recentLinks.isNotEmpty()) {
          item(key = "saved_stream_links") {
            SavedStreamLinksSection(
              links = recentLinks,
              onPlay = onPlayRecent,
              onDownload = onSaveRecent,
              onDelete = onDeleteRecent,
            )
          }
        }
        // 1. Featured Hero Carousel Banner
        if (heroGroups.isNotEmpty() && searchQuery.isBlank()) {
          item {
            TorrentHeroBanner(
              groups = heroGroups,
              onPlay = { group ->
                val infoHash = group.infoHash
                val viewed = if (infoHash != null) loadViewedFileIndices(viewedPreferences, infoHash) else emptySet()
                val targetFile = group.files.firstOrNull { it.fileIndex !in viewed } ?: group.files.firstOrNull()
                if (targetFile != null) {
                  onPlayWithHistory(targetFile, infoHash)
                }
              },
              onDetails = { group -> selectedDetailGroup = group },
            )
          }
        }

        // 2. Continue Watching (Recently Played Saved Links)
        if (recentViewedFiles.isNotEmpty() && searchQuery.isBlank()) {
          item {
            Column(
              modifier = Modifier.fillMaxWidth(),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              TorrentSectionHeader(
                title = "Continue Watching",
                subtitle = "Resume your recent streams and torrents",
              )
              androidx.compose.foundation.lazy.LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
              ) {
                items(recentViewedFiles, key = { it.stableKey }) { entry ->
                  TorrentResumeCard(
                    entry = entry,
                    onClick = { onPlayWithHistory(entry, entry.infoHash) },
                    onLongClick = {
                      val group = mediaGroups.find { it.infoHash == entry.infoHash || it.canonicalSourceUri == entry.canonicalSourceUri }
                      if (group != null) selectedDetailGroup = group
                    },
                  )
                }
              }
            }
          }
        }

        // 3. Saved Links Section Header
        item {
          TorrentSectionHeader(
            title = if (searchQuery.isNotBlank()) "Search Results (${mediaGroups.size})" else "Saved Links (${mediaGroups.size})",
            subtitle = if (searchQuery.isNotBlank()) null else "Stream instantly with high-speed hardware acceleration",
          )
        }

        // 4. Saved Links Posters
        if (mediaGroups.isNotEmpty()) {
          item {
            androidx.compose.foundation.lazy.LazyRow(
              horizontalArrangement = Arrangement.spacedBy(12.dp),
              contentPadding = PaddingValues(horizontal = 16.dp),
            ) {
              items(mediaGroups, key = { it.id }) { group ->
                TorrentPosterCard(
                  group = group,
                  onClick = { selectedDetailGroup = group },
                  onLongClick = { selectedDetailGroup = group },
                )
              }
            }
          }
        }
      }
    }

    // 5. Cinematic Media Detail Sheet
    selectedDetailGroup?.let { group ->
      val infoHash = group.infoHash
      val viewed =
        remember(infoHash) {
          if (infoHash != null) loadViewedFileIndices(viewedPreferences, infoHash) else emptySet()
        }

      TorrentDetailSheet(
        group = group,
        viewedFileIndices = viewed,
        onDismiss = { selectedDetailGroup = null },
        onPlayFile = { file ->
          onPlayWithHistory(file, group.infoHash)
        },
        onDeleteGroup = { grp ->
          onDeleteMediaGroup(grp)
          selectedDetailGroup = null
        },
        onDeleteFile = onDeleteMediaFile,
      )
    }
  }
}

@Composable
private fun EmptyStateCard(
  icon: AppIcon,
  title: String,
  subtitle: String,
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors =
      CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceContainer,
      ),
    shape = RoundedCornerShape(20.dp),
  ) {
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(28.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        modifier = Modifier.size(52.dp),
        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
      )
      Spacer(modifier = Modifier.height(16.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
      )
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
      )
    }
  }
}

@Composable
private fun SavedStreamLinksSection(
  links: List<NetworkStreamEntryEntity>,
  onPlay: (NetworkStreamEntryEntity) -> Unit,
  onDownload: (NetworkStreamEntryEntity) -> Unit,
  onDelete: (String) -> Unit,
) {
  Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Text(
      text = "Saved Stream Links",
      style = MaterialTheme.typography.titleLarge,
      fontWeight = FontWeight.Bold,
      modifier = Modifier.padding(horizontal = 16.dp),
    )
    androidx.compose.foundation.lazy.LazyRow(
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(horizontal = 16.dp),
    ) {
      items(links, key = { "saved_${it.stableKey}" }) { entry ->
        SavedStreamLinkCard(entry = entry, onPlay = { onPlay(entry) }, onDownload = { onDownload(entry) }, onDelete = { onDelete(entry.stableKey) })
      }
    }
  }
}

@Composable
private fun SavedStreamLinkCard(
  entry: NetworkStreamEntryEntity,
  onPlay: () -> Unit,
  onDownload: () -> Unit,
  onDelete: () -> Unit,
) {
  val title = remember(entry.fileName, entry.canonicalSourceUri) {
    MediaInfoParser.parseStreamTitle(entry.canonicalSourceUri, entry.fileName)
  }
  val thumbnail = streamThumbnailUrl(entry.canonicalSourceUri)
  Card(
    modifier = Modifier.width(210.dp),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      Box(
        modifier = Modifier.fillMaxWidth().height(118.dp).background(MaterialTheme.colorScheme.surfaceContainerHighest),
        contentAlignment = Alignment.Center,
      ) {
        if (thumbnail != null) {
          RemoteImage(url = thumbnail, contentDescription = title, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
          Icon(Icons.RoundedFilled.Link, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(34.dp))
        }
      }
      Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
      Row(modifier = Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, bottom = 4.dp), horizontalArrangement = Arrangement.End) {
        IconButton(onClick = onDownload, modifier = Modifier.size(36.dp)) { Icon(Icons.RoundedFilled.Download, contentDescription = stringResource(R.string.downloads_download)) }
        IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) { Icon(Icons.RoundedFilled.Delete, contentDescription = stringResource(R.string.delete)) }
        IconButton(onClick = onPlay, modifier = Modifier.size(36.dp)) { Icon(Icons.RoundedFilled.PlayArrow, contentDescription = stringResource(R.string.ui_play), tint = MaterialTheme.colorScheme.primary) }
      }
    }
  }
}

private fun streamThumbnailUrl(url: String): String? {
  val videoId = Regex("(?:youtu\\.be/|youtube\\.com/(?:watch\\?v=|shorts/|embed/))([^?&/]+)").find(url)?.groupValues?.getOrNull(1)
  return videoId?.let { "https://i.ytimg.com/vi/$it/hqdefault.jpg" }
}

@Composable
private fun StreamLinkSection(
  recentLinks: List<NetworkStreamEntryEntity>,
  isPreparing: Boolean,
  onPlayLink: (String) -> Unit,
  onPlayRecent: (NetworkStreamEntryEntity) -> Unit,
  onSaveToTorrent: (NetworkStreamEntryEntity) -> Unit,
  onDeleteRecent: (String) -> Unit,
  showRecentLinks: Boolean = true,
) {
  val context = LocalContext.current
  val keyboardController = LocalSoftwareKeyboardController.current
  val playStreamContentDescription = stringResource(R.string.ui_play_stream)
  var linkUrl by rememberSaveable { mutableStateOf("") }

  fun pasteFromClipboard() {
    val clipboardManager =
      context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
    val clipData = clipboardManager?.primaryClip
    if (clipData != null && clipData.itemCount > 0) {
      val text =
        clipData
          .getItemAt(0)
          .text
          ?.toString()
          ?.trim()
          .orEmpty()
      if (text.isNotBlank()) {
        linkUrl = SharedUrlExtractor.normalizeInput(text)
      }
    }
  }

  fun playCurrentLink() {
    val sanitizedUrl = SharedUrlExtractor.normalizeInput(linkUrl)
    if (sanitizedUrl.isBlank()) return

    keyboardController?.hide()
    onPlayLink(sanitizedUrl)
    linkUrl = ""
  }

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    // 1. Stream URL Input Box
    Card(
      modifier = Modifier.fillMaxWidth(),
      colors =
        CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surfaceContainer,
        ),
      shape = RoundedCornerShape(16.dp),
    ) {
      Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .padding(4.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        OutlinedTextField(
          value = linkUrl,
          onValueChange = { linkUrl = it },
          enabled = !isPreparing,
          modifier = Modifier.weight(1f),
          placeholder = {
            Text(
              text = stringResource(R.string.ui_enter_stream_url),
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            )
          },
          leadingIcon = {
            Icon(
              imageVector = Icons.RoundedFilled.Link,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
              modifier = Modifier.size(20.dp),
            )
          },
          trailingIcon = {
            Row(
              verticalAlignment = Alignment.CenterVertically,
            ) {
              IconButton(onClick = { pasteFromClipboard() }, enabled = !isPreparing) {
                Icon(
                  imageVector = Icons.RoundedFilled.ContentPaste,
                  contentDescription = stringResource(R.string.ui_paste_stream_url),
                  modifier = Modifier.size(18.dp),
                )
              }
              if (linkUrl.isNotBlank()) {
                IconButton(onClick = { linkUrl = "" }, enabled = !isPreparing) {
                  Icon(
                    imageVector = Icons.RoundedFilled.Close,
                    contentDescription = stringResource(R.string.ui_clear_stream_url),
                    modifier = Modifier.size(18.dp),
                  )
                }
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
              unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
              focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
              unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
            ),
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
          keyboardActions =
            KeyboardActions(
              onGo = { playCurrentLink() },
            ),
        )
        Spacer(modifier = Modifier.size(6.dp))
        Button(
          onClick = { playCurrentLink() },
          enabled = linkUrl.isNotBlank() && !isPreparing,
          contentPadding = PaddingValues(12.dp),
          shape = RoundedCornerShape(14.dp),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.primary,
            ),
          modifier =
            Modifier.semantics {
              contentDescription = playStreamContentDescription
            },
        ) {
          if (isPreparing) {
            CircularProgressIndicator(
              modifier = Modifier.size(20.dp),
              strokeWidth = 2.dp,
            )
          } else {
            Icon(
              imageVector = Icons.RoundedFilled.PlayArrow,
              contentDescription = null,
              modifier = Modifier.size(20.dp),
            )
          }
        }
      }
    }

    // 2. Top 3 Recent Stream Links with Quick Autofill & Torrent Save
    val topRecent = remember(recentLinks) { recentLinks.take(3) }
    if (showRecentLinks && topRecent.isNotEmpty()) {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Icon(
            imageVector = Icons.RoundedFilled.Link,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(14.dp),
          )
          Text(
            text = stringResource(R.string.ui_recent_streams),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
          )
        }

        topRecent.forEach { entry ->
          Surface(
            modifier =
              Modifier
                .fillMaxWidth()
                .clickable {
                  linkUrl = entry.canonicalSourceUri
                },
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceContainerLow,
          ) {
            Row(
              modifier = Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Icon(
                imageVector = Icons.RoundedFilled.Link,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp),
              )
              Column(modifier = Modifier.weight(1f)) {
                val displayTitle =
                  remember(entry.fileName, entry.canonicalSourceUri) {
                    MediaInfoParser.parseStreamTitle(entry.canonicalSourceUri, entry.fileName)
                  }
                Text(
                  text = displayTitle,
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Medium,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Text(
                  text = entry.canonicalSourceUri,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
              IconButton(
                onClick = { onSaveToTorrent(entry) },
                modifier = Modifier.size(32.dp),
              ) {
                Icon(
                  imageVector = Icons.RoundedFilled.Download,
                  contentDescription = stringResource(R.string.downloads_download),
                  tint = MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.size(18.dp),
                )
              }
              IconButton(
                onClick = { onDeleteRecent(entry.stableKey) },
                modifier = Modifier.size(32.dp),
              ) {
                Icon(
                  imageVector = Icons.RoundedFilled.Delete,
                  contentDescription = stringResource(R.string.delete),
                  tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                  modifier = Modifier.size(16.dp),
                )
              }
              IconButton(
                onClick = { onPlayRecent(entry) },
                modifier = Modifier.size(32.dp),
              ) {
                Icon(
                  imageVector = Icons.RoundedFilled.PlayArrow,
                  contentDescription = stringResource(R.string.ui_play),
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(20.dp),
                )
              }
            }
          }
        }
      }
    }
  }
}

private fun loadViewedFileIndices(
  preferences: SharedPreferences,
  infoHash: String,
): Set<Int> =
  preferences
    .getStringSet(infoHash, emptySet())
    .orEmpty()
    .mapNotNull(String::toIntOrNull)
    .toSet()

private fun saveViewedFileIndices(
  preferences: SharedPreferences,
  infoHash: String,
  indices: Set<Int>,
) {
  preferences
    .edit()
    .putStringSet(infoHash, indices.map(Int::toString).toSet())
    .apply()
}
