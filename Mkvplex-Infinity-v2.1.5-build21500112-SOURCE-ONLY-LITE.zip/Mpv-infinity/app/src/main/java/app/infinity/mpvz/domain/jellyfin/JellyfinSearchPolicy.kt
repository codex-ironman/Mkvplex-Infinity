/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.domain.jellyfin

object JellyfinSearchPolicy {
  fun itemTypes(category: JellyfinSearchCategory, musicLibrary: Boolean = false): String = when (category) {
    JellyfinSearchCategory.ALL -> if (musicLibrary) "Audio,MusicAlbum,MusicArtist" else "Movie,Series,Episode"
    JellyfinSearchCategory.MOVIES -> "Movie"
    JellyfinSearchCategory.SHOWS -> "Series"
    JellyfinSearchCategory.EPISODES -> "Episode"
  }

  data class Page(val items: List<JellyfinItem>, val nextOffset: Int, val hasMore: Boolean)

  fun page(previous: List<JellyfinItem>, incoming: JellyfinQueryResult, offset: Int): Page {
    val next = offset + incoming.items.size
    return Page((previous + incoming.items).distinctBy { it.id }, next,
      incoming.items.isNotEmpty() && next < incoming.totalRecordCount)
  }

  data class Scope(val serverId: Long?, val libraryId: String?, val query: String,
    val category: JellyfinSearchCategory? = null, val musicOnly: Boolean = false)

  /** Both the request generation and its visible destination must still match. */
  class Requests {
    data class Ticket internal constructor(val generation: Long, val scope: Scope)
    private var generation = 0L
    private fun normalized(scope: Scope) = scope.copy(query = scope.query.takeUnless { it.isBlank() }.orEmpty())

    @Synchronized fun begin(scope: Scope): Ticket = Ticket(++generation, normalized(scope))
    @Synchronized fun invalidate() { generation++ }
    @Synchronized fun accepts(ticket: Ticket, scope: Scope): Boolean =
      ticket.generation == generation && ticket.scope == normalized(scope)
  }
}
