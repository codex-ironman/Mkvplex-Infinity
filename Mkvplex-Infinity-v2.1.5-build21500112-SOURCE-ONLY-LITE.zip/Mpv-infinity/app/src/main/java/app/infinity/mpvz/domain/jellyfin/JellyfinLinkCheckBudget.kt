/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.domain.jellyfin

/** One chooser's total test-attempt budget, independent of fetching and probe concurrency. */
class JellyfinLinkCheckBudget(private val maxChecks: Int) {
  private val scheduled = linkedSetOf<String>()

  fun select(sourceIds: List<String>): Set<String> = sourceIds.filterTo(linkedSetOf()) { id ->
    id !in scheduled &&
      (maxChecks !in 1..JellyfinLinkPolicy.MAX_LINKS || scheduled.size < maxChecks) &&
      scheduled.add(id)
  }
}
