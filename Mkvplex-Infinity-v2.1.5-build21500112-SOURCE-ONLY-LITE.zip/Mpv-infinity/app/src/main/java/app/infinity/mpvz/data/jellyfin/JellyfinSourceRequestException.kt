/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.data.jellyfin

import java.io.IOException

/** Safe structured failures: never expose a response body, URL or account token. */
internal class JellyfinSourceRequestException(
  val status: Int? = null,
  val serverCode: String? = null,
  val retryAfterMillis: Long? = null,
) : IOException(if (status != null) "Unable to load links: HTTP $status" else "No playable links were returned by the server") {
  val canRetry: Boolean get() = when {
    retryAfterMillis != null && retryAfterMillis > 5_000 -> false
    status != null -> status in setOf(408, 425, 429, 500, 502, 503, 504, 520, 521, 522, 523, 524)
    else -> serverCode == null || serverCode == "NoCompatibleStream"
  }
}
