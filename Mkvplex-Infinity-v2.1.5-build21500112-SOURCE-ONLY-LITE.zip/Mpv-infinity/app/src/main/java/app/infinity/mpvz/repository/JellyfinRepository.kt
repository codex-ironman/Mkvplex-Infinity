/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.repository

import app.infinity.mpvz.data.jellyfin.JellyfinClient
import app.infinity.mpvz.database.dao.JellyfinServerDao
import app.infinity.mpvz.database.entities.JellyfinServerEntity
import app.infinity.mpvz.domain.jellyfin.JellyfinAuthResult
import app.infinity.mpvz.domain.jellyfin.JellyfinItem
import app.infinity.mpvz.domain.jellyfin.JellyfinMediaSource
import app.infinity.mpvz.data.jellyfin.JellyfinSourceLoader
import app.infinity.mpvz.data.jellyfin.JellyfinSourceUpdate
import app.infinity.mpvz.domain.jellyfin.MediaServerType
import app.infinity.mpvz.domain.jellyfin.JellyfinServer
import app.infinity.mpvz.domain.jellyfin.JellyfinUser
import app.infinity.mpvz.utils.media.PlaybackSubtitleTrack
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class JellyfinRepository(
  private val dao: JellyfinServerDao,
  private val client: JellyfinClient,
) {
  private val embyClient = client.forServerType(MediaServerType.EMBY)

  private fun clientFor(type: MediaServerType): JellyfinClient =
    if (type == MediaServerType.EMBY) embyClient else client

  private fun clientFor(server: JellyfinServer): JellyfinClient = clientFor(server.serverType)

  val allServers: Flow<List<JellyfinServer>> =
    dao.getAllServers().map { list -> list.map { it.toDomain() } }

  suspend fun getServerById(id: Long): JellyfinServer? =
    dao.getServerById(id)?.toDomain()

  suspend fun saveServer(server: JellyfinServer): Long =
    dao.insert(JellyfinServerEntity.fromDomain(server))

  suspend fun updateServer(server: JellyfinServer) =
    dao.update(JellyfinServerEntity.fromDomain(server))

  suspend fun deleteServer(server: JellyfinServer) {
    clientFor(server).clearSourceCache(server.serverUrl, server.userId, server.accessToken)
    dao.delete(JellyfinServerEntity.fromDomain(server))
  }

  suspend fun authenticate(
    serverUrl: String,
    username: String,
    password: String,
    serverType: MediaServerType = MediaServerType.JELLYFIN,
  ): Result<JellyfinAuthResult> =
    clientFor(serverType).authenticate(serverUrl, username, password)

  suspend fun validateToken(
    serverUrl: String,
    token: String,
  ): Result<JellyfinUser> =
    client.validateToken(serverUrl, token)

  suspend fun getLibraries(server: JellyfinServer): Result<List<JellyfinItem>> =
    clientFor(server).getUserLibraries(server.serverUrl, server.userId, server.accessToken)

  suspend fun getResumeItems(
    server: JellyfinServer,
    limit: Int = 16,
  ): Result<List<JellyfinItem>> =
    clientFor(server).getResumeItems(server.serverUrl, server.userId, server.accessToken, limit)

  suspend fun getLatestMedia(
    server: JellyfinServer,
    parentId: String? = null,
    limit: Int = 16,
    groupItems: Boolean = true,
  ): Result<List<JellyfinItem>> =
    clientFor(server).getLatestMedia(server.serverUrl, server.userId, parentId, limit, server.accessToken, groupItems)

  suspend fun getSuggestions(
    server: JellyfinServer,
    limit: Int = 16,
  ): Result<List<JellyfinItem>> =
    clientFor(server).getSuggestions(server.serverUrl, server.userId, limit, server.accessToken)

  suspend fun getSimilarItems(
    server: JellyfinServer,
    itemId: String,
    limit: Int = 12,
  ): Result<List<JellyfinItem>> =
    clientFor(server).getSimilarItems(server.serverUrl, server.userId, itemId, limit, server.accessToken)

  suspend fun getItem(
    server: JellyfinServer,
    itemId: String,
    includeMediaSources: Boolean = true,
  ): Result<JellyfinItem> =
    clientFor(server).getItem(server.serverUrl, server.userId, itemId, server.accessToken, includeMediaSources)

  suspend fun deleteItem(
    server: JellyfinServer,
    itemId: String,
  ): Result<Unit> =
    clientFor(server).deleteItem(server.serverUrl, itemId, server.accessToken)

  suspend fun getPerson(
    server: JellyfinServer,
    personName: String,
  ): Result<JellyfinItem> =
    clientFor(server).getPerson(server.serverUrl, server.userId, personName, server.accessToken)

  suspend fun getPersonMedia(
    server: JellyfinServer,
    personId: String? = null,
    personName: String? = null,
    limit: Int = 100,
  ): Result<List<JellyfinItem>> =
    clientFor(server).getPersonMedia(server.serverUrl, server.userId, personId, personName, server.accessToken, limit)

  suspend fun getItems(
    server: JellyfinServer,
    parentId: String? = null,
    artistIds: String? = null,
    searchTerm: String? = null,
    sortBy: app.infinity.mpvz.domain.jellyfin.JellyfinSortBy = app.infinity.mpvz.domain.jellyfin.JellyfinSortBy.NAME,
    sortOrder: app.infinity.mpvz.domain.jellyfin.JellyfinSortOrder = app.infinity.mpvz.domain.jellyfin.JellyfinSortOrder.ASCENDING,
    isPlayed: Boolean? = null,
    isFavorite: Boolean? = null,
    genres: String? = null,
    includeItemTypes: String? = null,
    startIndex: Int = 0,
    limit: Int = 100,
    summaryOnly: Boolean = false,
  ): Result<app.infinity.mpvz.domain.jellyfin.JellyfinQueryResult> =
    clientFor(server).getItems(
      serverUrl = server.serverUrl,
      userId = server.userId,
      parentId = parentId,
      artistIds = artistIds,
      searchTerm = searchTerm,
      sortBy = sortBy,
      sortOrder = sortOrder,
      isPlayed = isPlayed,
      isFavorite = isFavorite,
      genres = genres,
      includeItemTypes = includeItemTypes,
      startIndex = startIndex,
      limit = limit,
      token = server.accessToken,
      summaryOnly = summaryOnly,
    )

  suspend fun getArtists(
    server: JellyfinServer,
    parentId: String? = null,
    sortBy: app.infinity.mpvz.domain.jellyfin.JellyfinSortBy = app.infinity.mpvz.domain.jellyfin.JellyfinSortBy.NAME,
    sortOrder: app.infinity.mpvz.domain.jellyfin.JellyfinSortOrder = app.infinity.mpvz.domain.jellyfin.JellyfinSortOrder.ASCENDING,
    startIndex: Int = 0,
    limit: Int = 500,
    albumArtistsOnly: Boolean = false,
  ): Result<app.infinity.mpvz.domain.jellyfin.JellyfinQueryResult> =
    clientFor(server).getArtists(
      serverUrl = server.serverUrl,
      userId = server.userId,
      parentId = parentId,
      sortBy = sortBy,
      sortOrder = sortOrder,
      startIndex = startIndex,
      limit = limit,
      token = server.accessToken,
      albumArtistsOnly = albumArtistsOnly,
    )

  suspend fun getGenres(
    server: JellyfinServer,
    parentId: String,
  ): Result<List<String>> =
    clientFor(server).getGenres(
      serverUrl = server.serverUrl,
      userId = server.userId,
      parentId = parentId,
      token = server.accessToken,
    )

  suspend fun getSeasons(
    server: JellyfinServer,
    seriesId: String,
  ): Result<List<JellyfinItem>> =
    clientFor(server).getSeasons(
      serverUrl = server.serverUrl,
      userId = server.userId,
      seriesId = seriesId,
      token = server.accessToken,
    )

  suspend fun getEpisodes(
    server: JellyfinServer,
    seriesId: String,
    seasonId: String?,
    unplayedOnly: Boolean = false,
    limit: Int? = null,
  ): Result<List<JellyfinItem>> =
    clientFor(server).getEpisodes(
      serverUrl = server.serverUrl,
      userId = server.userId,
      seriesId = seriesId,
      seasonId = seasonId,
      token = server.accessToken,
      unplayedOnly = unplayedOnly,
      limit = limit,
    )

  suspend fun getSubtitleTracks(
    server: JellyfinServer,
    itemId: String,
    mediaSource: JellyfinMediaSource? = null,
  ): Result<List<PlaybackSubtitleTrack>> =
    clientFor(server).getSubtitleTracks(
      serverUrl = server.serverUrl,
      token = server.accessToken,
      userId = server.userId,
      itemId = itemId,
      mediaSource = mediaSource,
    )

  suspend fun getMediaSources(server: JellyfinServer, itemId: String): Result<List<JellyfinMediaSource>> =
    clientFor(server).getMediaSources(server.serverUrl, server.accessToken, server.userId, itemId)
  suspend fun getPlaybackSources(server: JellyfinServer, itemId: String): Result<List<JellyfinMediaSource>> =
    clientFor(server).getPlaybackSources(server.serverUrl, server.userId, itemId, server.accessToken)

  fun cachedSources(server: JellyfinServer, itemId: String): List<JellyfinMediaSource> =
    clientFor(server).cachedItemSources(server.serverUrl, server.userId, itemId, server.accessToken)

  suspend fun prefetchSources(server: JellyfinServer, itemId: String): Result<List<JellyfinMediaSource>> =
    clientFor(server).getItemSources(server.serverUrl, server.userId, itemId, server.accessToken)

  fun observePlaybackSources(
    server: JellyfinServer,
    itemId: String,
    initialSources: List<JellyfinMediaSource>,
    maxSources: Int = 0,
    forceRefresh: Boolean = false,
  ): Flow<JellyfinSourceUpdate> = JellyfinSourceLoader.load(
    initialSources,
    maxSources = maxSources,
    metadataHeadStartMillis = 750,
    metadata = { fresh -> clientFor(server).getItemSources(server.serverUrl, server.userId, itemId, server.accessToken, forceRefresh || fresh) },
    playback = { getPlaybackSources(server, itemId) },
  )

  suspend fun checkStream(server: JellyfinServer, item: JellyfinItem, source: JellyfinMediaSource) =
    clientFor(server).checkStream(getStreamUrl(server, item, source.id), server.accessToken)

  fun getStreamUrl(
    server: JellyfinServer,
    item: JellyfinItem,
    mediaSourceId: String? = null,
  ): String =
    clientFor(server).getStreamUrl(
      serverUrl = server.serverUrl,
      itemId = item.id,
      token = server.accessToken,
      isAudio = item.isAudio,
      mediaSourceId = mediaSourceId,
    )

  fun getImageUrl(
    server: JellyfinServer,
    item: JellyfinItem,
    maxWidth: Int = 400,
  ): String {
    val useSeriesArtwork =
      item.type == "Episode" &&
        !item.seriesId.isNullOrBlank() &&
        !item.seriesPrimaryImageTag.isNullOrBlank()
    val targetItemId = when {
      useSeriesArtwork -> item.seriesId.orEmpty()
      item.primaryImageTag.isNullOrBlank() && !item.albumId.isNullOrBlank() && !item.albumPrimaryImageTag.isNullOrBlank() -> item.albumId
      else -> item.id
    }
    val targetTag = if (useSeriesArtwork) item.seriesPrimaryImageTag else item.primaryImageTag ?: item.albumPrimaryImageTag
    return clientFor(server).getImageUrl(
      serverUrl = server.serverUrl,
      itemId = targetItemId,
      imageTag = targetTag,
      maxWidth = maxWidth,
      token = server.accessToken,
    )
  }

  fun getBackdropUrl(
    server: JellyfinServer,
    item: JellyfinItem,
    maxWidth: Int = 1280,
  ): String =
    clientFor(server).getBackdropUrl(
      serverUrl = server.serverUrl,
      itemId = item.id,
      imageTag = item.backdropImageTag,
      maxWidth = maxWidth,
      token = server.accessToken,
    )

  suspend fun reportPlaybackStart(
    serverUrl: String,
    token: String,
    itemId: String,
    positionTicks: Long,
    mediaSourceId: String? = null,
    serverType: MediaServerType = MediaServerType.JELLYFIN,
  ) = clientFor(serverType).reportPlaybackStart(serverUrl, token, itemId, positionTicks, mediaSourceId)

  suspend fun reportPlaybackProgress(
    serverUrl: String,
    token: String,
    itemId: String,
    positionTicks: Long,
    isPaused: Boolean = false,
    serverType: MediaServerType = MediaServerType.JELLYFIN,
  ) = clientFor(serverType).reportPlaybackProgress(serverUrl, token, itemId, positionTicks, isPaused)

  suspend fun reportPlaybackStopped(
    serverUrl: String,
    token: String,
    itemId: String,
    positionTicks: Long,
    serverType: MediaServerType = MediaServerType.JELLYFIN,
  ) = clientFor(serverType).reportPlaybackStopped(serverUrl, token, itemId, positionTicks)

  suspend fun markPlayed(
    server: JellyfinServer,
    item: JellyfinItem,
  ): Result<Unit> =
    clientFor(server).markPlayed(
      serverUrl = server.serverUrl,
      userId = server.userId,
      itemId = item.id,
      token = server.accessToken,
    )

  suspend fun markUnplayed(
    server: JellyfinServer,
    item: JellyfinItem,
  ): Result<Unit> =
    clientFor(server).markUnplayed(
      serverUrl = server.serverUrl,
      userId = server.userId,
      itemId = item.id,
      token = server.accessToken,
    )

  suspend fun toggleFavorite(
    server: JellyfinServer,
    item: JellyfinItem,
    isFavorite: Boolean,
  ): Result<Unit> =
    clientFor(server).toggleFavorite(
      serverUrl = server.serverUrl,
      userId = server.userId,
      itemId = item.id,
      isFavorite = isFavorite,
      token = server.accessToken,
    )

  suspend fun toggleFavorite(
    server: JellyfinServer,
    itemId: String,
    isFavorite: Boolean,
  ): Result<Unit> =
    clientFor(server).toggleFavorite(
      serverUrl = server.serverUrl,
      userId = server.userId,
      itemId = itemId,
      isFavorite = isFavorite,
      token = server.accessToken,
    )

  suspend fun createPlaylist(
    server: JellyfinServer,
    name: String,
    itemIds: List<String> = emptyList(),
  ): Result<String> =
    clientFor(server).createPlaylist(
      serverUrl = server.serverUrl,
      userId = server.userId,
      token = server.accessToken,
      name = name,
      itemIds = itemIds,
    )

  suspend fun addToPlaylist(
    server: JellyfinServer,
    playlistId: String,
    itemIds: List<String>,
  ): Result<Unit> =
    clientFor(server).addToPlaylist(
      serverUrl = server.serverUrl,
      userId = server.userId,
      token = server.accessToken,
      playlistId = playlistId,
      itemIds = itemIds,
    )
}
