/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.ui.browser.jellyfin

import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.mediarouter.media.MediaRouter
import app.infinity.mpvz.domain.jellyfin.JellyfinCastMedia
import app.infinity.mpvz.ui.cast.CastExpandedControlsActivity
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener

/** Uses the app's existing receiver SDK. No mpv load, HTTP probe, relay or transcoding. */
@Composable
fun JellyfinSourceCastDialog(media: JellyfinCastMedia, onDismiss: () -> Unit, onStarted: () -> Unit) {
  val context = LocalContext.current
  var routes by remember(media) { mutableStateOf<List<MediaRouter.RouteInfo>>(emptyList()) }
  var message by remember(media) { mutableStateOf("Searching for Cast devices…") }
  var busy by remember(media) { mutableStateOf(false) }
  var select by remember(media) { mutableStateOf<((MediaRouter.RouteInfo) -> Unit)?>(null) }

  LifecycleResumeEffect(media) {
    busy = false
    routes = emptyList()
    message = "Searching for Cast devices…"
    var disposed = false
    var manager: com.google.android.gms.cast.framework.SessionManager? = null
    var router: MediaRouter? = null
    var callback: MediaRouter.Callback? = null
    var listener: SessionManagerListener<CastSession>? = null
    var pendingRoute: String? = null
    var loading = false
    var castAttempt = 0
    val handler = Handler(Looper.getMainLooper())
    val timeout = Runnable {
      if (!disposed && busy) {
        pendingRoute = null
        loading = false
        busy = false
        message = "Cast did not start. Check the receiver and try again."
      }
    }
    val noDevices = Runnable {
      if (!disposed && !busy && routes.isEmpty()) message = "No Cast devices found. Connect the phone and receiver to the same Wi-Fi network."
    }
    fun failed(text: String) {
      if (disposed) return
      handler.removeCallbacks(timeout)
      pendingRoute = null
      loading = false
      busy = false
      message = text
    }
    fun load(session: CastSession) {
      if (disposed || pendingRoute == null || loading) return
      if (manager?.currentCastSession !== session || router?.selectedRoute?.id != pendingRoute) return
      loading = true
      val attempt = castAttempt
      val remote = session.remoteMediaClient ?: run { failed("Cast receiver is not ready."); return }
      val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply { putString(MediaMetadata.KEY_TITLE, media.title) }
      val info = MediaInfo.Builder(media.url)
        .setContentType(media.contentType).setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
        .setMetadata(metadata).apply { if (media.durationMs > 0) setStreamDuration(media.durationMs) }.build()
      try {
        remote.load(MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).setCurrentTime(media.positionMs).build())
          .setResultCallback { result ->
            if (disposed || pendingRoute == null || attempt != castAttempt) return@setResultCallback
            if (result.status.isSuccess) {
              handler.removeCallbacks(timeout)
              pendingRoute = null
              busy = false
              context.startActivity(Intent(context, CastExpandedControlsActivity::class.java))
              onStarted()
            } else failed("The receiver could not play this link. Check its supported codecs and network access.")
          }
      } catch (_: RuntimeException) { failed("Could not send this link to the Cast receiver.") }
    }
    try {
      CastContext.getSharedInstance(context.applicationContext, ContextCompat.getMainExecutor(context))
        .addOnSuccessListener { cast ->
          if (disposed) return@addOnSuccessListener
          val selector = cast.mergedSelector ?: run {
            failed("No Google Cast receiver is configured on this device.")
            return@addOnSuccessListener
          }
          manager = cast.sessionManager
          val mediaRouter = MediaRouter.getInstance(context)
          router = mediaRouter
          fun updateRoutes() {
            if (!disposed) routes = mediaRouter.routes.filter { !it.isDefault && it.isEnabled && it.matchesSelector(selector) }
            if (!disposed && !busy && routes.isNotEmpty() && (message.startsWith("Searching") || message.startsWith("No Cast"))) message = "Choose a Cast device."
          }
          val routeCallback = object : MediaRouter.Callback() {
            override fun onRouteAdded(r: MediaRouter, route: MediaRouter.RouteInfo) = updateRoutes()
            override fun onRouteRemoved(r: MediaRouter, route: MediaRouter.RouteInfo) = updateRoutes()
            override fun onRouteChanged(r: MediaRouter, route: MediaRouter.RouteInfo) = updateRoutes()
          }
          callback = routeCallback
          mediaRouter.addCallback(selector, routeCallback, MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY)
          updateRoutes()
          val sessionListener = object : SessionManagerListener<CastSession> {
            override fun onSessionStarted(session: CastSession, id: String) = load(session)
            override fun onSessionResumed(session: CastSession, suspended: Boolean) = load(session)
            override fun onSessionStartFailed(session: CastSession, error: Int) = failed("Could not connect to the Cast device.")
            override fun onSessionResumeFailed(session: CastSession, error: Int) = failed("Could not reconnect to the Cast device.")
            override fun onSessionEnded(session: CastSession, error: Int) { if (busy) failed("Cast connection ended.") }
            override fun onSessionStarting(session: CastSession) = Unit
            override fun onSessionEnding(session: CastSession) = Unit
            override fun onSessionResuming(session: CastSession, id: String) = Unit
            override fun onSessionSuspended(session: CastSession, reason: Int) = Unit
          }
          listener = sessionListener
          cast.sessionManager.addSessionManagerListener(sessionListener, CastSession::class.java)
          select = { route ->
            if (!disposed && !busy) {
              pendingRoute = route.id
              castAttempt++
              loading = false
              busy = true
              message = "Connecting to ${route.name}…"
              handler.removeCallbacks(timeout)
              handler.postDelayed(timeout, 30_000)
              val session = cast.sessionManager.currentCastSession
              if (mediaRouter.selectedRoute.id == route.id && session?.isConnected == true) load(session)
              else try { route.select() } catch (_: RuntimeException) { failed("Could not select the Cast device.") }
            }
          }
          handler.postDelayed(noDevices, 8_000)
        }.addOnFailureListener { if (!disposed) failed("Google Cast is unavailable. Check Google Play services.") }
    } catch (_: RuntimeException) { failed("Google Cast is unavailable on this device.") }
    onPauseOrDispose {
      disposed = true
      select = null
      handler.removeCallbacks(timeout)
      handler.removeCallbacks(noDevices)
      callback?.let { router?.removeCallback(it) }
      listener?.let { manager?.removeSessionManagerListener(it, CastSession::class.java) }
      // Stop discovery and ignore late callbacks; a receiver already playing stays connected.
      pendingRoute = null
      busy = false
    }
  }
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Cast video") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(media.title, style = MaterialTheme.typography.titleSmall)
        if (busy) CircularProgressIndicator()
        Text(message)
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 280.dp)) {
          items(routes, key = { it.id }) { route ->
            TextButton(enabled = !busy && select != null, onClick = { select?.invoke(route) }, modifier = Modifier.fillMaxWidth()) { Text(route.name) }
          }
        }
        Text("The receiver must support this video's format and be able to reach its link.", style = MaterialTheme.typography.bodySmall)
      }
    },
    confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
  )
}
