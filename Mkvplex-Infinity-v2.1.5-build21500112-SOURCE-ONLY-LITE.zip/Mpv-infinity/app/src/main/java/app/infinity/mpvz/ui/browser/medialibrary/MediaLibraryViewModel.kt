/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.ui.browser.medialibrary

import android.app.Application
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import app.infinity.mpvz.database.entities.PlaybackStateEntity
import app.infinity.mpvz.domain.media.model.Video
import app.infinity.mpvz.domain.playbackstate.repository.PlaybackStateRepository
import app.infinity.mpvz.preferences.AppearancePreferences
import app.infinity.mpvz.preferences.BrowserPreferences
import app.infinity.mpvz.repository.MediaFileRepository
import app.infinity.mpvz.ui.browser.base.BaseBrowserViewModel
import app.infinity.mpvz.ui.browser.videolist.VideoWithPlaybackInfo
import app.infinity.mpvz.ui.browser.videolist.buildVideoWithPlaybackInfo
import app.infinity.mpvz.ui.browser.videolist.videoPlaybackIdentifiers
import app.infinity.mpvz.ui.player.PlaybackIdentity
import app.infinity.mpvz.utils.media.MetadataRetrieval
import app.infinity.mpvz.utils.media.PlaybackStateEvents
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

class MediaLibraryViewModel(
  application: Application,
) : BaseBrowserViewModel(application),
  KoinComponent {
  private val appearancePreferences: AppearancePreferences by inject()
  private val browserPreferences: BrowserPreferences by inject()
  private val playbackStateRepository: PlaybackStateRepository by inject()

  private val _videos = MutableStateFlow<List<Video>>(emptyList())
  val videos: StateFlow<List<Video>> = _videos.asStateFlow()

  private val _videosWithPlaybackInfo = MutableStateFlow<List<VideoWithPlaybackInfo>>(emptyList())
  val videosWithPlaybackInfo: StateFlow<List<VideoWithPlaybackInfo>> = _videosWithPlaybackInfo.asStateFlow()

  private val _isLoading = MutableStateFlow(false)
  val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
  private var playbackIndexByIdentifier: Map<String, Int> = emptyMap()

  private val tag = "MediaLibraryViewModel"

  init {
    loadData()
    viewModelScope.launch(Dispatchers.IO) {
      PlaybackStateEvents.changes.collectLatest { mediaIdentifier ->
        if (_videos.value.isNotEmpty()) updatePlaybackInfo(mediaIdentifier)
      }
    }
  }

  private fun loadData() {
    viewModelScope.launch(Dispatchers.IO) {
      try {
        _isLoading.value = true
        var videoList =
          MediaFileRepository.getAllVideos(
            context = getApplication(),
            includeAudioOverride = true,
          )

        if (MetadataRetrieval.isVideoMetadataNeeded(browserPreferences)) {
          videoList =
            MetadataRetrieval.enrichVideosIfNeeded(
              context = getApplication(),
              videos = videoList,
              browserPreferences = browserPreferences,
              metadataCache = metadataCache,
            )
        }

        _videos.value = videoList
        loadPlaybackInfo(videoList)
      } catch (e: Exception) {
        Log.e(tag, "Error loading media library videos", e)
      } finally {
        _isLoading.value = false
      }
    }
  }

  override fun refresh() {
    loadData()
  }

  private suspend fun loadPlaybackInfo(videos: List<Video>) {
    val playbackStates = playbackStateRepository.getAllPlaybackStates()
    val currentTime = System.currentTimeMillis()
    val thresholdDays = appearancePreferences.unplayedOldVideoDays.get()
    val watchedThreshold = browserPreferences.watchedThreshold.get()
    val playbackByTitle = playbackStates.associateBy { it.mediaTitle }
    playbackIndexByIdentifier =
      buildMap(videos.size * 4) {
        videos.forEachIndexed { index, video ->
          videoPlaybackIdentifiers(video).forEach { identifier -> put(identifier, index) }
        }
      }

    val videosWithInfo =
      videos.map { video ->
        buildVideoWithPlaybackInfo(
          video = video,
          playbackState = videoPlaybackIdentifiers(video).firstNotNullOfOrNull(playbackByTitle::get),
          currentTimeMillis = currentTime,
          newLabelDays = thresholdDays,
          watchedThreshold = watchedThreshold,
        )
      }
    _videosWithPlaybackInfo.value = videosWithInfo
  }

  private suspend fun updatePlaybackInfo(mediaIdentifier: String) {
    if (mediaIdentifier.isBlank()) {
      loadPlaybackInfo(_videos.value)
      return
    }

    val index = playbackIndexByIdentifier[mediaIdentifier] ?: return
    val videos = _videos.value
    val video = videos.getOrNull(index) ?: return
    val currentItems = _videosWithPlaybackInfo.value
    if (currentItems.size != videos.size || currentItems.getOrNull(index)?.video?.path != video.path) {
      loadPlaybackInfo(videos)
      return
    }

    val updatedItem =
      buildVideoWithPlaybackInfo(
        video = video,
        playbackState = videoPlaybackIdentifiers(video).firstNotNullOfOrNull { identifier ->
          playbackStateRepository.getVideoDataByTitle(identifier)
        },
        currentTimeMillis = System.currentTimeMillis(),
        newLabelDays = appearancePreferences.unplayedOldVideoDays.get(),
        watchedThreshold = browserPreferences.watchedThreshold.get(),
      )
    if (currentItems[index] == updatedItem) return

    _videosWithPlaybackInfo.value =
      currentItems.toMutableList().apply {
        this[index] = updatedItem
      }
  }

  fun setWatched(video: Video, watched: Boolean) {
    _videosWithPlaybackInfo.update { videos ->
      videos.map { item ->
        if (item.video.path == video.path) {
          item.copy(
            timeRemaining = if (watched) 0L else (video.duration / 1000L).coerceAtLeast(0L),
            progressPercentage = null,
            isOldAndUnplayed = !watched && (appearancePreferences.unplayedOldVideoDays.get() == 0 || System.currentTimeMillis() - video.dateModified * 1000L <= appearancePreferences.unplayedOldVideoDays.get().toLong() * 24L * 60L * 60L * 1000L),
            isWatched = watched,
          )
        } else item
      }
    }
    viewModelScope.launch(Dispatchers.IO) {
      val durationSeconds = (video.duration / 1000L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
      val identifiers = videoPlaybackIdentifiers(video)
      val existing = playbackStateRepository.getAllPlaybackStates().firstNotNullOfOrNull { state ->
        if (state.mediaTitle in identifiers) state else null
      }
      playbackStateRepository.upsert(
        (existing ?: PlaybackStateEntity(
          mediaTitle = PlaybackIdentity.forLocalPath(video.path),
          lastPosition = 0,
          playbackSpeed = 1.0,
          sid = -1,
          secondarySid = -1,
          subDelay = 0,
          subSpeed = 1.0,
          aid = -1,
          audioDelay = 0,
          timeRemaining = durationSeconds,
          hasBeenWatched = false,
        )).copy(
          mediaTitle = PlaybackIdentity.forLocalPath(video.path),
          lastPosition = 0,
          timeRemaining = if (watched) 0 else durationSeconds,
          hasBeenWatched = watched,
        ),
      )
      PlaybackStateEvents.notifyChanged(PlaybackIdentity.forLocalPath(video.path))
    }
  }

  companion object {
    fun factory(application: Application): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = MediaLibraryViewModel(application) as T
      }
  }
}
