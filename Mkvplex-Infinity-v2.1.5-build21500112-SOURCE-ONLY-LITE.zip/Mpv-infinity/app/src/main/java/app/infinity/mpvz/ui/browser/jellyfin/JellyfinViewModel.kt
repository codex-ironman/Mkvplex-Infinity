/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.ui.browser.jellyfin

import android.app.Application
import android.content.Context
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.infinity.mpvz.data.jellyfin.JellyfinClient
import app.infinity.mpvz.database.entities.PlaybackStateEntity
import app.infinity.mpvz.domain.download.AppDownloadManager
import app.infinity.mpvz.domain.download.DownloadLocations
import app.infinity.mpvz.domain.download.DownloadMetadata
import app.infinity.mpvz.domain.download.DownloadSources
import app.infinity.mpvz.domain.jellyfin.EmbyHomeItems
import app.infinity.mpvz.domain.jellyfin.MediaServerType
import app.infinity.mpvz.domain.jellyfin.JellyfinAuthMode
import app.infinity.mpvz.domain.jellyfin.JellyfinItem
import app.infinity.mpvz.preferences.AdvancedPreferences
import app.infinity.mpvz.domain.jellyfin.JellyfinLinkCheckBudget
import app.infinity.mpvz.domain.jellyfin.JellyfinLinkCheckQueue
import app.infinity.mpvz.domain.jellyfin.JellyfinLinkPolicy
import app.infinity.mpvz.domain.jellyfin.JellyfinLinkStatus
import app.infinity.mpvz.domain.jellyfin.JellyfinPlaybackCandidate
import app.infinity.mpvz.domain.jellyfin.JellyfinPlaybackFallbacks
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.ensureActive
import app.infinity.mpvz.domain.jellyfin.JellyfinMediaSource
import app.infinity.mpvz.domain.jellyfin.JellyfinPerson
import app.infinity.mpvz.domain.jellyfin.JellyfinSearchCategory
import app.infinity.mpvz.domain.jellyfin.JellyfinSearchPolicy
import app.infinity.mpvz.domain.jellyfin.JellyfinSourceErrors
import app.infinity.mpvz.domain.jellyfin.JellyfinServer
import app.infinity.mpvz.domain.jellyfin.JellyfinSortBy
import app.infinity.mpvz.domain.jellyfin.JellyfinSortOrder
import app.infinity.mpvz.domain.playbackstate.repository.PlaybackStateRepository
import app.infinity.mpvz.preferences.AppearancePreferences
import app.infinity.mpvz.preferences.AudioPreferences
import app.infinity.mpvz.preferences.SubtitlesPreferences
import app.infinity.mpvz.repository.JellyfinRepository
import app.infinity.mpvz.ui.player.PlaybackIdentity
import app.infinity.mpvz.utils.media.MediaUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withContext
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

enum class JellyfinMusicTab(val title: String) {
  HOME("Home"),
  TRACKS("Songs"),
  ALBUMS("Albums"),
  ARTISTS("Artists"),
  PLAYLISTS("Playlists"),
}

data class JellyfinLibraryView(
  val id: String,
  val title: String,
  /** Jellyfin IncludeItemTypes requested recursively for this view. */
  val itemTypes: String,
  val collectionType: String? = null,
  val isMusic: Boolean = false,
)

data class JellyfinHomeSection(
  val library: JellyfinItem,
  val title: String,
  val subtitle: String? = null,
  val items: List<JellyfinItem> = emptyList(),
  val isShows: Boolean = false,
)

data class JellyfinSourceSelection(
  val item: JellyfinItem,
  val serverId: Long,
  val startFromBeginning: Boolean = false,
  val requestId: Long = 0,
  val sources: List<JellyfinMediaSource> = emptyList(),
  val isLoading: Boolean = true,
  val error: String? = null,
  val checkingEnabled: Boolean = false,
  val linkStatus: Map<String, JellyfinLinkStatus> = emptyMap(),
  val checkSourceIds: Set<String> = emptySet(),
  val retryAttempt: Int = 0,
)

data class JellyfinUiState(
  val servers: List<JellyfinServer> = emptyList(),
  val activeServer: JellyfinServer? = null,
  val libraries: List<JellyfinItem> = emptyList(),
  val librarySections: List<JellyfinHomeSection> = emptyList(),
  val heroItems: List<JellyfinItem> = emptyList(),
  val resumeItems: List<JellyfinItem> = emptyList(),
  val latestMovies: List<JellyfinItem> = emptyList(),
  val latestShows: List<JellyfinItem> = emptyList(),
  val latestMusic: List<JellyfinItem> = emptyList(),
  val recommendations: List<JellyfinItem> = emptyList(),
  val currentItems: List<JellyfinItem> = emptyList(),
  val openLibrary: JellyfinLibraryView? = null,
  val selectedLibraryId: String? = null,
  val availableGenres: List<String> = emptyList(),
  val selectedGenreFilter: String? = null,
  val sortBy: JellyfinSortBy = JellyfinSortBy.NAME,
  val sortOrder: JellyfinSortOrder = JellyfinSortOrder.ASCENDING,
  val isUnplayedOnly: Boolean = false,
  val totalRecordCount: Int = 0,
  val startIndex: Int = 0,
  val isLoading: Boolean = false,
  val isLoadingMore: Boolean = false,
  val hasMore: Boolean = false,
  val isAuthenticating: Boolean = false,
  val error: String? = null,
  val authError: String? = null,
  val searchQuery: String = "",
  val searchMusicOnly: Boolean = false,
  val isSearchLoading: Boolean = false,
  val searchCategory: JellyfinSearchCategory = JellyfinSearchCategory.ALL,

  // Jellyfin Music Tab State (AFinity style)
  val musicActiveTab: JellyfinMusicTab = JellyfinMusicTab.HOME,
  val musicFavorites: List<JellyfinItem> = emptyList(),
  val musicJumpBackIn: List<JellyfinItem> = emptyList(),
  val musicRecentlyPlayedAlbums: List<JellyfinItem> = emptyList(),
  val musicArtistsToExplore: List<JellyfinItem> = emptyList(),
  val musicPlaylists: List<JellyfinItem> = emptyList(),
  val musicArtists: List<JellyfinItem> = emptyList(),
  val musicAlbums: List<JellyfinItem> = emptyList(),
  val musicTracks: List<JellyfinItem> = emptyList(),
  val musicGenres: List<JellyfinItem> = emptyList(),
  val isMusicLoading: Boolean = false,

  // Detail Sheet State
  val detailItem: JellyfinItem? = null,
  val detailSeasons: List<JellyfinItem> = emptyList(),
  val selectedDetailSeasonId: String? = null,
  val detailEpisodes: List<JellyfinItem> = emptyList(),
  val detailSimilarItems: List<JellyfinItem> = emptyList(),
  val isDetailLoading: Boolean = false,
  val isDetailEpisodesLoading: Boolean = false,
  val sourceSelection: JellyfinSourceSelection? = null,

  // Person Sheet State
  val personDetail: JellyfinPerson? = null,
  val personOverview: String? = null,
  val personMedia: List<JellyfinItem> = emptyList(),
  val isPersonLoading: Boolean = false,
) {
  val hasMusicLibrary: Boolean
    get() = activeServer != null && libraries.any { it.collectionType.equals("music", true) || it.type.equals("MusicAlbum", true) }
}

class JellyfinViewModel(
  application: Application,
) : AndroidViewModel(application),
  KoinComponent {
  private val jellyfinRepository: JellyfinRepository by inject()
  private val playbackStateRepository: PlaybackStateRepository by inject()
  private val subtitlesPreferences: SubtitlesPreferences by inject()
  private val audioPreferences: AudioPreferences by inject()
  private val appearancePreferences: AppearancePreferences by inject()
  private val advancedPreferences: AdvancedPreferences by inject()
  private val downloadManager: AppDownloadManager by inject()

  private var loadDashboardJob: Job? = null
  private var loadItemsJob: Job? = null
  private var searchJob: Job? = null
  private val searchRequests = JellyfinSearchPolicy.Requests()
  private val libraryRequests = JellyfinSearchPolicy.Requests()
  private var detailJob: Job? = null
  private var sourceJob: Job? = null
  private var sourceRequestId = 0L
  private var linkCheckQueue: JellyfinLinkCheckQueue? = null
  private var playbackFallbackId: String? = null
  private var seasonEpisodesJob: Job? = null
  private var musicLoadJob: Job? = null
  private var loadedMusicHomeLibraryId: String? = null

  private val _uiState = MutableStateFlow(JellyfinUiState())
  val uiState: StateFlow<JellyfinUiState> = _uiState.asStateFlow()

  init {
    loadServers()
  }

  fun loadServers() {
    viewModelScope.launch {
      jellyfinRepository.allServers.collect { servers ->
        _uiState.update { state ->
          val newest = servers.firstOrNull()
          val active = state.activeServer?.let { cur ->
            servers.find { it.id == cur.id }?.takeIf { newest == null || newest.id == it.id || newest.lastConnected >= cur.lastConnected }
              ?: newest
          } ?: newest
          state.copy(
            servers = servers,
            activeServer = active,
          )
        }
        val currentActive = _uiState.value.activeServer
        if (currentActive != null && _uiState.value.libraries.isEmpty() && _uiState.value.heroItems.isEmpty()) {
          loadHomeDashboard(currentActive)
        }
      }
    }
  }

  fun selectServer(server: JellyfinServer) {
    val selected = server.copy(lastConnected = System.currentTimeMillis())
    cancelSearch()
    libraryRequests.invalidate()
    dismissSources()
    detailJob?.cancel()
    seasonEpisodesJob?.cancel()
    _uiState.update {
      it.copy(
        activeServer = selected,
        libraries = emptyList(),
        latestMusic = emptyList(),
        openLibrary = null,
        currentItems = emptyList(),
        resumeItems = emptyList(),
        heroItems = emptyList(),
        latestMovies = emptyList(),
        latestShows = emptyList(),
        librarySections = emptyList(),
        recommendations = emptyList(),
        searchQuery = "",
        searchMusicOnly = false,
        isSearchLoading = false,
        detailItem = null,
        error = null,
      )
    }
    viewModelScope.launch(Dispatchers.IO) { jellyfinRepository.updateServer(selected) }
    loadHomeDashboard(selected)
  }

  fun refresh() {
    val active = _uiState.value.activeServer ?: return
    if (_uiState.value.searchQuery.isNotBlank()) {
      performSearch(_uiState.value.searchQuery)
      return
    }
    val library = _uiState.value.openLibrary
    if (library == null) {
      loadHomeDashboard(active)
    } else {
      loadLibraryItems(active, library, resetPagination = true)
    }
  }

  suspend fun refreshSuspend() {
    val active = _uiState.value.activeServer ?: return
    if (_uiState.value.searchQuery.isNotBlank()) {
      performSearch(_uiState.value.searchQuery)
      searchJob?.join()
      return
    }
    val library = _uiState.value.openLibrary
    if (library == null) {
      loadHomeDashboard(active)
      loadDashboardJob?.join()
    } else {
      loadLibraryItems(active, library, resetPagination = true)
      loadItemsJob?.join()
    }
  }

  fun loadLibraries(server: JellyfinServer) {
    loadHomeDashboard(server)
  }

  fun enterMusicOnlyMode(server: JellyfinServer) {
    loadDashboardJob?.cancel()
    loadItemsJob?.cancel()
    musicLoadJob?.cancel()
    _uiState.update {
      it.copy(
        isLoading = true,
        isMusicLoading = false,
        openLibrary = null,
        currentItems = emptyList(),
        resumeItems = emptyList(),
        heroItems = emptyList(),
        latestMovies = emptyList(),
        latestShows = emptyList(),
        librarySections = emptyList(),
        recommendations = emptyList(),
        detailItem = null,
      )
    }
    viewModelScope.launch {
      _uiState.update { it.copy(error = null) }
      val musicLibrary = jellyfinRepository.getLibraries(server).getOrDefault(emptyList())
        .firstOrNull { isMusicLibrary(it) }
      if (musicLibrary == null) {
        _uiState.update {
          it.copy(
            isLoading = false,
            isMusicLoading = false,
            openLibrary = null,
            currentItems = emptyList(),
            libraries = emptyList(),
            error = "No music library was found on this Jellyfin server",
          )
        }
        return@launch
      }
      _uiState.update { it.copy(isLoading = false, libraries = listOf(musicLibrary)) }
      openLibrary(
        server,
        JellyfinLibraryView(
          id = musicLibrary.id,
          title = musicLibrary.name,
          itemTypes = "Audio,MusicAlbum,MusicArtist,Playlist",
          collectionType = musicLibrary.collectionType,
          isMusic = true,
        ),
      )
    }
  }

  fun enterFullLibraryMode(server: JellyfinServer) {
    loadDashboardJob?.cancel()
    loadItemsJob?.cancel()
    musicLoadJob?.cancel()
    _uiState.update {
      it.copy(
        isLoading = true,
        isMusicLoading = false,
        openLibrary = null,
        currentItems = emptyList(),
        resumeItems = emptyList(),
        heroItems = emptyList(),
        latestMovies = emptyList(),
        latestShows = emptyList(),
        librarySections = emptyList(),
        recommendations = emptyList(),
        detailItem = null,
        musicActiveTab = JellyfinMusicTab.HOME,
      )
    }
    loadHomeDashboard(server)
  }

  fun loadHomeDashboard(server: JellyfinServer) {
    loadDashboardJob?.cancel()
    loadItemsJob?.cancel()
    musicLoadJob?.cancel()
    if (server.serverType == MediaServerType.EMBY) {
      loadDashboardJob = viewModelScope.launch { loadEmbyHomeDashboard(server) }
      return
    }
    loadDashboardJob =
      viewModelScope.launch {
        _uiState.update { it.copy(isLoading = true, error = null) }

        // Helper filter to exclude music and pure folders from general video home sections
        fun isVideoMedia(item: JellyfinItem): Boolean {
          if (item.isAudio || item.type == "Folder" || item.type == "MusicAlbum" || item.type == "Audio" || item.type == "MusicArtist" || item.type == "CollectionFolder") return false
          if (item.isFolder && !item.isSeries && !item.isSeason && item.type != "Series" && item.type != "Season") return false
          return true
        }

        var firstHero = emptyList<JellyfinItem>()
        fun publishFirstHero(items: List<JellyfinItem>) {
          if (firstHero.isNotEmpty()) return
          firstHero = items.filter {
            !it.isPlayed && (it.type == "Movie" || it.isSeries) && EmbyHomeItems.hasArtwork(it)
          }.distinctBy { mediaDeduplicationKey(it) }.take(15)
          if (firstHero.isNotEmpty()) _uiState.update { it.copy(heroItems = firstHero) }
        }

        // The hero only needs display metadata. Start it before the other home requests.
        val heroDeferred = async {
          jellyfinRepository.getItems(
            server = server,
            includeItemTypes = "Movie,Series",
            isPlayed = false,
            sortBy = app.infinity.mpvz.domain.jellyfin.JellyfinSortBy.RANDOM,
            limit = 15,
            summaryOnly = true,
          ).onSuccess {
            currentCoroutineContext().ensureActive()
            publishFirstHero(it.items)
          }
        }

        val libsDeferred = async {
          jellyfinRepository.getLibraries(server).also { result ->
            currentCoroutineContext().ensureActive()
            result.onSuccess { libraries ->
              _uiState.update { it.copy(libraries = sortJellyfinLibraries(libraries)) }
            }
          }
        }
        val resumeDeferred = async {
          jellyfinRepository.getResumeItems(server, limit = 16).also { result ->
            currentCoroutineContext().ensureActive()
            result.onSuccess { items ->
              _uiState.update { it.copy(resumeItems = items.filter { item -> isVideoMedia(item) }) }
            }
          }
        }
        val latestDeferred = async {
          jellyfinRepository.getLatestMedia(server, limit = 32).onSuccess {
            currentCoroutineContext().ensureActive()
            // Remux's random query can be slower than its latest-items endpoint.
            publishFirstHero(it)
          }
        }
        val suggestionsDeferred = async { jellyfinRepository.getSuggestions(server, limit = 36) }
        val topRatedDeferred =
          async {
            jellyfinRepository.getItems(
              server = server,
              includeItemTypes = "Movie,Series",
              sortBy = app.infinity.mpvz.domain.jellyfin.JellyfinSortBy.RATING,
              sortOrder = app.infinity.mpvz.domain.jellyfin.JellyfinSortOrder.DESCENDING,
              limit = 36,
            )
          }
        val musicDeferred =
          async {
            jellyfinRepository.getItems(
              server = server,
              includeItemTypes = "Audio,MusicAlbum",
              sortBy = app.infinity.mpvz.domain.jellyfin.JellyfinSortBy.DATE_ADDED,
              sortOrder = app.infinity.mpvz.domain.jellyfin.JellyfinSortOrder.DESCENDING,
              limit = 20,
            )
          }

        val libsResult = libsDeferred.await()
        currentCoroutineContext().ensureActive()
        val libs = sortJellyfinLibraries(libsResult.getOrDefault(emptyList()))
        // Fetch latest media for each non-music library concurrently
        val videoLibs = libs.filter { !isMusicLibrary(it) }
        val libraryRequests = Semaphore(4)
        val librarySectionsDeferred = videoLibs.map { lib ->
          async {
            val isShowLib = isSeriesLibrary(lib)
            val latestItemsResult = libraryRequests.withPermit {
              jellyfinRepository.getLatestMedia(
                server = server,
                parentId = lib.id,
                limit = 16,
                groupItems = true,
              )
            }
            val rawItems = latestItemsResult.getOrDefault(emptyList()).filter { isVideoMedia(it) }
            val containsShows = rawItems.any { it.isSeries || it.type == "Episode" || it.seriesName != null }
            val isShows = isShowLib || containsShows

            val processedItems = if (isShows) {
              resolveShowsAsSeries(server, rawItems)
            } else {
              rawItems
            }

            if (processedItems.isNotEmpty()) {
              val title = if (lib.name.startsWith("Latest", ignoreCase = true)) {
                lib.name
              } else {
                "Latest ${lib.name}"
              }
              val subtitle = if (isShows) "Newly updated series" else "Newly added to ${lib.name}"
              JellyfinHomeSection(
                library = lib,
                title = title,
                subtitle = subtitle,
                items = processedItems,
                isShows = isShows,
              ).also { section ->
                currentCoroutineContext().ensureActive()
                _uiState.update { state ->
                  val sections = (state.librarySections.filterNot { it.library.id == lib.id } + section)
                    .filter { old -> videoLibs.any { it.id == old.library.id } }
                    .sortedBy { old -> videoLibs.indexOfFirst { it.id == old.library.id } }
                  state.copy(librarySections = sections)
                }
              }
            } else {
              null
            }
          }
        }
        val librarySections = librarySectionsDeferred.awaitAll().filterNotNull()
        val resumeResult = resumeDeferred.await()
        val latestResult = latestDeferred.await()
        val suggestionsResult = suggestionsDeferred.await()
        val topRatedResult = topRatedDeferred.await()
        val musicResult = musicDeferred.await()
        heroDeferred.await()
        currentCoroutineContext().ensureActive()
        val resumeRaw = resumeResult.getOrDefault(emptyList())
        val resume = resumeRaw.filter { isVideoMedia(it) }
        val latestRaw = latestResult.getOrDefault(emptyList())
        val suggestionsRaw = suggestionsResult.getOrDefault(emptyList())
        val topRatedRaw = topRatedResult.getOrNull()?.items ?: emptyList()
        val musicRaw = musicResult.getOrNull()?.items ?: emptyList()


        val legacyLatestMovies = latestRaw.filter { isVideoMedia(it) && (it.type == "Movie" || it.collectionType?.equals("movies", ignoreCase = true) == true) }
        val legacyLatestShows = resolveShowsAsSeries(
          server,
          latestRaw.filter { isVideoMedia(it) && (it.type == "Series" || it.type == "Episode" || it.collectionType?.equals("tvshows", ignoreCase = true) == true) },
        )

        val latestMovies = librarySections.filter { !it.isShows }.flatMap { it.items }.ifEmpty { legacyLatestMovies }
        val latestShows = librarySections.filter { it.isShows }.flatMap { it.items }.ifEmpty { legacyLatestShows }

        // Top Picks For You: Combined API suggestions + top community-rated items + library sections + latest
        val rawRecommendationCandidates = (suggestionsRaw + topRatedRaw + librarySections.flatMap { it.items } + latestRaw)
          .filter { isVideoMedia(it) && (!it.backdropImageTag.isNullOrBlank() || !it.primaryImageTag.isNullOrBlank()) }

        val recommendations = resolveShowsAsSeries(server, rawRecommendationCandidates)
          .sortedWith(
            compareByDescending<JellyfinItem> { it.isSeries || it.type == "Series" }
              .thenByDescending { it.childCount ?: 0 }
              .thenByDescending { it.communityRating ?: 0.0 }
          )
          .distinctBy { mediaDeduplicationKey(it) }
          .take(36)

        val latestMusic = (musicRaw + latestRaw.filter { it.isAudio || it.type == "MusicAlbum" || it.type == "Audio" })
          .distinctBy { it.id }
          .take(16)

        // Keep the visible slide stable when the remaining home requests finish.
        val finalHero = firstHero.ifEmpty {
          resolveShowsAsSeries(
            server,
            (librarySections.flatMap { it.items } + recommendations)
              .filter { !it.isPlayed && isVideoMedia(it) && EmbyHomeItems.hasArtwork(it) },
          )
            .distinctBy { mediaDeduplicationKey(it) }
            .take(15)
        }

        currentCoroutineContext().ensureActive()
        _uiState.update {
          it.copy(
            libraries = libs,
            librarySections = librarySections,
            resumeItems = resume,
            latestMovies = latestMovies,
            latestShows = latestShows,
            latestMusic = latestMusic,
            recommendations = recommendations,
            heroItems = if (firstHero.isNotEmpty()) it.heroItems else finalHero,
            // A ready row can now be opened before the dashboard finishes.
            // Leave the loading/error state of that library or search request alone.
            isLoading = if (it.openLibrary == null && it.searchQuery.isBlank()) false else it.isLoading,
            error = if (it.openLibrary != null || it.searchQuery.isNotBlank()) it.error
              else if (libs.isEmpty() && latestRaw.isEmpty() && resumeRaw.isEmpty() && librarySections.isEmpty()) libsResult.exceptionOrNull()?.message else null,
          )
        }
      }
  }

  /** Prioritize visible content and leave HTTP slots available for artwork. */
  private suspend fun loadEmbyHomeDashboard(server: JellyfinServer) = coroutineScope {
    _uiState.update { it.copy(isLoading = true, error = null) }
    val librariesRequest = async { jellyfinRepository.getLibraries(server) }
    val resumeRequest = async {
      jellyfinRepository.getResumeItems(server, limit = 16).also { result ->
        currentCoroutineContext().ensureActive()
        result.onSuccess { items ->
          _uiState.update { it.copy(resumeItems = EmbyHomeItems.videoItems(items)) }
        }
      }
    }
    val latestRequest = async {
      jellyfinRepository.getLatestMedia(server, limit = 32).also { result ->
        currentCoroutineContext().ensureActive()
        result.onSuccess { raw ->
          val items = EmbyHomeItems.videoItems(raw)
          _uiState.update { state ->
            state.copy(
              latestMovies = items.filter { it.type == "Movie" || it.type == "Video" },
              latestShows = items.filter { it.isSeries },
              heroItems = EmbyHomeItems.heroItems(items),
              recommendations = items.filter { EmbyHomeItems.hasArtwork(it) }.take(36),
              latestMusic = raw.filter { it.isAudio || it.type == "MusicAlbum" }.take(16),
            )
          }
        }
      }
    }
    val librariesResult = librariesRequest.await()
    currentCoroutineContext().ensureActive()
    val libraries = sortJellyfinLibraries(librariesResult.getOrDefault(emptyList()))
    _uiState.update { state -> state.copy(
      libraries = libraries,
      librarySections = state.librarySections.filter { row -> libraries.any { it.id == row.library.id } },
    ) }
    val resumeResult = resumeRequest.await()
    val latestResult = latestRequest.await()
    currentCoroutineContext().ensureActive()
    _uiState.update { state ->
      val isHome = state.openLibrary == null && state.searchQuery.isBlank()
      state.copy(
        isLoading = if (isHome) false else state.isLoading,
        error = if (!isHome) state.error else if (libraries.isEmpty() &&
          latestResult.getOrDefault(emptyList()).isEmpty() && resumeResult.getOrDefault(emptyList()).isEmpty()) {
          librariesResult.exceptionOrNull()?.message ?: latestResult.exceptionOrNull()?.message
        } else null,
      )
    }

    // Do not enqueue all libraries before the banner and its images can load.
    val videoLibraries = libraries.filterNot { isMusicLibrary(it) }
    val permits = Semaphore(2)
    videoLibraries.map { library ->
      async {
        permits.withPermit {
          val raw = jellyfinRepository.getLatestMedia(server, parentId = library.id, limit = 16)
            .getOrDefault(emptyList())
          var items = EmbyHomeItems.videoItems(raw)
          if (items.isEmpty()) {
            items = EmbyHomeItems.videoItems(jellyfinRepository.getItems(
              server = server, parentId = library.id,
              includeItemTypes = libraryItemTypes(library.collectionType),
              sortBy = JellyfinSortBy.DATE_ADDED, sortOrder = JellyfinSortOrder.DESCENDING, limit = 16,
            ).getOrNull()?.items.orEmpty())
          }
          currentCoroutineContext().ensureActive()
          if (items.isNotEmpty()) {
            val isShows = isSeriesLibrary(library) || items.any { it.isSeries }
            val section = JellyfinHomeSection(
              library = library,
              title = if (library.name.startsWith("Latest", ignoreCase = true)) library.name else "Latest ${library.name}",
              subtitle = if (isShows) "Newly updated series" else "Newly added to ${library.name}",
              items = items, isShows = isShows,
            )
            _uiState.update { state ->
              val sections = (state.librarySections.filterNot { it.library.id == library.id } + section)
                .sortedBy { row -> videoLibraries.indexOfFirst { it.id == row.library.id } }
              val candidates = (state.recommendations + items).distinctBy { it.id }
              state.copy(
                librarySections = sections,
                heroItems = state.heroItems.ifEmpty { EmbyHomeItems.heroItems(items) },
                recommendations = candidates.filter { EmbyHomeItems.hasArtwork(it) }.take(36),
              )
            }
          }
        }
      }
    }.awaitAll()
  }

  private fun mediaDeduplicationKey(item: JellyfinItem): String {
    if (item.isSeries || item.type == "Series" || item.type == "Episode" || !item.seriesName.isNullOrBlank()) {
      val showName = (item.seriesName ?: item.name).trim().lowercase()
      return "series_$showName"
    }
    val movieName = item.name.trim().lowercase()
    return "movie_$movieName"
  }

  private suspend fun resolveShowsAsSeries(
    server: JellyfinServer,
    items: List<JellyfinItem>,
  ): List<JellyfinItem> {
    if (items.isEmpty()) return emptyList()

    val episodeItems = items.filter { it.type == "Episode" && !it.seriesId.isNullOrBlank() }
    val seriesMap = if (episodeItems.isNotEmpty()) {
      val distinctSeriesIds = episodeItems.mapNotNull { it.seriesId }.distinct()
      coroutineScope {
        distinctSeriesIds.map { seriesId ->
          async(Dispatchers.IO) {
            seriesId to jellyfinRepository.getItem(server, seriesId).getOrNull()
          }
        }.awaitAll().toMap()
      }
    } else {
      emptyMap()
    }

    return items.map { item ->
      if (item.type == "Episode") {
        val series = item.seriesId?.let { seriesMap[it] }
        series ?: item.copy(
          id = item.seriesId ?: item.id,
          name = item.seriesName ?: item.name,
          type = "Series",
          primaryImageTag = item.seriesPrimaryImageTag ?: item.primaryImageTag,
        )
      } else {
        item
      }
    }.distinctBy { mediaDeduplicationKey(it) }
  }

  private fun isSeriesLibrary(lib: JellyfinItem): Boolean {
    val col = lib.collectionType?.lowercase()?.trim() ?: ""
    val type = lib.type.lowercase().trim()
    val name = lib.name.lowercase().trim()
    return col == "tvshows" || col == "series" || type == "series" ||
      name.contains("show") || name.contains("series") || name.contains("tv") || name.contains("anime") || name.contains("drama")
  }

  private fun isMusicLibrary(item: JellyfinItem): Boolean {
    val col = item.collectionType?.lowercase()?.trim() ?: ""
    val type = item.type.lowercase().trim()
    val name = item.name.lowercase().trim()
    return col == "music" || type == "music" || type == "audio" || (name.contains("music") && !name.contains("video"))
  }

  fun getMusicLibraryView(): JellyfinLibraryView? =
    _uiState.value.libraries.firstOrNull(::isMusicLibrary)?.let { library ->
      JellyfinLibraryView(
        id = library.id,
        title = library.name,
        itemTypes = "Audio,MusicAlbum,MusicArtist,Playlist",
        collectionType = library.collectionType,
        isMusic = true,
      )
    }

  private fun sortJellyfinLibraries(libs: List<JellyfinItem>): List<JellyfinItem> {
    fun libraryRank(item: JellyfinItem): Int {
      val name = item.name.lowercase().trim()
      val colType = item.collectionType?.lowercase()?.trim() ?: ""
      val type = item.type.lowercase().trim()

      val isAnime = name.contains("anime") || colType.contains("anime")
      val isMovie = !isAnime && (colType == "movies" || type == "movie" || name.contains("movie") || name.contains("film"))
      val isMusic = colType == "music" || type == "audio" || type == "music" || name.contains("music") || name.contains("song") || name.contains("audio")
      val isSeries = !isAnime && (colType == "tvshows" || type == "series" || name.contains("show") || name.contains("series") || name.contains("tv"))

      return when {
        isMovie -> 0
        isMusic -> 1
        isSeries -> 2
        isAnime -> 3
        else -> 4
      }
    }

    return libs.sortedWith(compareBy({ libraryRank(it) }, { it.name.lowercase() }))
  }

  fun setSort(
    sortBy: JellyfinSortBy,
    sortOrder: JellyfinSortOrder,
  ) {
    _uiState.update { it.copy(sortBy = sortBy, sortOrder = sortOrder) }
    val active = _uiState.value.activeServer ?: return
    val library = _uiState.value.openLibrary ?: return
    loadLibraryItems(active, library, resetPagination = true)
  }

  fun toggleUnplayedOnly() {
    val newFilter = !_uiState.value.isUnplayedOnly
    _uiState.update { it.copy(isUnplayedOnly = newFilter) }
    val active = _uiState.value.activeServer ?: return
    val library = _uiState.value.openLibrary ?: return
    loadLibraryItems(active, library, resetPagination = true)
  }

  fun navigateToItem(item: JellyfinItem) {
    val active = _uiState.value.activeServer ?: return
    val isMusic = item.collectionType?.equals("music", ignoreCase = true) == true ||
      item.type == "MusicAlbum" || item.type == "MusicArtist"
    val types =
      when {
        item.type == "MusicAlbum" || item.type == "MusicArtist" -> "Audio"
        item.type == "CollectionFolder" -> libraryItemTypes(item.collectionType)
        item.isFolder && !item.isSeries && !item.isSeason -> libraryItemTypes(item.collectionType)
        else -> null
      }
    if (types == null) {
      openDetail(item)
    } else {
      openLibrary(
        active,
        JellyfinLibraryView(
          id = item.id,
          title = item.name,
          itemTypes = types,
          collectionType = item.collectionType,
          isMusic = isMusic,
        ),
      )
    }
  }

  private fun openLibrary(
    server: JellyfinServer,
    library: JellyfinLibraryView,
  ) {
    cancelSearch()
    libraryRequests.invalidate()
    _uiState.update {
      it.copy(
        openLibrary = library,
        selectedLibraryId = library.id,
        selectedGenreFilter = null,
        availableGenres = emptyList(),
        searchQuery = "",
        isSearchLoading = false,
        musicActiveTab = JellyfinMusicTab.HOME,
      )
    }
    if (library.isMusic) {
      loadMusicHomeDashboard(server, library)
    } else {
      loadLibraryItems(server, library, resetPagination = true)
      viewModelScope.launch {
        jellyfinRepository.getGenres(server, library.id).onSuccess { genres ->
          if (_uiState.value.openLibrary?.id == library.id) {
            _uiState.update { it.copy(availableGenres = genres) }
          }
        }
      }
    }
  }

  fun setGenreFilter(genre: String?) {
    if (_uiState.value.selectedGenreFilter == genre) return
    _uiState.update { it.copy(selectedGenreFilter = genre) }
    val active = _uiState.value.activeServer ?: return
    val library = _uiState.value.openLibrary ?: return
    loadLibraryItems(active, library, resetPagination = true)
  }

  fun navigateBack(): Boolean {
    val library = _uiState.value.openLibrary
    if (library != null) {
      if (library.isMusic && _uiState.value.musicActiveTab != JellyfinMusicTab.HOME) {
        setMusicTab(JellyfinMusicTab.HOME)
        return true
      }
      cancelSearch()
      loadItemsJob?.cancel()
      libraryRequests.invalidate()
      _uiState.update {
        it.copy(
          openLibrary = null,
          currentItems = emptyList(),
          selectedLibraryId = null,
          selectedGenreFilter = null,
          availableGenres = emptyList(),
          searchQuery = "",
        isSearchLoading = false,
          musicActiveTab = JellyfinMusicTab.HOME,
        )
      }
      val active = _uiState.value.activeServer ?: return true
      loadHomeDashboard(active)
      return true
    }
    return false
  }

  fun loadMusicHomeDashboard(
    server: JellyfinServer,
    library: JellyfinLibraryView,
  ) {
    loadDashboardJob?.cancel()
    loadItemsJob?.cancel()
    musicLoadJob?.cancel()
    loadedMusicHomeLibraryId = null
    musicLoadJob = viewModelScope.launch {
      _uiState.update { it.copy(isLoading = false, isMusicLoading = true) }

      val jumpBackDeferred = async {
        val playedTracks = jellyfinRepository.getItems(
          server = server,
          parentId = library.id,
          includeItemTypes = "Audio",
          sortBy = JellyfinSortBy.DATE_PLAYED,
          sortOrder = JellyfinSortOrder.DESCENDING,
          limit = 30,
        ).getOrNull()?.items.orEmpty()

        val addedTracks = jellyfinRepository.getItems(
          server = server,
          parentId = library.id,
          includeItemTypes = "Audio",
          sortBy = JellyfinSortBy.DATE_ADDED,
          sortOrder = JellyfinSortOrder.DESCENDING,
          limit = 30,
        ).getOrNull()?.items.orEmpty()

        val randomTracks = jellyfinRepository.getItems(
          server = server,
          parentId = library.id,
          includeItemTypes = "Audio",
          sortBy = JellyfinSortBy.RANDOM,
          limit = 30,
        ).getOrNull()?.items.orEmpty()

        val uniquePlayed = playedTracks.distinctBy { it.id }
        val playedIds = uniquePlayed.map { it.id }.toSet()
        val uniqueOthers = (addedTracks + randomTracks)
          .distinctBy { it.id }
          .filter { it.id !in playedIds }

        (uniquePlayed + uniqueOthers).take(24)
      }

      val recentlyPlayedAlbumsDeferred = async {
        jellyfinRepository.getItems(
          server = server,
          parentId = library.id,
          includeItemTypes = "MusicAlbum",
          sortBy = JellyfinSortBy.DATE_ADDED,
          sortOrder = JellyfinSortOrder.DESCENDING,
          limit = 15,
        ).getOrNull()?.items.orEmpty()
      }

      val artistsToExploreDeferred = async {
        val endpointArtists = jellyfinRepository.getArtists(
          server = server,
          parentId = library.id,
          limit = 30,
        ).getOrNull()?.items.orEmpty()

        val itemArtists = jellyfinRepository.getItems(
          server = server,
          parentId = library.id,
          includeItemTypes = "MusicArtist,Artist,AlbumArtist",
          sortBy = JellyfinSortBy.RANDOM,
          limit = 30,
        ).getOrNull()?.items.orEmpty()

        (endpointArtists + itemArtists)
          .filter { it.name.isNotBlank() }
          .distinctBy { if (it.id.isNotBlank()) it.id else it.name.lowercase().trim() }
          .shuffled()
          .take(15)
      }

      val favoritesDeferred = async {
        jellyfinRepository.getItems(
          server = server,
          parentId = null,
          includeItemTypes = "Audio",
          isFavorite = true,
          sortBy = JellyfinSortBy.NAME,
          limit = 50,
        ).getOrNull()?.items.orEmpty()
      }

      val playlistsDeferred = async {
        val serverPlaylists = jellyfinRepository.getItems(
          server = server,
          parentId = null,
          includeItemTypes = "Playlist",
          sortBy = JellyfinSortBy.NAME,
          limit = 500,
        ).getOrNull()?.items.orEmpty()

        val favoritesVirtualPlaylist = JellyfinItem(
          id = "virtual_favorites_playlist",
          name = "Favorites",
          type = "Playlist",
          overview = null,
          isFolder = true,
          isFavorite = true,
          primaryImageTag = null,
          albumPrimaryImageTag = null,
        )

        listOf(favoritesVirtualPlaylist) + serverPlaylists.filter { !it.name.equals("Favorites", ignoreCase = true) }
      }

      val jumpBackIn = jumpBackDeferred.await()
      val recentAlbums = recentlyPlayedAlbumsDeferred.await()
      val artistsToExplore = artistsToExploreDeferred.await()
      val favorites = favoritesDeferred.await()
      val playlists = playlistsDeferred.await()

      loadedMusicHomeLibraryId = library.id
      _uiState.update {
        it.copy(
          musicFavorites = favorites,
          musicPlaylists = playlists,
          musicJumpBackIn = jumpBackIn,
          musicRecentlyPlayedAlbums = recentAlbums,
          musicArtistsToExplore = artistsToExplore,
          isMusicLoading = false,
        )
      }
    }
  }

  fun setMusicTab(tab: JellyfinMusicTab) {
    if (_uiState.value.musicActiveTab == tab) return
    _uiState.update { it.copy(musicActiveTab = tab) }
    val active = _uiState.value.activeServer ?: return
    val library = _uiState.value.openLibrary ?: return

    if (tab == JellyfinMusicTab.HOME) {
      if (loadedMusicHomeLibraryId != library.id) loadMusicHomeDashboard(active, library)
    } else {
      loadMusicTabItems(active, library, tab)
    }
  }

  private fun loadMusicTabItems(
    server: JellyfinServer,
    library: JellyfinLibraryView,
    tab: JellyfinMusicTab,
  ) {
    musicLoadJob?.cancel()
    musicLoadJob = viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true, isMusicLoading = false) }
      when (tab) {
        JellyfinMusicTab.PLAYLISTS -> {
          val serverPlaylists = jellyfinRepository.getItems(
            server = server,
            parentId = null,
            includeItemTypes = "Playlist",
            sortBy = JellyfinSortBy.NAME,
            limit = 500,
          ).getOrNull()?.items.orEmpty()

          val favoriteTracks = jellyfinRepository.getItems(
            server = server,
            parentId = null,
            includeItemTypes = "Audio",
            isFavorite = true,
            sortBy = JellyfinSortBy.NAME,
            limit = 1,
          ).getOrNull()?.items.orEmpty()

          val favoritesVirtualPlaylist = JellyfinItem(
            id = "virtual_favorites_playlist",
            name = "Favorites",
            type = "Playlist",
            overview = null,
            isFolder = true,
            isFavorite = true,
            primaryImageTag = null,
            albumPrimaryImageTag = null,
          )

          val combinedPlaylists = listOf(favoritesVirtualPlaylist) + serverPlaylists.filter { !it.name.equals("Favorites", ignoreCase = true) }
          _uiState.update { it.copy(musicPlaylists = combinedPlaylists, isLoading = false) }
        }
        JellyfinMusicTab.ARTISTS -> {
          val libraryItemsArtists = jellyfinRepository.getItems(
            server = server,
            parentId = library.id,
            includeItemTypes = "MusicArtist,Artist,AlbumArtist",
            sortBy = JellyfinSortBy.NAME,
            limit = 500,
          ).getOrNull()?.items.orEmpty()

          val rootItemsArtists = jellyfinRepository.getItems(
            server = server,
            parentId = null,
            includeItemTypes = "MusicArtist,Artist,AlbumArtist",
            sortBy = JellyfinSortBy.NAME,
            limit = 500,
          ).getOrNull()?.items.orEmpty()

          val libraryArtistsEndpoint = jellyfinRepository.getArtists(
            server = server,
            parentId = library.id,
            limit = 500,
          ).getOrNull()?.items.orEmpty()

          val rootArtistsEndpoint = jellyfinRepository.getArtists(
            server = server,
            parentId = null,
            limit = 500,
          ).getOrNull()?.items.orEmpty()

          val libraryAlbumArtistsEndpoint = jellyfinRepository.getArtists(
            server = server,
            parentId = library.id,
            limit = 500,
            albumArtistsOnly = true,
          ).getOrNull()?.items.orEmpty()

          val rootAlbumArtistsEndpoint = jellyfinRepository.getArtists(
            server = server,
            parentId = null,
            limit = 500,
            albumArtistsOnly = true,
          ).getOrNull()?.items.orEmpty()

          val allFetched = libraryItemsArtists + rootItemsArtists + libraryArtistsEndpoint + rootArtistsEndpoint + libraryAlbumArtistsEndpoint + rootAlbumArtistsEndpoint

          val combinedArtists = allFetched
            .filter { it.name.isNotBlank() }
            .distinctBy { if (it.id.isNotBlank()) it.id else it.name.lowercase().trim() }
            .sortedBy { it.name.lowercase() }

          _uiState.update { it.copy(musicArtists = combinedArtists, isLoading = false) }
        }
        JellyfinMusicTab.ALBUMS -> {
          val result = jellyfinRepository.getItems(
            server = server,
            parentId = library.id,
            includeItemTypes = "MusicAlbum",
            sortBy = JellyfinSortBy.NAME,
            limit = 500,
          ).getOrNull()?.items.orEmpty()
          _uiState.update { it.copy(musicAlbums = result, isLoading = false) }
        }
        JellyfinMusicTab.TRACKS -> {
          val result = jellyfinRepository.getItems(
            server = server,
            parentId = library.id,
            includeItemTypes = "Audio",
            sortBy = JellyfinSortBy.NAME,
            limit = 500,
          ).getOrNull()?.items.orEmpty()
          _uiState.update { it.copy(musicTracks = result, isLoading = false) }
        }
        JellyfinMusicTab.HOME -> {
          _uiState.update { it.copy(isLoading = false) }
        }
      }
    }
  }

  fun navigateToRoot() {
    navigateBack()
  }

  /** Concrete item types to request recursively so a library lists media, not folders. */
  private fun libraryItemTypes(collectionType: String?): String =
    when (collectionType?.lowercase()) {
      "movies" -> "Movie"
      "tvshows" -> "Series"
      "music" -> "MusicAlbum"
      "musicvideos" -> "MusicVideo"
      "boxsets" -> "BoxSet"
      "books" -> "Book"
      "homevideos", "photos" -> "Video"
      else -> "Movie,Series"
    }

  private fun loadLibraryItems(
    server: JellyfinServer,
    library: JellyfinLibraryView,
    resetPagination: Boolean = true,
  ) {
    if (_uiState.value.searchQuery.isNotBlank()) {
      performSearch(_uiState.value.searchQuery)
      return
    }
    val request = libraryRequests.begin(JellyfinSearchPolicy.Scope(server.id, library.id, ""))
    val startIndex = if (resetPagination) 0 else _uiState.value.startIndex
    val currentList = if (resetPagination) emptyList() else _uiState.value.currentItems

    if (resetPagination) {
      loadItemsJob?.cancel()
      musicLoadJob?.cancel()
    }

    loadItemsJob =
      viewModelScope.launch {
        if (resetPagination) {
          _uiState.update {
            it.copy(
              isLoading = true,
              currentItems = emptyList(),
              startIndex = 0,
              hasMore = false,
              error = null,
            )
          }
        } else {
          _uiState.update { it.copy(isLoadingMore = true) }
        }

        val currentState = _uiState.value

        jellyfinRepository
          .getItems(
            server = server,
            parentId = library.id,
            includeItemTypes = library.itemTypes,
            sortBy = currentState.sortBy,
            sortOrder = currentState.sortOrder,
            isPlayed = if (currentState.isUnplayedOnly) false else null,
            genres = currentState.selectedGenreFilter,
            startIndex = startIndex,
            limit = 100,
          ).onSuccess { queryResult ->
            currentCoroutineContext().ensureActive()
            val combined = (currentList + queryResult.items).distinctBy { it.id }
            _uiState.update {
              if (!libraryRequests.accepts(request, requestScope(it, libraryOnly = true))) it else it.copy(
                currentItems = combined,
                totalRecordCount = queryResult.totalRecordCount,
                startIndex = combined.size,
                hasMore = combined.size < queryResult.totalRecordCount,
                isLoading = false,
                isLoadingMore = false,
                error = null,
              )
            }
          }.onFailure { err ->
            currentCoroutineContext().ensureActive()
            _uiState.update {
              if (!libraryRequests.accepts(request, requestScope(it, libraryOnly = true))) it else it.copy(
                isLoading = false,
                isLoadingMore = false,
                error = err.message ?: "Failed to load items",
              )
            }
          }
      }
  }

  fun loadMoreItems() {
    val state = _uiState.value
    if (state.isLoading || state.isLoadingMore || !state.hasMore) return
    if (state.searchQuery.isNotBlank()) {
      performSearch(state.searchQuery, append = true)
      return
    }
    val active = state.activeServer ?: return
    val library = state.openLibrary ?: return
    loadLibraryItems(active, library, resetPagination = false)
  }

  fun onSearchQueryChanged(query: String, musicOnly: Boolean? = null) {
    performSearch(query, debounceMs = 300L, musicOnly = musicOnly)
  }

  fun setSearchCategory(category: JellyfinSearchCategory) {
    _uiState.update { it.copy(searchCategory = category) }
    if (_uiState.value.searchQuery.isNotBlank()) {
      performSearch(_uiState.value.searchQuery, debounceMs = 0L)
    }
  }

  private fun cancelSearch() {
    searchJob?.cancel()
    searchRequests.invalidate()
  }

  private fun requestScope(state: JellyfinUiState, libraryOnly: Boolean = false) =
    JellyfinSearchPolicy.Scope(state.activeServer?.id, state.openLibrary?.id, state.searchQuery,
      if (libraryOnly) null else state.searchCategory,
      if (libraryOnly) false else state.searchMusicOnly)

  fun performSearch(
    query: String,
    debounceMs: Long = 0L,
    append: Boolean = false,
    musicOnly: Boolean? = null,
  ) {
    val active = _uiState.value.activeServer ?: return
    cancelSearch()
    loadItemsJob?.cancel()
    musicLoadJob?.cancel()
    libraryRequests.invalidate()
    val musicContext = musicOnly ?: _uiState.value.searchMusicOnly
    _uiState.update { it.copy(searchQuery = query, searchMusicOnly = query.isNotBlank() && musicContext) }
    val state = _uiState.value
    val library = state.openLibrary
    val category = state.searchCategory
    val request = searchRequests.begin(requestScope(state))
    val offset = if (append) state.startIndex else 0
    val previousItems = if (append) state.currentItems else emptyList()
    if (query.isBlank()) {
      _uiState.update { it.copy(isSearchLoading = false, isLoading = false, isLoadingMore = false) }
      if (musicContext && library == null) {
        getMusicLibraryView()?.let { loadMusicHomeDashboard(active, it); return }
      }
      refresh()
      return
    }
    _uiState.update {
      if (append) it.copy(isSearchLoading = true, isLoadingMore = true, error = null)
      else it.copy(isSearchLoading = true, isLoading = true, isLoadingMore = false,
        currentItems = emptyList(), hasMore = false, error = null)
    }
    searchJob =
      viewModelScope.launch {
        if (debounceMs > 0) {
          delay(debounceMs)
        }
        val includeTypes = JellyfinSearchPolicy.itemTypes(category, library?.isMusic == true || state.searchMusicOnly)

        val result =
          jellyfinRepository.getItems(
            server = active,
            parentId = library?.id,
            searchTerm = query,
            includeItemTypes = includeTypes,
            sortBy = state.sortBy,
            sortOrder = state.sortOrder,
            isPlayed = if (state.isUnplayedOnly) false else null,
            genres = state.selectedGenreFilter,
            startIndex = offset,
            limit = 100,
          )
        coroutineContext.ensureActive()
        fun isCurrent(value: JellyfinUiState) = searchRequests.accepts(request, requestScope(value))
        result
          .onSuccess { queryResult ->
            val page = JellyfinSearchPolicy.page(previousItems, queryResult, offset)
            _uiState.update {
              if (!isCurrent(it)) it else it.copy(
                currentItems = page.items,
                totalRecordCount = queryResult.totalRecordCount,
                startIndex = page.nextOffset,
                hasMore = page.hasMore,
                isLoading = false,
                isLoadingMore = false,
                isSearchLoading = false,
                error = null,
              )
            }
          }.onFailure { err ->
            _uiState.update { if (!isCurrent(it)) it else it.copy(isLoading = false,
              isLoadingMore = false, isSearchLoading = false, error = err.message ?: "Search failed. Try again.") }
          }
      }
  }

  // ============================================================================
  // Media Details & Series Season/Episode Browsing (Material 3 Expressive)
  // ============================================================================

  fun deleteItem(itemId: String, onSuccess: (() -> Unit)? = null) {
    val active = _uiState.value.activeServer ?: return
    viewModelScope.launch {
      val res = jellyfinRepository.deleteItem(active, itemId)
      res.fold(
        onSuccess = {
          _uiState.update { state ->
            state.copy(
              currentItems = state.currentItems.filter { it.id != itemId },
              detailItem = if (state.detailItem?.id == itemId) null else state.detailItem,
            )
          }
          onSuccess?.invoke()
          refresh()
        },
        onFailure = { err ->
          Log.e("JellyfinViewModel", "Failed to delete item $itemId", err)
        },
      )
    }
  }

  fun deleteItems(itemIds: List<String>, onSuccess: (() -> Unit)? = null) {
    val active = _uiState.value.activeServer ?: return
    viewModelScope.launch {
      for (id in itemIds) {
        jellyfinRepository.deleteItem(active, id)
      }
      _uiState.update { state ->
        state.copy(
          currentItems = state.currentItems.filter { it.id !in itemIds },
        )
      }
      onSuccess?.invoke()
      refresh()
    }
  }

  fun openDetailById(itemId: String) {
    val active = _uiState.value.activeServer ?: return
    viewModelScope.launch {
      val res = jellyfinRepository.getItem(active, itemId, includeMediaSources = false)
      res.onSuccess { item ->
        openDetail(item, detailAlreadyFresh = true)
      }
    }
  }

  fun openDetail(item: JellyfinItem, detailAlreadyFresh: Boolean = false) {
    val active = _uiState.value.activeServer ?: return
    detailJob?.cancel()
    seasonEpisodesJob?.cancel()

    _uiState.update {
      it.copy(
        detailItem = item,
        detailSeasons = emptyList(),
        selectedDetailSeasonId = null,
        detailEpisodes = emptyList(),
        detailSimilarItems = emptyList(),
        isDetailLoading = true,
        isDetailEpisodesLoading = false,
      )
    }

    detailJob =
      viewModelScope.launch {
        // Match Remux Web: render lightweight details while only the viewed
        // Movie/Episode's version list warms. The chooser joins this request.
        if (item.isVideo) launch {
          val sources = jellyfinRepository.prefetchSources(active, item.id).getOrDefault(emptyList())
          currentCoroutineContext().ensureActive()
          _uiState.update { state ->
            val detail = state.detailItem
            if (state.activeServer?.id == active.id && detail?.id == item.id && sources.isNotEmpty()) {
              state.copy(detailItem = detail.copy(mediaSources =
                (detail.mediaSources + sources).associateBy { it.id }.values.toList()))
            } else state
          }
        }
        val freshDeferred = async {
          if (detailAlreadyFresh) Result.success(item)
          else jellyfinRepository.getItem(active, item.id, includeMediaSources = false)
        }
        // Similar titles must not hold up details, seasons or the first episode list.
        launch {
          val similarResult = jellyfinRepository.getSimilarItems(active, item.id, limit = 12)
          currentCoroutineContext().ensureActive()
          _uiState.update { state ->
            if (state.activeServer?.id == active.id && state.detailItem?.id == item.id) {
              state.copy(detailSimilarItems = similarResult.getOrDefault(emptyList()))
            } else state
          }
        }

        val freshResult = freshDeferred.await()
        currentCoroutineContext().ensureActive()
        val freshItem = freshResult.getOrNull() ?: item
        val fullItem = freshItem.copy(
          mediaSources = (item.mediaSources + freshItem.mediaSources +
            jellyfinRepository.cachedSources(active, item.id)).associateBy { it.id }.values.toList(),
          container = freshItem.container ?: item.container,
          videoCodec = freshItem.videoCodec ?: item.videoCodec,
          videoResolution = freshItem.videoResolution ?: item.videoResolution,
          videoHdrType = freshItem.videoHdrType ?: item.videoHdrType,
          audioCodec = freshItem.audioCodec ?: item.audioCodec,
          audioChannels = freshItem.audioChannels ?: item.audioChannels,
        )

        _uiState.update {
          it.copy(
            detailItem = fullItem,
            isDetailLoading = false,
          )
        }

        if (fullItem.isSeries) {
          val seasonsResult = jellyfinRepository.getSeasons(active, fullItem.id)
          val rawSeasons = seasonsResult.getOrDefault(emptyList())
          val seasons = rawSeasons.sortedWith(
            compareBy<JellyfinItem> { it.indexNumber ?: Int.MAX_VALUE }
              .thenBy { it.name }
          )
          val initialSeason = seasons.firstOrNull()

          _uiState.update {
            it.copy(
              detailSeasons = seasons,
              selectedDetailSeasonId = initialSeason?.id,
            )
          }

          if (initialSeason != null) {
            selectDetailSeason(initialSeason.id)
          }
        } else if (fullItem.type == "MusicArtist" || fullItem.type == "Artist" || fullItem.type == "AlbumArtist") {
          val albumsDeferred = async {
            val byParent = jellyfinRepository.getItems(
              server = active,
              parentId = fullItem.id,
              includeItemTypes = "MusicAlbum",
              sortBy = JellyfinSortBy.NAME,
              limit = 100,
            ).getOrNull()?.items.orEmpty()

            val byArtistId = jellyfinRepository.getItems(
              server = active,
              artistIds = fullItem.id,
              includeItemTypes = "MusicAlbum",
              sortBy = JellyfinSortBy.NAME,
              limit = 100,
            ).getOrNull()?.items.orEmpty()

            val allAlbums = jellyfinRepository.getItems(
              server = active,
              includeItemTypes = "MusicAlbum",
              sortBy = JellyfinSortBy.NAME,
              limit = 300,
            ).getOrNull()?.items.orEmpty()

            val byName = allAlbums.filter { a ->
              a.seriesName?.equals(fullItem.name, ignoreCase = true) == true
            }

            (byParent + byArtistId + byName)
              .filter { it.name.isNotBlank() }
              .distinctBy { it.id }
          }
          val tracksDeferred = async {
            val byParentTracks = jellyfinRepository.getItems(
              server = active,
              parentId = fullItem.id,
              includeItemTypes = "Audio",
              sortBy = JellyfinSortBy.NAME,
              limit = 200,
            ).getOrNull()?.items.orEmpty()

            val byArtistIdTracks = jellyfinRepository.getItems(
              server = active,
              artistIds = fullItem.id,
              includeItemTypes = "Audio",
              sortBy = JellyfinSortBy.NAME,
              limit = 200,
            ).getOrNull()?.items.orEmpty()

            (byParentTracks + byArtistIdTracks)
              .filter { it.name.isNotBlank() }
              .distinctBy { it.id }
          }

          val albums = albumsDeferred.await()
          val tracks = tracksDeferred.await()

          _uiState.update {
            it.copy(
              detailSeasons = albums,
              detailEpisodes = tracks,
            )
          }
        } else if (fullItem.type == "MusicAlbum" || fullItem.type == "Playlist") {
          val tracks =
            if (fullItem.id == "virtual_favorites_playlist" || fullItem.id == "favorites") {
              jellyfinRepository.getItems(
                server = active,
                parentId = null,
                includeItemTypes = "Audio",
                isFavorite = true,
                sortBy = JellyfinSortBy.NAME,
                limit = 500,
              ).getOrNull()?.items.orEmpty()
            } else {
              jellyfinRepository.getItems(
                server = active,
                parentId = fullItem.id,
                includeItemTypes = if (fullItem.type == "MusicAlbum") "Audio" else null,
                limit = 200,
              ).getOrNull()?.items.orEmpty().ifEmpty {
                jellyfinRepository.getItems(
                  server = active,
                  parentId = fullItem.id,
                  limit = 200,
                ).getOrNull()?.items.orEmpty()
              }
            }

          _uiState.update {
            it.copy(
              detailEpisodes = tracks,
            )
          }
        }
      }
  }

  fun selectDetailSeason(seasonId: String) {
    val active = _uiState.value.activeServer ?: return
    val series = _uiState.value.detailItem ?: return
    seasonEpisodesJob?.cancel()

    _uiState.update {
      it.copy(
        selectedDetailSeasonId = seasonId,
        detailEpisodes = emptyList(),
        isDetailEpisodesLoading = true,
      )
    }

    seasonEpisodesJob =
      viewModelScope.launch {
        val result = jellyfinRepository.getEpisodes(active, series.id, seasonId)
        currentCoroutineContext().ensureActive()
        val episodes = result.getOrDefault(emptyList())
        _uiState.update { state ->
          if (state.activeServer?.id != active.id || state.detailItem?.id != series.id ||
            state.selectedDetailSeasonId != seasonId) state
          else state.copy(
            detailEpisodes = episodes,
            isDetailEpisodesLoading = false,
          )
        }
      }
  }

  fun closeDetail() {
    detailJob?.cancel()
    seasonEpisodesJob?.cancel()
    _uiState.update {
      it.copy(
        detailItem = null,
        detailSeasons = emptyList(),
        selectedDetailSeasonId = null,
        detailEpisodes = emptyList(),
        detailSimilarItems = emptyList(),
        isDetailLoading = false,
        isDetailEpisodesLoading = false,
      )
    }
  }

  // ── Downloads ─────────────────────────────────────────────────────────────

  /** Engine download list, exposed for per-item badges and indicators. */
  val downloads get() = downloadManager.downloads

  suspend fun availableDownloadSources(item: JellyfinItem): List<JellyfinMediaSource> {
    val server = _uiState.value.activeServer ?: return emptyList()
    return jellyfinRepository.getMediaSources(server, item.id).getOrDefault(emptyList())
  }

  /** Live snapshot of the currently transferring item (progress and speed). */
  val activeSnapshot get() = downloadManager.activeSnapshot

  private fun serverDownload(server: JellyfinServer, itemId: String, playableOnly: Boolean = false) =
    downloadManager.downloads.value.firstOrNull {
      it.entity.jellyfinServerId == server.id.toString() && it.entity.jellyfinItemId == itemId &&
        (!playableOnly || it.isPlayable)
    }

  fun cancelDownload(itemId: String) {
    val server = _uiState.value.activeServer ?: return
    viewModelScope.launch(Dispatchers.IO) {
      val dl = downloadManager.downloads.value.firstOrNull { it.entity.jellyfinServerId == server.id.toString() && it.entity.jellyfinItemId == itemId && it.isActive }
      if (dl != null) {
        downloadManager.remove(dl, deleteFile = true)
      }
    }
  }
  fun downloadItem(item: JellyfinItem, mediaSource: JellyfinMediaSource? = null) {
    val server = _uiState.value.activeServer ?: return
    viewModelScope.launch(Dispatchers.IO) {
      val queued = enqueueJellyfinDownload(server, item, mediaSource)
      showDownloadToast(
        if (queued) {
          getApplication<Application>().getString(app.infinity.mpvz.R.string.downloads_started)
        } else {
          getApplication<Application>().getString(app.infinity.mpvz.R.string.downloads_already_downloaded)
        },
      )
    }
  }

  /** Downloads every episode of the currently selected detail season. */
  fun downloadSelectedSeason() {
    val server = _uiState.value.activeServer ?: return
    val episodes = _uiState.value.detailEpisodes.filter { it.type == "Episode" }
    if (episodes.isEmpty()) return
    viewModelScope.launch(Dispatchers.IO) {
      var queued = 0
      episodes.forEach { episode ->
        if (enqueueJellyfinDownload(server, episode)) queued++
      }
      showDownloadToast(
        getApplication<Application>().getString(app.infinity.mpvz.R.string.downloads_episodes_queued, queued),
      )
    }
  }

  /** Downloads every episode of every season of the detail series. */
  fun downloadWholeSeries() {
    val server = _uiState.value.activeServer ?: return
    val series = _uiState.value.detailItem?.takeIf { it.isSeries } ?: return
    val seasons = _uiState.value.detailSeasons
    if (seasons.isEmpty()) return
    viewModelScope.launch(Dispatchers.IO) {
      var queued = 0
      seasons.forEach { season ->
        val episodes =
          jellyfinRepository
            .getEpisodes(server, series.id, season.id)
            .getOrDefault(emptyList())
            .filter { it.type == "Episode" }
        episodes.forEach { episode ->
          if (enqueueJellyfinDownload(server, episode)) queued++
        }
      }
      showDownloadToast(
        getApplication<Application>().getString(app.infinity.mpvz.R.string.downloads_episodes_queued, queued),
      )
    }
  }

  /**
   * Resolves the direct stream URL plus external subtitle tracks and queues them.
   * Subtitles are saved as sidecars with the video's basename so local playback
   * (and the player's sibling-subtitle autoload) picks them up automatically.
   */
  private suspend fun enqueueJellyfinDownload(
    server: JellyfinServer,
    item: JellyfinItem,
    mediaSource: JellyfinMediaSource? = null,
  ): Boolean {
    if (serverDownload(server, item.id) != null) return false

    val streamUrl = jellyfinRepository.getStreamUrl(server, item, mediaSource?.id)
    if (streamUrl.isBlank()) return false
    val subtitleTracks =
      jellyfinRepository
        .getSubtitleTracks(server = server, itemId = item.id)
        .getOrDefault(emptyList())

    val extension =
      item.container
        ?.substringBefore(',')
        ?.trim()
        ?.lowercase()
        ?.takeIf { it.isNotBlank() && it.length <= 5 }
        ?: "mkv"

    val locations = downloadManager.locations
    val isEpisode = item.type == "Episode"
    val directory: java.io.File
    val fileName: String
    val displayTitle: String
    if (isEpisode) {
      val seriesName = item.seriesName ?: item.name
      val episodeCode = "S%02dE%02d".format(item.parentIndexNumber ?: 1, item.indexNumber ?: 0)
      directory = locations.jellyfinSeasonDir(seriesName, item.parentIndexNumber)
      fileName = "${DownloadLocations.sanitizeName("$episodeCode - ${item.name}")}.$extension"
      displayTitle = "$seriesName $episodeCode - ${item.name}"
    } else {
      val titleWithYear = item.name + (item.productionYear?.let { " ($it)" } ?: "")
      directory = locations.jellyfinMovieDir(titleWithYear)
      fileName = "${DownloadLocations.sanitizeName(titleWithYear)}.$extension"
      displayTitle = titleWithYear
    }

    val meta =
      DownloadMetadata(
        source = DownloadSources.JELLYFIN,
        title = displayTitle,
        posterUrl = jellyfinRepository.getImageUrl(server, item),
        sourceUrl = streamUrl,
        jellyfinServerId = server.id.toString(),
        jellyfinItemId = item.id,
        jellyfinSeriesName = item.seriesName,
        seasonNumber = item.parentIndexNumber,
        episodeNumber = item.indexNumber,
        isAudio = item.isAudio,
      )

    downloadManager.enqueueVideo(
      url = streamUrl,
      directory = directory,
      fileName = fileName,
      meta = meta,
      // Belt and braces for reverse proxies that strip query-string auth.
      headers = JellyfinClient.playbackRequestHeaders(
        streamUrl, JellyfinClient.playbackHeaders(server.accessToken, server.serverType),
      ),
    )
    downloadManager.enqueueSubtitleSidecars(
      directory = directory,
      videoFileName = fileName,
      tracks = subtitleTracks,
      headers = mapOf(
        "X-Emby-Token" to server.accessToken,
        "X-MediaBrowser-Token" to server.accessToken,
      ),
    )
    return true
  }

  /** Plays a completed local copy with its sidecar subtitles; true when handled. */
  private fun playLocalCopyIfAvailable(
    context: Context,
    server: JellyfinServer,
    item: JellyfinItem,
    title: String,
    posterUrl: String?,
    backdropUrl: String?,
  ): Boolean {
    val download = serverDownload(server, item.id, playableOnly = true) ?: return false
    MediaUtils.playFile(
      source = download.file.absolutePath,
      context = context,
      launchSource = "jellyfin_download",
      title = title,
      subtitles = downloadManager.sidecarSubtitles(download).map { Uri.fromFile(it) },
      posterUrl = posterUrl,
      backdropUrl = backdropUrl,
      isAudio = item.isAudio,
    )
    return true
  }

  private suspend fun showDownloadToast(message: String) {
    withContext(Dispatchers.Main) {
      android.widget.Toast
        .makeText(getApplication(), message, android.widget.Toast.LENGTH_SHORT)
        .show()
    }
  }

  fun toggleItemFavorite(item: JellyfinItem) {
    val server = _uiState.value.activeServer ?: return
    val newFavoriteState = !item.isFavorite

    // Optimistic UI update
    fun updateItemInList(list: List<JellyfinItem>): List<JellyfinItem> =
      list.map { if (it.id == item.id) it.copy(isFavorite = newFavoriteState) else it }

    _uiState.update { state ->
      state.copy(
        heroItems = updateItemInList(state.heroItems),
        resumeItems = updateItemInList(state.resumeItems),
        latestMovies = updateItemInList(state.latestMovies),
        latestShows = updateItemInList(state.latestShows),
        librarySections = state.librarySections.map { it.copy(items = updateItemInList(it.items)) },
        recommendations = updateItemInList(state.recommendations),
        currentItems = updateItemInList(state.currentItems),
        detailItem = if (state.detailItem?.id == item.id) state.detailItem.copy(isFavorite = newFavoriteState) else state.detailItem,
      )
    }

    viewModelScope.launch {
      jellyfinRepository.toggleFavorite(server, item, newFavoriteState)
    }
  }

  // ============================================================================
  // Server Management & Playback
  // ============================================================================

  fun addServer(
    serverUrl: String,
    serverName: String,
    authMode: JellyfinAuthMode,
    username: String = "",
    password: String = "",
    token: String = "",
    existingServerId: Long? = null,
    serverType: MediaServerType = MediaServerType.JELLYFIN,
    onSuccess: () -> Unit,
  ) {
    viewModelScope.launch {
      _uiState.update { it.copy(isAuthenticating = true, authError = null) }

      try {
        val serverToSave =
          if (authMode == JellyfinAuthMode.CREDENTIALS) {
            val authResult =
              withTimeout(30_000L) {
              jellyfinRepository.authenticate(serverUrl, username, password, serverType).getOrThrow()
              }

            if (subtitlesPreferences.preferredLanguages.get().isBlank() && !authResult.subtitleLanguage.isNullOrBlank()) {
              subtitlesPreferences.preferredLanguages.set(authResult.subtitleLanguage)
            }
            if (audioPreferences.preferredLanguages.get().isBlank() && !authResult.audioLanguage.isNullOrBlank()) {
              audioPreferences.preferredLanguages.set(authResult.audioLanguage)
            }

            val effectiveUrl = authResult.normalizedServerUrl.ifBlank { JellyfinClient.normalizeUrl(serverUrl) }

            JellyfinServer(
              id = existingServerId ?: 0,
              name = serverName.ifBlank { "${serverType.displayName} (${authResult.username})" },
              serverUrl = effectiveUrl,
              userId = authResult.userId,
              username = authResult.username,
              accessToken = authResult.accessToken,
              lastConnected = System.currentTimeMillis(),
              serverType = serverType,
            )
          } else {
            require(serverType == MediaServerType.JELLYFIN) { "Use your Emby username and password" }
            val user =
              withTimeout(30_000L) {
                jellyfinRepository.validateToken(serverUrl, token).getOrThrow()
              }

            if (subtitlesPreferences.preferredLanguages.get().isBlank() && !user.subtitleLanguage.isNullOrBlank()) {
              subtitlesPreferences.preferredLanguages.set(user.subtitleLanguage)
            }
            if (audioPreferences.preferredLanguages.get().isBlank() && !user.audioLanguage.isNullOrBlank()) {
              audioPreferences.preferredLanguages.set(user.audioLanguage)
            }

            val effectiveUrl = user.normalizedServerUrl.ifBlank { JellyfinClient.normalizeUrl(serverUrl) }

            JellyfinServer(
              id = existingServerId ?: 0,
              name = serverName.ifBlank { "Jellyfin (${user.name})" },
              serverUrl = effectiveUrl,
              userId = user.id,
              username = user.name,
              accessToken = token.trim(),
              lastConnected = System.currentTimeMillis(),
              serverType = serverType,
            )
          }

        val savedServer =
          if (existingServerId != null && existingServerId > 0) {
            jellyfinRepository.updateServer(serverToSave)
            serverToSave
          } else {
            val id = jellyfinRepository.saveServer(serverToSave)
            serverToSave.copy(id = id)
          }
        // A successful Jellyfin connection can enable the Jellyfin tab automatically, while
        // still respecting the user's global preference for this behavior.
        if (appearancePreferences.autoShowJellyfinTab.get()) {
          appearancePreferences.showJellyfinTab.set(true)
        }
        _uiState.update {
          it.copy(
            isAuthenticating = false,
            authError = null,
            activeServer = savedServer,
          )
        }
        selectServer(savedServer)
        if (!appearancePreferences.showJellyfinTab.get()) {
          appearancePreferences.showJellyfinTab.set(true)
        }
        onSuccess()
      } catch (e: Exception) {
        val message =
          if (e is TimeoutCancellationException) {
            "Connection timed out. Check the server address and credentials."
          } else {
            e.localizedMessage ?: "Failed to connect to Jellyfin server"
          }
        _uiState.update {
          it.copy(
            isAuthenticating = false,
            authError = message,
          )
        }
      }
    }
  }

  fun deleteServer(server: JellyfinServer) {
    dismissSources()
    viewModelScope.launch {
      jellyfinRepository.deleteServer(server)
      val remaining = jellyfinRepository.allServers.firstOrNull() ?: emptyList()
      val newActive = remaining.firstOrNull { it.id != server.id }
      _uiState.update {
        it.copy(
          activeServer = newActive,
          openLibrary = null,
          currentItems = emptyList(),
          libraries = emptyList(),
          resumeItems = emptyList(),
          heroItems = emptyList(),
          latestMovies = emptyList(),
          latestShows = emptyList(),
          librarySections = emptyList(),
        )
      }
      if (newActive != null) {
        loadHomeDashboard(newActive)
      }
    }
  }

  fun showSources(item: JellyfinItem, startFromBeginning: Boolean = false, forceRefresh: Boolean = false) {
    val server = _uiState.value.activeServer ?: return
    if (!item.isVideo) return
    sourceJob?.cancel()
    linkCheckQueue?.cancel()
    playbackFallbackId = null
    val maxLinks = advancedPreferences.maxFetchedLinks.get()
    val checkLinks = advancedPreferences.checkWorkingLinks.get()
    val checkBudget = JellyfinLinkCheckBudget(advancedPreferences.maxCheckedLinks.get())
    val current = _uiState.value
    val initialSources = (item.mediaSources +
      current.detailItem?.takeIf { it.id == item.id }?.mediaSources.orEmpty() +
      current.sourceSelection?.takeIf { it.item.id == item.id && it.serverId == server.id }?.sources.orEmpty() +
      jellyfinRepository.cachedSources(server, item.id))
      .associateBy { it.id }.values.toList()
    val selection = JellyfinSourceSelection(
      item, server.id, startFromBeginning, requestId = ++sourceRequestId,
      sources = JellyfinLinkPolicy.limited(initialSources, maxLinks), checkingEnabled = checkLinks,
    )
    _uiState.update { it.copy(sourceSelection = selection) }
    val checks = JellyfinLinkCheckQueue(
      parentScope = viewModelScope,
      onStatus = { sourceId, status ->
        _uiState.update { state ->
          val currentSelection = state.sourceSelection
          if (currentSelection?.requestId != selection.requestId || state.activeServer?.id != server.id) state
          else state.copy(sourceSelection = currentSelection.copy(
            linkStatus = currentSelection.linkStatus + (sourceId to status),
            checkSourceIds = currentSelection.checkSourceIds + sourceId,
          ))
        }
      },
      check = { source -> jellyfinRepository.checkStream(server, item, source) },
    )
    linkCheckQueue = checks
    sourceJob = viewModelScope.launch {
      jellyfinRepository.observePlaybackSources(server, item.id, initialSources, maxLinks, forceRefresh).collect { update ->
        // A chosen source can start before fetching ends; append later candidates to that same session.
        playbackFallbackId?.let { id ->
          JellyfinPlaybackFallbacks.get(id)?.update(playbackCandidates(server, item, update.sources))
        }
        val toCheck = if (checkLinks) checkBudget.select(update.sources.map { it.id }) else emptySet()
        _uiState.update {
          if (it.sourceSelection?.requestId != selection.requestId || it.activeServer?.id != server.id) it
          else it.copy(sourceSelection = it.sourceSelection!!.copy(
            sources = update.sources,
            checkSourceIds = it.sourceSelection!!.checkSourceIds + toCheck,
            isLoading = update.isLoading,
            retryAttempt = update.retryAttempt,
            error = when {
              update.isLoading -> null
              update.sources.isEmpty() -> JellyfinSourceErrors.emptySelectionMessage(update.error)
              update.error != null -> "Some links could not be refreshed. Available links can still be played."
              else -> null
            },
          ))
        }
        if (checkLinks && _uiState.value.sourceSelection?.requestId == selection.requestId) {
          update.sources.filter { it.id in toCheck }.forEach { source ->
            checks.enqueue(source)
          }
        }
      }
    }
  }

  private suspend fun playbackCandidates(
    server: JellyfinServer,
    item: JellyfinItem,
    sources: List<JellyfinMediaSource>,
    status: Map<String, JellyfinLinkStatus> = emptyMap(),
  ): List<JellyfinPlaybackCandidate> = sources.map { source ->
    JellyfinPlaybackCandidate(
      source.id, jellyfinRepository.getStreamUrl(server, item, source.id),
      jellyfinRepository.getSubtitleTracks(server, item.id, source).getOrDefault(emptyList()),
      status[source.id],
      app.infinity.mpvz.domain.jellyfin.JellyfinPlaybackHints.hdr(item, source),
    )
  }

  fun dismissSources() {
    linkCheckQueue?.cancel()
    linkCheckQueue = null
    playbackFallbackId = null
    sourceJob?.cancel()
    sourceJob = null
    _uiState.update { it.copy(sourceSelection = null) }
  }

  fun retrySources() {
    val selection = _uiState.value.sourceSelection ?: return
    showSources(selection.item, selection.startFromBeginning, forceRefresh = true)
  }

  fun checkSource(sourceId: String) {
    if (!advancedPreferences.showManualLinkChecks.get()) return
    val selection = _uiState.value.sourceSelection ?: return
    if (_uiState.value.activeServer?.id != selection.serverId) return
    val source = selection.sources.firstOrNull { it.id == sourceId } ?: return
    linkCheckQueue?.enqueue(source, manual = true)
  }

  fun copySourceLink(context: Context, sourceId: String) {
    if (!advancedPreferences.copyStreamLinks.get()) return
    val selection = _uiState.value.sourceSelection ?: return
    val server = _uiState.value.activeServer?.takeIf { it.id == selection.serverId } ?: return
    val source = selection.sources.firstOrNull { it.id == sourceId } ?: return
    viewModelScope.launch(Dispatchers.IO) {
      val url = jellyfinRepository.getStreamUrl(server, selection.item, source.id)
      withContext(Dispatchers.Main) {
        if (!advancedPreferences.copyStreamLinks.get() || _uiState.value.sourceSelection?.requestId != selection.requestId ||
          _uiState.value.activeServer?.id != server.id) return@withContext
        val clip = ClipData.newPlainText("Video link", url)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
          clip.description.extras = android.os.PersistableBundle().apply {
            putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
          }
        }
        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
        if (android.os.Build.VERSION.SDK_INT < 33) android.widget.Toast.makeText(context, "Link copied", android.widget.Toast.LENGTH_SHORT).show()
      }
    }
  }

  fun prepareSourceCast(sourceId: String): app.infinity.mpvz.domain.jellyfin.JellyfinCastMedia? {
    if (!advancedPreferences.castStreamLinks.get()) return null
    val selection = _uiState.value.sourceSelection ?: return null
    val server = _uiState.value.activeServer?.takeIf { it.id == selection.serverId } ?: return null
    val source = selection.sources.firstOrNull { it.id == sourceId } ?: return null
    val duration = (selection.item.runTimeTicks ?: 0).coerceAtLeast(0) / 10_000
    return app.infinity.mpvz.domain.jellyfin.JellyfinCastMedia(
      jellyfinRepository.getStreamUrl(server, selection.item, source.id),
      selection.item.displayTitle,
      app.infinity.mpvz.domain.jellyfin.JellyfinCastPolicy.contentType(source.container),
      duration,
      app.infinity.mpvz.domain.jellyfin.JellyfinCastPolicy.positionMs(selection.item.playbackPositionTicks, duration, selection.startFromBeginning),
    )
  }

  fun playSource(context: Context, sourceId: String) {
    val selection = _uiState.value.sourceSelection ?: return
    val source = selection.sources.firstOrNull { it.id == sourceId } ?: return
    if (_uiState.value.activeServer?.id != selection.serverId) return
    val server = _uiState.value.activeServer ?: return
    linkCheckQueue?.cancel() // Manual and automatic probes must not compete with playback.
    viewModelScope.launch {
      val id = JellyfinPlaybackFallbacks.create(
        jellyfinRepository.getStreamUrl(server, selection.item, source.id),
        playbackCandidates(server, selection.item, selection.sources, selection.linkStatus),
      )
      if (_uiState.value.sourceSelection?.requestId != selection.requestId || _uiState.value.activeServer?.id != server.id) return@launch
      playbackFallbackId = id
      _uiState.update { it.copy(sourceSelection = null) }
      playItem(context, selection.item, selection.startFromBeginning, source, selection.serverId, id)
    }
  }

  fun playItem(
    context: Context,
    item: JellyfinItem,
    startFromBeginning: Boolean = false,
    mediaSource: JellyfinMediaSource? = null,
    expectedServerId: Long? = null,
    sourceSessionId: String? = null,
  ) {
    val server = _uiState.value.activeServer ?: return
    if (expectedServerId != null && server.id != expectedServerId) return
    viewModelScope.launch(Dispatchers.IO) {
      val targetItem = if (item.type == "MusicAlbum" || item.type == "MusicArtist" || (item.isFolder && item.collectionType == "music")) {
        val tracksResult = jellyfinRepository.getItems(server = server, parentId = item.id, includeItemTypes = "Audio").getOrNull()
        tracksResult?.items?.firstOrNull() ?: item
      } else if (item.isSeries) {
        // A series played before its detail list loads still needs chronological episodes.
        // Sorting names with Limit=1 could choose e.g. S2E15 "2 Prime Suspects!" over S1E1.
        val unplayedEpisode = if (startFromBeginning) null else jellyfinRepository.getEpisodes(
          server = server,
          seriesId = item.id,
          seasonId = null,
          unplayedOnly = true,
          limit = 1,
        ).getOrNull()?.firstOrNull()

        unplayedEpisode ?: jellyfinRepository.getEpisodes(
          server = server,
          seriesId = item.id,
          seasonId = null,
          limit = 1,
        ).getOrNull()?.firstOrNull() ?: run {
          withContext(Dispatchers.Main) {
            android.widget.Toast.makeText(context, "No episodes returned. Refresh the series and try again.", android.widget.Toast.LENGTH_LONG).show()
          }
          return@launch
        }
      } else {
        item
      }

      val isAudio = targetItem.isAudio || targetItem.type == "Audio" || targetItem.type == "Song" || item.type == "MusicAlbum" || item.type == "MusicArtist" || item.collectionType == "music"
      val streamUrl = jellyfinRepository.getStreamUrl(server, targetItem, mediaSource?.id)
      val mediaIdentifier = PlaybackIdentity.forUri(streamUrl)
      val posterUrl = jellyfinRepository.getImageUrl(server, targetItem)
      val backdropUrl = jellyfinRepository.getBackdropUrl(server, targetItem)

      val itemTitle =
        when {
          targetItem.seriesName != null && targetItem.indexNumber != null -> "${targetItem.seriesName} S${targetItem.parentIndexNumber ?: 1}E${targetItem.indexNumber} - ${targetItem.name}"
          else -> targetItem.name
        }

      // Offline-first: a completed download plays locally with its sidecar subtitles.
      if (!isAudio && mediaSource == null) {
        val localDownload = serverDownload(server, targetItem.id, playableOnly = true)
        if (localDownload != null) {
          if (startFromBeginning) {
            runCatching {
              playbackStateRepository.deleteByTitle(PlaybackIdentity.forUri(localDownload.file.absolutePath))
              playbackStateRepository.deleteByTitle(
                PlaybackIdentity.forUri(Uri.fromFile(localDownload.file).toString()),
              )
            }
          }
          withContext(Dispatchers.Main) {
            playLocalCopyIfAvailable(
              context = context,
              server = server,
              item = targetItem,
              title = itemTitle,
              posterUrl = posterUrl,
              backdropUrl = backdropUrl,
            )
          }
          return@launch
        }
      }

      if (!isAudio && mediaSource == null) {
        withContext(Dispatchers.Main) {
          if (_uiState.value.activeServer?.id == server.id) showSources(targetItem, startFromBeginning)
        }
        return@launch
      }

      if (startFromBeginning) {
        runCatching {
          playbackStateRepository.deleteByTitle(mediaIdentifier)
          playbackStateRepository.deleteByTitle(streamUrl)
        }
      }

      val freshItemDeferred =
        async {
          if (!startFromBeginning && mediaSource == null) {
            jellyfinRepository.getItem(server, targetItem.id).getOrNull()
          } else {
            null
          }
        }

      val subsDeferred =
        async {
          if (!isAudio) {
            jellyfinRepository
              .getSubtitleTracks(server = server, itemId = targetItem.id, mediaSource = mediaSource)
              .getOrDefault(emptyList())
          } else {
            emptyList()
          }
        }

      val freshItem = freshItemDeferred.await() ?: targetItem
      val effectivePositionTicks =
        if (!startFromBeginning) {
          freshItem.playbackPositionTicks ?: targetItem.playbackPositionTicks ?: 0L
        } else {
          0L
        }
      val positionSeconds = (effectivePositionTicks / JellyfinClient.TICKS_PER_SECOND).toInt()

      if (positionSeconds > 0 && !isAudio) {
        val durationSec = (freshItem.runTimeTicks ?: targetItem.runTimeTicks ?: 0L) / JellyfinClient.TICKS_PER_SECOND
        runCatching {
          val existing = playbackStateRepository.getVideoDataByTitle(mediaIdentifier)
          val stateToSave =
            existing?.copy(
              lastPosition = positionSeconds,
              timeRemaining = (durationSec - positionSeconds).toInt().coerceAtLeast(0),
            ) ?: PlaybackStateEntity(
              mediaTitle = mediaIdentifier,
              lastPosition = positionSeconds,
              playbackSpeed = 1.0,
              videoZoom = 0f,
              sid = -1,
              secondarySid = -1,
              subDelay = 0,
              subSpeed = 1.0,
              aid = -1,
              audioDelay = 0,
              timeRemaining = (durationSec - positionSeconds).toInt().coerceAtLeast(0),
            )
          playbackStateRepository.upsert(stateToSave)
        }
      }

      // Audio retains its existing reporting; video reports after the player loads the chosen source.
      if (isAudio) launch {
        jellyfinRepository.reportPlaybackStart(
          serverType = server.serverType,
          serverUrl = server.serverUrl,
          token = server.accessToken,
          itemId = targetItem.id,
          positionTicks = effectivePositionTicks,
          mediaSourceId = mediaSource?.id,
        )
      }

      val externalSubs = subsDeferred.await()

      var playlistArtists: List<String> = emptyList()
      val playlistData =
        if (isAudio) {
          val audioSource =
            if (item.id == "virtual_favorites_playlist" || item.id == "favorites") {
              jellyfinRepository.getItems(
                server = server,
                parentId = null,
                includeItemTypes = "Audio",
                isFavorite = true,
                sortBy = JellyfinSortBy.NAME,
                limit = 500,
              ).getOrNull()?.items.orEmpty()
            } else if (item.type == "MusicAlbum" || item.type == "MusicArtist" || (item.isFolder && item.collectionType == "music") || item.type == "Playlist") {
              jellyfinRepository.getItems(server = server, parentId = item.id, includeItemTypes = "Audio").getOrNull()?.items.orEmpty()
            } else {
              val potentialSources = listOf(
                _uiState.value.detailEpisodes,
                _uiState.value.musicTracks,
                _uiState.value.musicJumpBackIn,
                _uiState.value.musicFavorites,
                _uiState.value.latestMusic,
                _uiState.value.currentItems,
              )
              val matchedList = potentialSources.firstOrNull { list ->
                list.any { it.id == targetItem.id }
              }?.filter { it.isAudio || it.type == "Audio" || it.type == "Song" }

              if (!matchedList.isNullOrEmpty() && matchedList.any { it.id == targetItem.id }) {
                matchedList
              } else {
                listOf(targetItem)
              }
            }

          if (audioSource.isNotEmpty()) {
            val uris = ArrayList<Uri>(audioSource.size)
            val titles = ArrayList<String>(audioSource.size)
            val artworks = ArrayList<String>(audioSource.size)
            playlistArtists = audioSource.map { track -> track.seriesName ?: targetItem.seriesName ?: "" }
            var targetIdx = 0
            audioSource.forEachIndexed { idx, track ->
              if (track.id == targetItem.id) targetIdx = idx
              val tUrl = jellyfinRepository.getStreamUrl(server, track)
              val aUrl = jellyfinRepository.getImageUrl(server, track)
              uris.add(Uri.parse(tUrl))
              titles.add(track.name)
              artworks.add(aUrl)
            }
            Triple(uris, titles, targetIdx) to artworks
          } else {
            Triple(emptyList<Uri>(), emptyList<String>(), 0) to emptyList<String>()
          }
        } else if (targetItem.type == "Episode") {
          val episodesSource =
            _uiState.value.detailEpisodes.ifEmpty {
              _uiState.value.currentItems.filter { it.type == "Episode" }
            }

          if (episodesSource.size > 1 && episodesSource.any { it.id == targetItem.id }) {
            val uris = ArrayList<Uri>(episodesSource.size)
            val titles = ArrayList<String>(episodesSource.size)
            var targetIdx = 0
            episodesSource.forEachIndexed { index, ep ->
              if (ep.id == targetItem.id) targetIdx = index
              uris.add(Uri.parse(if (ep.id == targetItem.id) streamUrl else jellyfinRepository.getStreamUrl(server, ep)))
              titles.add(
                when {
                  ep.seriesName != null && ep.indexNumber != null ->
                    "${ep.seriesName} S${ep.parentIndexNumber ?: 1}E${ep.indexNumber} - ${ep.name}"
                  else -> ep.name
                },
              )
            }
            Triple(uris, titles, targetIdx) to emptyList<String>()
          } else {
            Triple(emptyList<Uri>(), emptyList<String>(), 0) to emptyList<String>()
          }
        } else {
          Triple(emptyList<Uri>(), emptyList<String>(), 0) to emptyList<String>()
        }

      val (playlistUris, playlistTitles, playlistIndex) = playlistData.first
      val playlistArtworkUrls = playlistData.second

      val headers = JellyfinClient.playbackHeaders(server.accessToken, server.serverType)

      withContext(Dispatchers.Main) {
        if (_uiState.value.activeServer?.id != server.id) return@withContext
        MediaUtils.playFile(
          source = streamUrl,
          context = context,
          jellyfinSourceSessionId = sourceSessionId,
          selectedSourceHdr = app.infinity.mpvz.domain.jellyfin.JellyfinPlaybackHints.hdr(targetItem, mediaSource),
          launchSource = if (isAudio) "jellyfin_music" else "jellyfin_stream",
          title = itemTitle,
          headers = headers,
          mediaDescription = targetItem.overview,
          posterUrl = posterUrl,
          backdropUrl = backdropUrl,
          subtitleTracks = externalSubs,
          playlist = playlistUris,
          playlistIndex = playlistIndex,
          playlistTitles = playlistTitles,
          playlistArtists = playlistArtists,
          playlistArtworkUrls = playlistArtworkUrls,
          isAudio = isAudio,
        )
      }
    }
  }

  fun playSelected(
    context: Context,
    items: List<JellyfinItem>,
  ) {
    val server = _uiState.value.activeServer ?: return
    val videoPlayable = items.filter { it.isVideo }
    val audioPlayable = items.filter { it.isAudio || it.type == "Audio" || it.type == "Song" }
    val isAudio = videoPlayable.isEmpty() && audioPlayable.isNotEmpty()
    val playable = if (isAudio) audioPlayable else videoPlayable
    if (playable.isEmpty()) return

    val firstItem = playable.first()
    val streamUrl = jellyfinRepository.getStreamUrl(server, firstItem)
    val mediaIdentifier = PlaybackIdentity.forUri(streamUrl)
    val posterUrl = jellyfinRepository.getImageUrl(server, firstItem)
    val backdropUrl = jellyfinRepository.getBackdropUrl(server, firstItem)

    val itemTitle =
      when {
        firstItem.seriesName != null && firstItem.indexNumber != null ->
          "${firstItem.seriesName} S${firstItem.parentIndexNumber ?: 1}E${firstItem.indexNumber} - ${firstItem.name}"
        else -> firstItem.name
      }

    val playlistUris = ArrayList<Uri>(playable.size)
    val playlistTitles = ArrayList<String>(playable.size)
    playable.forEach { item ->
      playlistUris.add(Uri.parse(jellyfinRepository.getStreamUrl(server, item)))
      playlistTitles.add(
        when {
          item.seriesName != null && item.indexNumber != null ->
            "${item.seriesName} S${item.parentIndexNumber ?: 1}E${item.indexNumber} - ${item.name}"
          else -> item.name
        },
      )
    }

    val headers = JellyfinClient.playbackHeaders(server.accessToken, server.serverType)

    viewModelScope.launch(Dispatchers.IO) {
      val freshItem = jellyfinRepository.getItem(server, firstItem.id).getOrNull() ?: firstItem
      val effectivePositionTicks = freshItem.playbackPositionTicks ?: firstItem.playbackPositionTicks ?: 0L
      val positionSeconds = (effectivePositionTicks / JellyfinClient.TICKS_PER_SECOND).toInt()

      if (positionSeconds > 0 && !isAudio) {
        val durationSec = (freshItem.runTimeTicks ?: firstItem.runTimeTicks ?: 0L) / JellyfinClient.TICKS_PER_SECOND
        runCatching {
          val existing = playbackStateRepository.getVideoDataByTitle(mediaIdentifier)
          val stateToSave =
            existing?.copy(
              lastPosition = positionSeconds,
              timeRemaining = (durationSec - positionSeconds).toInt().coerceAtLeast(0),
            ) ?: PlaybackStateEntity(
              mediaTitle = mediaIdentifier,
              lastPosition = positionSeconds,
              playbackSpeed = 1.0,
              videoZoom = 0f,
              sid = -1,
              secondarySid = -1,
              subDelay = 0,
              subSpeed = 1.0,
              aid = -1,
              audioDelay = 0,
              timeRemaining = (durationSec - positionSeconds).toInt().coerceAtLeast(0),
            )
          playbackStateRepository.upsert(stateToSave)
        }
      }

      launch {
        jellyfinRepository.reportPlaybackStart(
          serverType = server.serverType,
          serverUrl = server.serverUrl,
          token = server.accessToken,
          itemId = firstItem.id,
          positionTicks = effectivePositionTicks,
        )
      }

      val playlistArtworks = if (isAudio) playable.map { jellyfinRepository.getImageUrl(server, it) } else emptyList()
      withContext(Dispatchers.Main) {
        MediaUtils.playFile(
          source = streamUrl,
          context = context,
          launchSource = if (isAudio) "jellyfin_music" else "jellyfin_stream",
          title = itemTitle,
          headers = headers,
          mediaDescription = firstItem.overview,
          posterUrl = posterUrl,
          backdropUrl = backdropUrl,
          playlist = playlistUris,
          playlistIndex = 0,
          playlistTitles = playlistTitles,
          playlistArtists = if (isAudio) playable.map { it.seriesName.orEmpty() } else emptyList(),
          playlistArtworkUrls = playlistArtworks,
          isAudio = isAudio,
        )
      }
    }
  }

  fun togglePlayed(item: JellyfinItem) {
    val server = _uiState.value.activeServer ?: return
    viewModelScope.launch {
      val targetPlayed = !item.isPlayed
      val result =
        if (targetPlayed) {
          jellyfinRepository.markPlayed(server, item)
        } else {
          jellyfinRepository.markUnplayed(server, item)
        }
      result.onSuccess {
        _uiState.update { state ->
          fun updateList(list: List<JellyfinItem>) =
            list.map {
              if (it.id == item.id) {
                it.copy(
                  isPlayed = targetPlayed,
                  playbackPositionTicks = if (targetPlayed) 0L else it.playbackPositionTicks,
                )
              } else {
                it
              }
            }
          state.copy(
            currentItems = updateList(state.currentItems),
            resumeItems = updateList(state.resumeItems),
            heroItems = updateList(state.heroItems),
            latestMovies = updateList(state.latestMovies),
            latestShows = updateList(state.latestShows),
            librarySections = state.librarySections.map { it.copy(items = updateList(it.items)) },
            detailItem = if (state.detailItem?.id == item.id) state.detailItem.copy(isPlayed = targetPlayed) else state.detailItem,
          )
        }
      }
    }
  }

  fun markSelectedPlayed(
    items: List<JellyfinItem>,
    played: Boolean,
  ) {
    val server = _uiState.value.activeServer ?: return
    viewModelScope.launch {
      val ids = items.map { it.id }.toSet()
      items.forEach { item ->
        launch {
          if (played) {
            jellyfinRepository.markPlayed(server, item)
          } else {
            jellyfinRepository.markUnplayed(server, item)
          }
        }
      }
      _uiState.update { state ->
        fun updateList(list: List<JellyfinItem>) =
          list.map {
            if (it.id in ids) {
              it.copy(
                isPlayed = played,
                playbackPositionTicks = if (played) 0L else it.playbackPositionTicks,
              )
            } else {
              it
            }
          }
        state.copy(
          currentItems = updateList(state.currentItems),
          resumeItems = updateList(state.resumeItems),
          heroItems = updateList(state.heroItems),
          latestMovies = updateList(state.latestMovies),
          latestShows = updateList(state.latestShows),
          librarySections = state.librarySections.map { it.copy(items = updateList(it.items)) },
        )
      }
    }
  }

  fun playRandom(context: Context) {
    val items = (_uiState.value.currentItems.ifEmpty {
      val fromSections = _uiState.value.librarySections.flatMap { it.items }
      if (fromSections.isNotEmpty()) fromSections else _uiState.value.latestMovies + _uiState.value.latestShows
    }).filter { it.isVideo }
    if (items.isNotEmpty()) {
      playItem(context, items.random())
    }
  }

  fun resumeLastPlayed(context: Context) {
    viewModelScope.launch {
      val server = _uiState.value.activeServer ?: return@launch
      val resumeItems = jellyfinRepository.getResumeItems(server, limit = 1).getOrNull()
      val itemToPlay = resumeItems?.firstOrNull() ?: _uiState.value.currentItems.firstOrNull { it.isVideo }
      if (itemToPlay != null) {
        playItem(context, itemToPlay)
      }
    }
  }

  fun getStreamUrl(item: JellyfinItem): String {
    val server = _uiState.value.activeServer ?: return ""
    return jellyfinRepository.getStreamUrl(server, item)
  }

  fun createJellyfinPlaylist(name: String, itemIds: List<String> = emptyList()) {
    val server = _uiState.value.activeServer ?: return
    viewModelScope.launch {
      val res = jellyfinRepository.createPlaylist(server, name, itemIds)
      if (res.isSuccess) {
        val library = _uiState.value.openLibrary
        if (library != null) {
          loadMusicTabItems(server, library, JellyfinMusicTab.PLAYLISTS)
        }
      }
    }
  }

  fun addToJellyfinPlaylist(playlistId: String, itemIds: List<String>) {
    val server = _uiState.value.activeServer ?: return
    viewModelScope.launch {
      jellyfinRepository.addToPlaylist(server, playlistId, itemIds)
    }
  }

  companion object {
    fun factory(application: Application): ViewModelProvider.Factory =
      viewModelFactory {
        initializer {
          JellyfinViewModel(application)
        }
      }
  }
}
