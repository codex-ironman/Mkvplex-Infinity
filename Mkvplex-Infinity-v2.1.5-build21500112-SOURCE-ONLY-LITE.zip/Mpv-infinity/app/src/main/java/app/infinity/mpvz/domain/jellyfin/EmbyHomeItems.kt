/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.domain.jellyfin

/** Convert grouped episodes locally; opening a title loads its full series metadata. */
internal object EmbyHomeItems {
  fun videoItems(items: List<JellyfinItem>): List<JellyfinItem> = items.mapNotNull { item ->
    when (item.type) {
      "Movie", "Video", "Series" -> item
      "Episode" -> if (!item.seriesId.isNullOrBlank()) item.copy(
        id = item.seriesId, name = item.seriesName ?: item.name, type = "Series", isFolder = true,
        primaryImageTag = item.seriesPrimaryImageTag, backdropImageTag = null,
      ) else item
      else -> null
    }
  }.distinctBy { it.id }

  fun hasArtwork(item: JellyfinItem): Boolean =
    !item.primaryImageTag.isNullOrBlank() || !item.backdropImageTag.isNullOrBlank()

  fun heroItems(items: List<JellyfinItem>): List<JellyfinItem> {
    val illustrated = videoItems(items).filter(::hasArtwork)
    return illustrated.filterNot { it.isPlayed }.ifEmpty { illustrated }.take(15)
  }
}
