/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Cached video metadata to avoid repeated MediaInfo extractions
 * Stores duration, size, resolution, and framerate for videos that require MediaInfo processing
 */
@Entity(tableName = "video_metadata_cache")
data class VideoMetadataEntity(
  @PrimaryKey
  val path: String, // Unique identifier - absolute file path
  val size: Long, // File size in bytes
  val dateModified: Long, // Last modified timestamp (for cache invalidation)
  val duration: Long, // Duration in milliseconds
  val width: Int, // Video width in pixels
  val height: Int, // Video height in pixels
  val fps: Float, // Framerate in frames per second
  val hasEmbeddedSubtitles: Boolean = false,
  val subtitleCodec: String = "",
  val lastScanned: Long, // When this metadata was extracted (timestamp)
)
