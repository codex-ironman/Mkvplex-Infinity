/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.domain.jellyfin

import java.util.Locale

object JellyfinSourceFilter {
  const val UNKNOWN = "Unspecified"
  private data class Language(val name: String, val codes: Set<String>, val tags: Set<String>)
  private fun language(name: String, codes: String, tags: String = name) =
    Language(name, codes.split(',').toSet(), tags.lowercase(Locale.ROOT).split(',').toSet())

  private val languages = listOf(
    language("Hindi", "hi,hin", "hindi,hin,हिन्दी,हिंदी"),
    language("Telugu", "te,tel", "telugu,telgu,tel,తెలుగు"),
    language("Tamil", "ta,tam", "tamil,tam,தமிழ்"),
    language("English", "en,eng", "english,eng"),
    language("Malayalam", "ml,mal", "malayalam,mal,മലയാളം"),
    language("Kannada", "kn,kan", "kannada,kan,ಕನ್ನಡ"),
    language("Bengali", "bn,ben", "bengali,bangla,ben,বাংলা"),
    language("Marathi", "mr,mar", "marathi,mar,मराठी"),
    language("Punjabi", "pa,pan,pun", "punjabi,pan,pun,ਪੰਜਾਬੀ"),
    language("Gujarati", "gu,guj", "gujarati,guj,ગુજરાતી"),
    language("Odia", "or,ori,ory", "odia,oriya,ori,ory,ଓଡ଼ିଆ"),
    language("Urdu", "ur,urd", "urdu,urd,اردو"),
    language("Japanese", "ja,jpn", "japanese,jpn"),
    language("Korean", "ko,kor", "korean,kor"),
    language("Chinese", "zh,zho,chi", "chinese,mandarin,cantonese,zho,chi"),
    language("Spanish", "es,spa", "spanish,spa"),
    language("French", "fr,fra,fre", "french,fra,fre"),
    language("German", "de,deu,ger", "german,deu,ger"),
    language("Italian", "it,ita", "italian,ita"),
    language("Portuguese", "pt,por", "portuguese,por"),
    language("Russian", "ru,rus", "russian,rus"),
    language("Arabic", "ar,ara", "arabic,ara"),
    language("Thai", "th,tha", "thai,tha"),
  )
  private val tagPatterns = languages.associate { language ->
    language.name to Regex(
      "(?<![\\p{L}\\p{N}])(?:${language.tags.joinToString("|") { Regex.escape(it) }})(?![\\p{L}\\p{N}])",
      RegexOption.IGNORE_CASE,
    )
  }
  private fun fromTags(text: String): Set<String> = tagPatterns.filterValues { it.containsMatchIn(text) }.keys

  fun audioLanguages(source: JellyfinMediaSource): Set<String> {
    val audio = source.streams.filter { it.type.equals("Audio", true) }
    val explicit = audio.flatMap { stream ->
      val value = stream.language.orEmpty().lowercase(Locale.ROOT).trim()
      val code = value.substringBefore('-').substringBefore('_')
      languages.filter { code in it.codes || value in it.tags }.map { it.name }
    }.toSet()
    // Subtitle languages never determine the language of a playable audio version.
    if (explicit.isNotEmpty()) return explicit
    val audioLabels = fromTags(audio.mapNotNull { it.displayTitle }.joinToString(" "))
    if (audioLabels.isNotEmpty()) return audioLabels
    return fromTags(source.name).ifEmpty { setOf(UNKNOWN) }
  }

  data class Entry(val source: JellyfinMediaSource, val languages: Set<String>, val searchText: String)

  fun index(sources: List<JellyfinMediaSource>): List<Entry> = sources.map { source ->
    val labels = audioLanguages(source)
    val aliases = languages.filter { it.name in labels }.flatMap { it.codes + it.tags }
    Entry(source, labels, (listOf(source.name, source.description) + labels + aliases).joinToString(" ").lowercase(Locale.ROOT))
  }

  fun availableLanguages(entries: List<Entry>): List<String> = entries.flatMap { it.languages }.distinct()
    .sortedWith(compareBy<String> { it == UNKNOWN }.thenBy { it })

  fun filter(entries: List<Entry>, language: String?, query: String): List<JellyfinMediaSource> {
    val terms = query.lowercase(Locale.ROOT).trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    return entries.filter { entry ->
      (language == null || language in entry.languages) && terms.all { it in entry.searchText }
    }.map { it.source }
  }
}
