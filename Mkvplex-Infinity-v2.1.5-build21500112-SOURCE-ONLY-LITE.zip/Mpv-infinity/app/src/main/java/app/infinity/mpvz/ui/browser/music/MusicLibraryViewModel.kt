/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

package app.infinity.mpvz.ui.browser.music

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.infinity.mpvz.database.entities.PlaylistEntity
import app.infinity.mpvz.database.repository.PlaylistRepository
import app.infinity.mpvz.ui.player.PlaybackItem
import app.infinity.mpvz.ui.player.PlaybackSession
import app.infinity.mpvz.ui.player.PreparedPlaybackLaunchStore
import app.infinity.mpvz.ui.player.PlayerActivity
import app.infinity.mpvz.utils.history.RecentlyPlayedOps
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

import app.infinity.mpvz.utils.media.MediaLibraryEvents
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException

class MusicLibraryViewModel : ViewModel(), KoinComponent {

  private val context: Context by inject()
  private val playlistRepository: PlaylistRepository by inject()
  private val browserPreferences: app.infinity.mpvz.preferences.BrowserPreferences by inject()
  private val audioPreferences: app.infinity.mpvz.preferences.AudioPreferences by inject()
  private val foldersPreferences: app.infinity.mpvz.preferences.FoldersPreferences by inject()
  private var refreshJob: Job? = null

  val visibleTabs: StateFlow<List<MusicTab>> = combine(
    audioPreferences.musicTabOrder.changes(),
    audioPreferences.enabledMusicTabs.changes(),
  ) { orderList, enabledSet ->
    val tabMap = MusicTab.entries.associateBy { it.name }
    val orderedTabs = (orderList.mapNotNull { tabMap[it] } + (MusicTab.entries - orderList.mapNotNull { tabMap[it] }.toSet())).distinct()
    val filtered = orderedTabs.filter { it.name in enabledSet }
    if (filtered.isEmpty()) listOf(MusicTab.SONGS) else filtered
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MusicTab.entries.toList())

  // Keep the unfiltered MediaStore result so changing the minimum-duration preference can update
  // Songs, Albums and Artists immediately without rescanning storage on every slider movement.
  private val _allSongs = MutableStateFlow<List<MusicSong>>(emptyList())

  private val _songs = MutableStateFlow<List<MusicSong>>(emptyList())
  val songs: StateFlow<List<MusicSong>> = _songs.asStateFlow()

  private val _albums = MutableStateFlow<List<MusicAlbum>>(emptyList())
  val albums: StateFlow<List<MusicAlbum>> = _albums.asStateFlow()

  private val _artists = MutableStateFlow<List<MusicArtist>>(emptyList())
  val artists: StateFlow<List<MusicArtist>> = _artists.asStateFlow()

  val playlists: StateFlow<List<PlaylistEntity>> =
    playlistRepository.observeAllPlaylists(isAudio = true)
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _selectedTab = MutableStateFlow(MusicTab.SONGS)
  val selectedTab: StateFlow<MusicTab> = _selectedTab.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  val sortField: StateFlow<MusicSortField> = browserPreferences.musicSortField.stateIn(viewModelScope)
  val sortOrder: StateFlow<MusicSortOrder> = browserPreferences.musicSortOrder.stateIn(viewModelScope)

  val viewMode: StateFlow<MusicViewMode> = browserPreferences.musicViewMode.stateIn(viewModelScope)

  private val _selectedAlbum = MutableStateFlow<MusicAlbum?>(null)
  val selectedAlbum: StateFlow<MusicAlbum?> = _selectedAlbum.asStateFlow()

  private val _selectedArtist = MutableStateFlow<MusicArtist?>(null)
  val selectedArtist: StateFlow<MusicArtist?> = _selectedArtist.asStateFlow()

  private val _isLoading = MutableStateFlow(false)
  val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

  val recentlyPlayedFilePath: StateFlow<String?> =
    RecentlyPlayedOps.observeLastPlayedPath()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val isPlaybackActive: StateFlow<Boolean> =
    PlaybackSession.state
      .map { session -> session.currentItem != null }
      .distinctUntilChanged()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

  init {
    viewModelScope.launch {
      playlistRepository.getOrCreateFavoritesPlaylist(isAudio = true)
    }
    viewModelScope.launch {
      combine(
        browserPreferences.minimumAudioDurationSeconds.changes(),
        foldersPreferences.blacklistedAudioFolders.changes()
      ) { minimumSeconds, blacklist ->
        Pair(minimumSeconds, blacklist)
      }
        .distinctUntilChanged()
        .collect { (minimumSeconds, blacklist) -> applyFilters(minimumSeconds, blacklist) }
    }
    viewModelScope.launch {
      MediaLibraryEvents.changes.collectLatest {
        scanLibrary(context)
      }
    }
    scanLibrary(context)
  }

  val filteredSongs: StateFlow<List<MusicSong>> = combine(
    _songs, _searchQuery, sortField, sortOrder
  ) { songList, query, field, order ->
    var result = songList
    if (query.isNotBlank()) {
      val q = query.trim().lowercase()
      result = result.filter {
        it.title.lowercase().contains(q) ||
          it.artist.lowercase().contains(q) ||
          it.album.lowercase().contains(q)
      }
    }
    val sorted = when (field) {
      MusicSortField.TITLE -> result.sortedBy { it.title.lowercase() }
      MusicSortField.ARTIST -> result.sortedBy { it.artist.lowercase() }
      MusicSortField.ALBUM -> result.sortedBy { it.album.lowercase() }
      MusicSortField.DURATION -> result.sortedBy { it.durationMs }
      MusicSortField.DATE_ADDED -> result.sortedBy { it.dateAdded }
      MusicSortField.TRACK_COUNT, MusicSortField.YEAR -> result.sortedBy { it.year }
    }
    if (order == MusicSortOrder.DESCENDING) sorted.reversed() else sorted
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val filteredAlbums: StateFlow<List<MusicAlbum>> = combine(
    _albums, _searchQuery, sortField, sortOrder
  ) { albumList, query, field, order ->
    var result = albumList
    if (query.isNotBlank()) {
      val q = query.trim().lowercase()
      result = result.filter {
        it.title.lowercase().contains(q) || it.artist.lowercase().contains(q)
      }
    }
    val sorted = when (field) {
      MusicSortField.TITLE, MusicSortField.ALBUM -> result.sortedBy { it.title.lowercase() }
      MusicSortField.ARTIST -> result.sortedBy { it.artist.lowercase() }
      MusicSortField.TRACK_COUNT -> result.sortedBy { it.songCount }
      MusicSortField.YEAR -> result.sortedBy { it.year }
      else -> result.sortedBy { it.title.lowercase() }
    }
    if (order == MusicSortOrder.DESCENDING) sorted.reversed() else sorted
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val filteredArtists: StateFlow<List<MusicArtist>> = combine(
    _artists, _searchQuery, sortField, sortOrder
  ) { artistList, query, field, order ->
    var result = artistList
    if (query.isNotBlank()) {
      val q = query.trim().lowercase()
      result = result.filter { it.name.lowercase().contains(q) }
    }
    val sorted = when (field) {
      MusicSortField.TRACK_COUNT -> result.sortedBy { it.songCount }
      else -> result.sortedBy { it.name.lowercase() }
    }
    if (order == MusicSortOrder.DESCENDING) sorted.reversed() else sorted
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  suspend fun refreshLibrary(context: Context) {
    _isLoading.value = true
    try {
      _allSongs.value = MusicLibraryScanner.scanSongs(context.applicationContext)
      applyFilters(
        browserPreferences.minimumAudioDurationSeconds.get(),
        foldersPreferences.blacklistedAudioFolders.get()
      )
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      e.printStackTrace()
    } finally {
      _isLoading.value = false
    }
  }

  /**
   * Minimum duration is a lower bound only. There is intentionally no upper bound: if the user
   * selects 30 seconds, every 30s, 3min, 30min, or multi-hour audio file remains in the library.
   * Also filters out songs whose path starts with any blacklisted audio folder path.
   */
  private fun applyFilters(minimumSeconds: Int, blacklist: Set<String>) {
    val minimumMs = minimumSeconds.coerceAtLeast(0).toLong() * 1000L
    val visibleSongs = _allSongs.value.filter { song ->
      val meetsDuration = (minimumMs == 0L || song.durationMs >= minimumMs)
      val isNotBlacklisted = blacklist.none { folderPath ->
        song.path.equals(folderPath, ignoreCase = true) ||
          song.path.startsWith(if (folderPath.endsWith("/")) folderPath else "$folderPath/", ignoreCase = true)
      }
      meetsDuration && isNotBlacklisted
    }

    _songs.value = visibleSongs
    _albums.value = buildAlbums(visibleSongs)
    _artists.value = buildArtists(visibleSongs)

    // Never leave the detail screen pointing at an album/artist that was completely filtered out.
    _selectedAlbum.value = _selectedAlbum.value?.takeIf { selected -> _albums.value.any { it.id == selected.id } }
    _selectedArtist.value = _selectedArtist.value?.takeIf { selected -> _artists.value.any { it.id == selected.id } }
  }

  private fun buildAlbums(songs: List<MusicSong>): List<MusicAlbum> =
    songs
      .groupBy { song -> if (song.albumId > 0) song.albumId else song.album.hashCode().toLong() }
      .map { (albumId, albumSongs) ->
        val firstSong = albumSongs.first()
        MusicAlbum(
          id = albumId,
          title = firstSong.album,
          artist = firstSong.artist,
          songCount = albumSongs.size,
          year = albumSongs.maxOfOrNull { it.year } ?: 0,
          albumArtUri = firstSong.albumArtUri,
        )
      }
      .sortedBy { it.title.lowercase() }

  private fun buildArtists(songs: List<MusicSong>): List<MusicArtist> =
    songs
      .groupBy { it.artist.lowercase().trim() }
      .map { (_, artistSongs) ->
        val firstSong = artistSongs.first()
        MusicArtist(
          id = firstSong.artist.hashCode().toLong(),
          name = firstSong.artist,
          songCount = artistSongs.size,
          albumCount = artistSongs.map { it.albumId }.distinct().size,
        )
      }
      .sortedBy { it.name.lowercase() }

  fun scanLibrary(context: Context? = null) {
    refreshJob?.cancel()
    refreshJob = viewModelScope.launch {
      refreshLibrary((context ?: this@MusicLibraryViewModel.context).applicationContext)
    }
  }

  override fun onCleared() {
    refreshJob?.cancel()
    refreshJob = null
    super.onCleared()
  }

  fun setTab(tab: MusicTab) {
    _selectedTab.value = tab
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun setSortField(field: MusicSortField) {
    browserPreferences.musicSortField.set(field)
  }

  fun toggleSortOrder() {
    val nextOrder = if (sortOrder.value == MusicSortOrder.ASCENDING) {
      MusicSortOrder.DESCENDING
    } else {
      MusicSortOrder.ASCENDING
    }
    browserPreferences.musicSortOrder.set(nextOrder)
  }

  fun setSortOrder(order: MusicSortOrder) {
    browserPreferences.musicSortOrder.set(order)
  }

  fun toggleViewMode() {
    val nextMode = if (viewMode.value == MusicViewMode.GRID) MusicViewMode.LIST else MusicViewMode.GRID
    browserPreferences.musicViewMode.set(nextMode)
  }

  fun setViewMode(mode: MusicViewMode) {
    browserPreferences.musicViewMode.set(mode)
  }

  fun selectAlbum(album: MusicAlbum?) {
    _selectedAlbum.value = album
  }

  fun selectArtist(artist: MusicArtist?) {
    _selectedArtist.value = artist
  }

  fun playSong(context: Context, song: MusicSong, songList: List<MusicSong> = _songs.value) {
    if (songList.isEmpty()) return
    val index = songList.indexOfFirst { it.id == song.id }.coerceAtLeast(0)

    val queueItems = songList.map { item ->
      PlaybackItem.fromUri(
        uri = item.uri.toString(),
        title = item.title,
        artist = item.artist,
        mimeType = "audio/*",
        artworkUri = item.albumArtUri?.toString(),
      )
    }
    val launchToken = PreparedPlaybackLaunchStore.stage(
      items = queueItems,
      currentIndex = index,
      isExplicitQueue = true,
    )

    val intent = Intent(Intent.ACTION_VIEW, song.uri).apply {
      setClass(context, PlayerActivity::class.java)
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      putExtra("internal_launch", true)
      putExtra(PlayerActivity.EXTRA_PREPARED_PLAYBACK_QUEUE, true)
      putExtra(PlayerActivity.EXTRA_PREPARED_PLAYBACK_TOKEN, launchToken)
      putExtra("playlist_index", index)
      putExtra("launch_source", "music_library")
      putExtra("media_library_audio", true)
      putExtra("is_audio", true)
      putExtra("title", song.title)
    }
    context.startActivity(intent)
  }

  fun playAllSongs(context: Context, songsToPlay: List<MusicSong>, shuffle: Boolean = false) {
    if (songsToPlay.isEmpty()) return
    val list = if (shuffle) songsToPlay.shuffled() else songsToPlay
    val firstSong = list.first()

    val queueItems = list.map { item ->
      PlaybackItem.fromUri(
        uri = item.uri.toString(),
        title = item.title,
        artist = item.artist,
        mimeType = "audio/*",
        artworkUri = item.albumArtUri?.toString(),
      )
    }
    val launchToken = PreparedPlaybackLaunchStore.stage(
      items = queueItems,
      currentIndex = 0,
      isExplicitQueue = true,
    )

    val intent = Intent(Intent.ACTION_VIEW, firstSong.uri).apply {
      setClass(context, PlayerActivity::class.java)
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      putExtra("internal_launch", true)
      putExtra(PlayerActivity.EXTRA_PREPARED_PLAYBACK_QUEUE, true)
      putExtra(PlayerActivity.EXTRA_PREPARED_PLAYBACK_TOKEN, launchToken)
      putExtra("playlist_index", 0)
      putExtra("launch_source", if (shuffle) "music_shuffle" else "music_play_all")
      putExtra("media_library_audio", true)
      putExtra("is_audio", true)
      putExtra("title", firstSong.title)
    }
    context.startActivity(intent)
  }

  fun createPlaylist(name: String) {
    viewModelScope.launch {
      if (name.isNotBlank()) {
        playlistRepository.createPlaylist(name.trim(), isAudio = true)
      }
    }
  }

  fun deletePlaylist(playlist: PlaylistEntity) {
    if (playlist.name.equals(PlaylistRepository.FAVORITES_PLAYLIST_NAME, ignoreCase = true)) return
    viewModelScope.launch {
      playlistRepository.deletePlaylist(playlist)
    }
  }

  suspend fun deleteSongs(context: Context, songsToDelete: List<MusicSong>): Pair<Int, Int> {
    val videos = songsToDelete.map { song ->
      app.infinity.mpvz.domain.media.model.Video(
        id = song.id,
        title = song.title,
        displayName = song.title,
        path = song.path,
        uri = song.uri,
        duration = song.durationMs,
        durationFormatted = android.text.format.DateUtils.formatElapsedTime(song.durationMs / 1000),
        size = 0L,
        sizeFormatted = "",
        dateModified = song.dateAdded,
        dateAdded = song.dateAdded,
        mimeType = "audio/*",
        bucketId = "",
        bucketDisplayName = "",
        width = 0,
        height = 0,
        fps = 0f,
        resolution = "",
        isAudio = true
      )
    }
    val result = app.infinity.mpvz.utils.permission.PermissionUtils.StorageOps.deleteVideos(context.applicationContext as android.app.Application, videos)
    scanLibrary(context)
    return result
  }
}
