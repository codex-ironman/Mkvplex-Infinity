/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.domain.thumbnail

import android.app.ActivityManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.util.LruCache
import app.infinity.mpvz.data.network.client.NetworkMimeTypes
import app.infinity.mpvz.data.network.proxy.NetworkStreamingProxy
import app.infinity.mpvz.domain.media.model.Video
import app.infinity.mpvz.domain.network.NetworkConnection
import app.infinity.mpvz.preferences.ThumbnailMode
import app.infinity.mpvz.repository.NetworkRepository
import app.infinity.mpvz.ui.player.resolveLocalPath
import `is`.xyz.mpv.FastThumbnails
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import kotlinx.coroutines.yield
import org.koin.java.KoinJavaComponent
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantReadWriteLock
import kotlin.concurrent.read
import kotlin.concurrent.write
import kotlin.math.max
import kotlin.math.roundToInt

private const val NETWORK_THUMBNAIL_FAILURE_RETRY_MS = 30_000L
private const val METADATA_POSTER_FAILURE_RETRY_MS = 5 * 60_000L
private const val MAX_NETWORK_FRAME_THUMBNAIL_FILE_SIZE = 4L * 1024L * 1024L * 1024L
private const val CINEMETA_CATALOG_URL = "https://v3-cinemeta.strem.io/catalog"

class ThumbnailRepository(
  private val context: Context,
) {
  private val appearancePreferences by lazy {
    KoinJavaComponent.get<app.infinity.mpvz.preferences.AppearancePreferences>(
      app.infinity.mpvz.preferences.AppearancePreferences::class.java,
    )
  }
  private val browserPreferences by lazy {
    KoinJavaComponent.get<app.infinity.mpvz.preferences.BrowserPreferences>(
      app.infinity.mpvz.preferences.BrowserPreferences::class.java,
    )
  }
  private val networkRepository by lazy {
    KoinJavaComponent.get<NetworkRepository>(NetworkRepository::class.java)
  }

  private val memoryCache: LruCache<String, Bitmap>
  private val localDiskDir = File(context.filesDir, "thumbnails/local").apply { mkdirs() }
  private val networkDiskDir = File(context.filesDir, "thumbnails/network").apply { mkdirs() }
  private val diskCacheLock = ReentrantReadWriteLock()
  private val ongoingOperations = ConcurrentHashMap<String, Deferred<Bitmap?>>()
  private val diskVideoBaseKeyCache = ConcurrentHashMap<String, String>()
  private data class ResolvedMetadata(
    val size: Long,
    val dateModified: Long,
    val duration: Long,
  )
  private val localMetadataCache = ConcurrentHashMap<String, ResolvedMetadata>()
  private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private val maxConcurrentFolders = 3
  private val localGenerationParallelism = resolveLocalGenerationParallelism()
  private val localGenerationSemaphore = Semaphore(localGenerationParallelism)
  // Network thumbnails are independent range reads. Keep a small cap so a series folder can
  // fill promptly without opening one WebDAV decoder per visible card.
  // A decoder can issue several authenticated range requests for one MKV. Keep remote work
  // serialized so a series folder cannot burst dozens of TorBox/WebDAV requests at once.
  private val networkGenerationSemaphore = Semaphore(1)
  private val maxFolderBatchSize = 48

  private data class FolderState(
    val signature: String,
    @Volatile var nextIndex: Int = 0,
  )

  private val folderStates = ConcurrentHashMap<String, FolderState>()
  private val folderJobs = ConcurrentHashMap<String, Job>()

  // Throttle transient failures while still allowing remote files to recover during this process.
  private val networkThumbnailFailedAt = ConcurrentHashMap<String, Long>()
  private val metadataPosterFailedAt = ConcurrentHashMap<String, Long>()
  private val metadataPosterUrls = ConcurrentHashMap<String, String>()
  private val metadataPosterClient by lazy { OkHttpClient.Builder().callTimeout(10, TimeUnit.SECONDS).build() }
  private val metadataPosterJson = Json { ignoreUnknownKeys = true }

  private val _thumbnailReadyKeys =
    MutableSharedFlow<String>(
      extraBufferCapacity = 256,
    )
  val thumbnailReadyKeys: SharedFlow<String> = _thumbnailReadyKeys.asSharedFlow()

  init {
    val maxMemoryKb = (Runtime.getRuntime().maxMemory() / 1024L).toInt()
    val cacheSizeKb = maxMemoryKb / 6
    memoryCache =
      object : LruCache<String, Bitmap>(cacheSizeKb) {
        override fun sizeOf(
          key: String,
          value: Bitmap,
        ): Int = value.byteCount / 1024
      }
  }

  suspend fun getThumbnail(
    video: Video,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? =
    withContext(Dispatchers.IO) {
      val key = thumbnailKey(video, widthPx, heightPx)

      if (isNetworkUrl(video.path) && !isNetworkThumbnailAllowed(video.path)) {
        return@withContext null
      }

      synchronized(memoryCache) {
        memoryCache.get(key)
      }?.let { return@withContext it }

      ongoingOperations[key]?.let { return@withContext it.await() }

      val candidate =
        async(start = CoroutineStart.LAZY) {
          getCachedThumbnail(video, widthPx, heightPx)?.let { cached ->
            synchronized(memoryCache) {
              memoryCache.put(key, cached)
            }
            _thumbnailReadyKeys.tryEmit(key)
            return@async cached
          }

          val bitmap =
            when {
              isHttpUrl(video.path) ->
                networkGenerationSemaphore.withPermit {
                  getOrCreateNetworkVideoThumbnail(video, widthPx, heightPx)
                }
              isNetworkUrl(video.path) -> null
              else ->
                localGenerationSemaphore.withPermit {
                  generateLocalThumbnail(video, widthPx, heightPx)
                }
            } ?: return@async null

          currentCoroutineContext().ensureActive()
          synchronized(memoryCache) {
            memoryCache.put(key, bitmap)
          }
          writeBitmapToDisk(diskCacheKey(video), bitmap, isNetworkUrl(video.path))
          _thumbnailReadyKeys.tryEmit(key)
          bitmap
        }

      val operation =
        ongoingOperations.putIfAbsent(key, candidate)?.also {
          candidate.cancel()
        } ?: candidate.also { owned ->
          owned.invokeOnCompletion {
            ongoingOperations.remove(key, owned)
          }
          owned.start()
        }

      operation.await()
    }

  suspend fun getCachedThumbnail(
    video: Video,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? =
    withContext(Dispatchers.IO) {
      if (isNetworkUrl(video.path) && !isNetworkThumbnailAllowed(video.path)) {
        return@withContext null
      }

      val key = thumbnailKey(video, widthPx, heightPx)
      synchronized(memoryCache) {
        memoryCache.get(key)
      }?.let { return@withContext it }

      val decoded =
        readBitmapFromDisk(diskCacheKey(video), isNetworkUrl(video.path))
          ?: return@withContext null
      val scaled = scaleBitmap(decoded, widthPx, heightPx)
      synchronized(memoryCache) {
        memoryCache.put(key, scaled)
      }
      return@withContext scaled
    }

  fun getThumbnailFromMemory(
    video: Video,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? {
    if (isNetworkUrl(video.path) && !isNetworkThumbnailAllowed(video.path)) {
      return null
    }

    val key = thumbnailKey(video, widthPx, heightPx)
    return synchronized(memoryCache) {
      memoryCache.get(key)
    }
  }

  fun clearThumbnailCache() {
    folderJobs.values.forEach { it.cancel() }
    folderJobs.clear()
    folderStates.clear()
    ongoingOperations.values.forEach { it.cancel() }
    ongoingOperations.clear()
    diskVideoBaseKeyCache.clear()
    localMetadataCache.clear()
    networkThumbnailFailedAt.clear()

    synchronized(memoryCache) {
      memoryCache.evictAll()
    }

    diskCacheLock.write {
      listOf(
        File(context.cacheDir, "thumbnails"),
        File(context.filesDir, "thumbnails"),
        File(context.cacheDir, "remote_images"),
      ).forEach(::deleteCacheDirectory)
      check(localDiskDir.mkdirs() || localDiskDir.isDirectory) {
        "Unable to recreate thumbnail cache directory: ${localDiskDir.absolutePath}"
      }
      check(networkDiskDir.mkdirs() || networkDiskDir.isDirectory) {
        "Unable to recreate thumbnail cache directory: ${networkDiskDir.absolutePath}"
      }
    }
  }

  private fun deleteCacheDirectory(directory: File) {
    if (directory.exists() && !directory.deleteRecursively()) {
      error("Unable to clear cache directory: ${directory.absolutePath}")
    }
  }

  fun startFolderThumbnailGeneration(
    folderId: String,
    videos: List<Video>,
    widthPx: Int,
    heightPx: Int,
  ) {
    val videoSequence = videos.asSequence()
    val filteredVideos =
      (
        if (appearancePreferences.showNetworkThumbnails.get()) {
          videoSequence
        } else {
          videoSequence.filterNot { isNetworkUrl(it.path) }
        }
      ).take(maxFolderBatchSize)
        .toList()

    if (filteredVideos.isEmpty()) {
      return
    }

    folderJobs.entries.removeAll { !it.value.isActive }

    if (folderJobs.size >= maxConcurrentFolders && !folderJobs.containsKey(folderId)) {
      folderJobs.entries.firstOrNull()?.let { (oldestId, job) ->
        job.cancel()
        folderJobs.remove(oldestId)
        folderStates.remove(oldestId)
      }
    }

    val signature = folderSignature(filteredVideos, widthPx, heightPx)
    val existingState = folderStates[folderId]
    val state =
      folderStates.compute(folderId) { _, existing ->
        if (existing == null || existing.signature != signature) {
          FolderState(signature = signature, nextIndex = 0)
        } else {
          existing
        }
      }!!

    val existingJob = folderJobs[folderId]
    val shouldRestart =
      existingState == null ||
        existingState.signature != signature ||
        (existingJob?.isActive != true && state.nextIndex < filteredVideos.size)

    // Keep an active matching batch, but resume one that was cancelled before completing.
    if (shouldRestart) {
      folderJobs.remove(folderId)?.cancel()
      folderJobs[folderId] =
        repositoryScope.launch {
          var i = state.nextIndex
          while (i < filteredVideos.size) {
            val batchParallelism =
              if (filteredVideos.any { isNetworkUrl(it.path) || it.uri.scheme in setOf("http", "https") }) 1
              else localGenerationParallelism
            val batchEnd = (i + batchParallelism).coerceAtMost(filteredVideos.size)
            coroutineScope {
              (i until batchEnd)
                .map { index ->
                  async {
                    runCatching { getThumbnail(filteredVideos[index], widthPx, heightPx) }
                      .onFailure { error ->
                        if (error !is CancellationException) {
                          Log.w("ThumbnailRepository", "Remote thumbnail prefetch failed", error)
                        }
                      }
                      .getOrNull()
                  }
                }.awaitAll()
            }
            i = batchEnd
            state.nextIndex = i
            yield()
          }
        }
    }
  }

  fun cancelFolderThumbnailGeneration(folderId: String) {
    folderJobs.remove(folderId)?.cancel()
    folderStates.remove(folderId)
  }

  fun thumbnailKey(
    video: Video,
    width: Int,
    height: Int,
  ): String = "${videoBaseKey(video)}|$width|$height|${thumbnailModeKey()}|${thumbnailQualityKey()}"

  /**
   * Folder prefetch and a visible card may request different sizes for the same source.
   * The disk entry is size-independent, so either completion can wake the card and let it
   * decode the cached bitmap at its own target dimensions.
   */
  fun isThumbnailKeyForVideo(
    key: String,
    video: Video,
  ): Boolean =
    key.startsWith("${videoBaseKey(video)}|") &&
      key.endsWith("|${thumbnailModeKey()}|${thumbnailQualityKey()}")

  // Keep extraction-quality changes from reusing smaller legacy images that were
  // cached without their requested dimensions in the key.
  fun diskCacheKey(video: Video): String =
    "video-thumb-v2|${diskVideoBaseKey(video)}|${thumbnailModeKey()}|${thumbnailQualityKey()}"

  private fun canonicalLocalPath(video: Video): String {
    val raw = video.path.ifBlank { video.uri.toString() }
    if (isNetworkUrl(raw)) return raw

    val decoded = runCatching { Uri.decode(raw) }.getOrNull() ?: raw

    if (decoded.startsWith("file://", ignoreCase = true)) {
      val parsed = runCatching { Uri.parse(decoded).path }.getOrNull()
      if (!parsed.isNullOrBlank()) return parsed
      return decoded.removePrefix("file://")
    }

    if (decoded.startsWith("content://", ignoreCase = true) || video.uri.scheme.equals("content", ignoreCase = true)) {
      val targetUri =
        if (decoded.startsWith("content://", ignoreCase = true)) {
          runCatching { Uri.parse(decoded) }.getOrNull() ?: video.uri
        } else {
          video.uri
        }
      val resolved = runCatching { targetUri.resolveLocalPath(context) }.getOrNull()
      if (!resolved.isNullOrBlank()) return resolved
    }

    if (video.uri.scheme.equals("file", ignoreCase = true)) {
      val p = video.uri.path
      if (!p.isNullOrBlank()) return p
    }

    return decoded
  }

  private fun resolveLocalMetadata(video: Video, source: String): ResolvedMetadata {
    if (video.size > 0L && video.dateModified > 0L && video.duration > 0L) {
      return ResolvedMetadata(video.size, video.dateModified, video.duration)
    }

    localMetadataCache[source]?.let { return it }

    var size = video.size
    var dateModified = video.dateModified
    var duration = video.duration

    val file = if (!source.contains("://")) File(source) else null
    if (file != null && file.exists()) {
      if (size <= 0L) size = file.length()
      if (dateModified <= 0L) dateModified = file.lastModified() / 1000L
    }

    // Query MediaStore which is indexed by Android
    runCatching {
      val projection =
        arrayOf(
          MediaStore.Video.Media.DURATION,
          MediaStore.Video.Media.SIZE,
          MediaStore.Video.Media.DATE_MODIFIED,
        )
      val cursor =
        when {
          video.uri.scheme == "content" &&
            video.uri.toString().startsWith(MediaStore.Video.Media.EXTERNAL_CONTENT_URI.toString()) -> {
            context.contentResolver.query(video.uri, projection, null, null, null)
          }
          file != null -> {
            context.contentResolver.query(
              MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
              projection,
              "${MediaStore.Video.Media.DATA} = ?",
              arrayOf(source),
              null,
            )
          }
          else -> null
        }
      cursor?.use { c ->
        if (c.moveToFirst()) {
          val durCol = c.getColumnIndex(MediaStore.Video.Media.DURATION)
          val sizeCol = c.getColumnIndex(MediaStore.Video.Media.SIZE)
          val dateCol = c.getColumnIndex(MediaStore.Video.Media.DATE_MODIFIED)
          if (durCol >= 0 && duration <= 0L) duration = c.getLong(durCol)
          if (sizeCol >= 0 && size <= 0L) size = c.getLong(sizeCol)
          if (dateCol >= 0 && dateModified <= 0L) dateModified = c.getLong(dateCol)
        }
      }
    }

    val resolved = ResolvedMetadata(size, dateModified, duration)
    localMetadataCache[source] = resolved
    return resolved
  }

  private fun extractDurationFallback(video: Video): Long =
    runCatching {
      val retriever = MediaMetadataRetriever()
      try {
        setLocalDataSource(retriever, video)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
      } finally {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) retriever.close() else retriever.release()
      }
    }.getOrDefault(0L)

  private fun videoBaseKey(video: Video): String {
    if (isNetworkUrl(video.path)) {
      val base = video.path.ifBlank { video.uri.toString() }
      return "$base|network"
    }

    val source = canonicalLocalPath(video)
    val meta = resolveLocalMetadata(video, source)
    return "$source|${meta.size}|${meta.dateModified}|${meta.duration}"
  }

  /** Sidecar artwork probing is disk I/O, so keep it out of keys evaluated during composition. */
  private fun diskVideoBaseKey(video: Video): String {
    val baseKey = videoBaseKey(video)
    if (isNetworkUrl(video.path)) return baseKey
    diskVideoBaseKeyCache[baseKey]?.let { return it }

    val canonicalPath = canonicalLocalPath(video)
    val artworkSignature =
      EmbeddedArtworkCandidates
        .forVideoPath(canonicalPath)
        .asSequence()
        .map(::File)
        .firstOrNull { it.isFile && it.canRead() }
        ?.let { artwork -> "|art:${artwork.name}:${artwork.length()}:${artwork.lastModified()}" }
        .orEmpty()
    val resolvedKey = "$baseKey$artworkSignature"
    return diskVideoBaseKeyCache.putIfAbsent(baseKey, resolvedKey) ?: resolvedKey
  }

  private suspend fun generateLocalThumbnail(
    video: Video,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? {
    val mode = browserPreferences.thumbnailMode.get()
    val dimension = maxOf(widthPx, heightPx, MAX_THUMBNAIL_SIZE).coerceAtMost(thumbnailMaxSize())

    if (video.isAudio || mode == ThumbnailMode.Smart || mode == ThumbnailMode.EmbeddedThumbnail) {
      generateEmbeddedArtwork(video)?.let { return scaleBitmap(it, widthPx, heightPx) }
      if (video.isAudio) return null
    }

    generateWithFastThumbnails(video, mode, dimension)?.let {
      return scaleBitmap(it, widthPx, heightPx)
    }

    return extractLocalVideoFrame(video, widthPx, heightPx)
  }

  private fun generateEmbeddedArtwork(video: Video): Bitmap? =
    runCatching {
      val retriever = MediaMetadataRetriever()
      try {
        val canonicalPath = canonicalLocalPath(video)
        setLocalDataSource(retriever, video)
        EmbeddedArtworkResolver.decodeEmbeddedArtwork(canonicalPath, retriever)?.scaleToThumbnailMax(thumbnailMaxSize())
      } finally {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) retriever.close() else retriever.release()
      }
    }.getOrNull()

  private suspend fun generateWithFastThumbnails(
    video: Video,
    mode: ThumbnailMode,
    dimension: Int,
  ): Bitmap? {
    val canonicalPath = canonicalLocalPath(video)
    if (video.isAudio || canonicalPath.isBlank()) return null
    val targetVideo = if (video.path != canonicalPath) video.copy(path = canonicalPath) else video

    val resolvedDuration =
      if (targetVideo.duration > 0L) {
        targetVideo.duration
      } else {
        val metaDur = resolveLocalMetadata(targetVideo, canonicalPath).duration
        if (metaDur > 0L) metaDur else extractDurationFallback(targetVideo)
      }
    val durationSeconds = resolvedDuration.coerceAtLeast(0L) / 1000.0
    val requestedPosition =
      when (mode) {
        ThumbnailMode.FirstFrame, ThumbnailMode.EmbeddedThumbnail -> 0.0
        ThumbnailMode.FrameAtPosition ->
          durationSeconds * (browserPreferences.thumbnailFramePosition.get() / 100.0).coerceIn(0.0, 1.0)
        ThumbnailMode.Smart -> durationSeconds * 0.33
      }
    val lastSafePosition = (durationSeconds - 0.1).coerceAtLeast(0.0)
    val positions =
      when (mode) {
        ThumbnailMode.Smart -> listOf(requestedPosition, 10.0, 20.0, 30.0)
        else -> listOf(requestedPosition)
      }.map { position ->
        if (durationSeconds > 0.0) position.coerceIn(0.0, lastSafePosition) else position.coerceAtLeast(0.0)
      }.distinct()

    var lastSolidBitmap: Bitmap? = null
    for (position in positions) {
      val bitmap =
        try {
          FastThumbnails.generateAsync(
            targetVideo.path,
            position,
            dimension,
            useHwDec = false,
          )
        } catch (cancellation: CancellationException) {
          lastSolidBitmap?.takeUnless { it.isRecycled }?.recycle()
          throw cancellation
        } catch (_: Exception) {
          continue
        } ?: continue

      if (mode == ThumbnailMode.Smart && isMostlySolidThumbnail(bitmap)) {
        lastSolidBitmap?.takeUnless { it.isRecycled }?.recycle()
        lastSolidBitmap = bitmap
        continue
      }

      lastSolidBitmap?.takeUnless { it.isRecycled }?.recycle()
      return rotateNativeThumbnail(video, bitmap)
    }

    return lastSolidBitmap?.let { rotateNativeThumbnail(video, it) }
  }

  private suspend fun rotateNativeThumbnail(
    video: Video,
    bitmap: Bitmap,
  ): Bitmap {
    val rotation =
      try {
        app.infinity.mpvz.utils.media.MediaInfoOps
          .getRotation(context, video.uri, video.displayName)
      } catch (cancellation: CancellationException) {
        bitmap.takeUnless { it.isRecycled }?.recycle()
        throw cancellation
      } catch (_: Exception) {
        0
      }
    if (rotation == 0) return bitmap

    val rotated =
      Bitmap.createBitmap(
        bitmap,
        0,
        0,
        bitmap.width,
        bitmap.height,
        Matrix().apply { postRotate(rotation.toFloat()) },
        true,
      )
    if (rotated !== bitmap && !bitmap.isRecycled) bitmap.recycle()
    return rotated
  }

  private fun extractLocalVideoFrame(
    video: Video,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? =
    runCatching {
      val retriever = MediaMetadataRetriever()
      try {
        setLocalDataSource(retriever, video)
        extractFrameWithStrategy(
          retriever = retriever,
          strategy =
            browserPreferences.thumbnailMode.get().toThumbnailStrategy(
              browserPreferences.thumbnailFramePosition.get(),
            ),
          targetWidth = widthPx.takeIf { it > 0 },
          targetHeight = heightPx.takeIf { it > 0 },
          videoPath = canonicalLocalPath(video),
        )
      } finally {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) retriever.close() else retriever.release()
      }
    }.getOrNull()

  private fun setLocalDataSource(
    retriever: MediaMetadataRetriever,
    video: Video,
  ) {
    val canonicalPath = canonicalLocalPath(video)
    when {
      canonicalPath.isNotBlank() && !canonicalPath.contains("://") && File(canonicalPath).exists() ->
        retriever.setDataSource(canonicalPath)
      video.path.isNotBlank() && !video.path.contains("://") -> retriever.setDataSource(video.path)
      else -> retriever.setDataSource(context, video.uri)
    }
  }

  private fun readBitmapFromDisk(
    key: String,
    network: Boolean,
  ): Bitmap? =
    diskCacheLock.read {
      val file = File(if (network) networkDiskDir else localDiskDir, keyToFileName(key))
      if (!file.isFile) return@read null

      runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        BitmapFactory.decodeFile(
          file.absolutePath,
          BitmapFactory.Options().apply {
            inSampleSize = calculateThumbnailSampleSize(bounds.outWidth, bounds.outHeight, thumbnailMaxSize())
            inPreferredConfig = Bitmap.Config.RGB_565
          },
        )
      }.getOrNull()
    }

  private fun writeBitmapToDisk(
    key: String,
    bitmap: Bitmap,
    network: Boolean,
  ) {
    val file = File(if (network) networkDiskDir else localDiskDir, keyToFileName(key))
    val encoded =
      runCatching {
        ByteArrayOutputStream().use { buffer ->
          if (bitmap.compress(Bitmap.CompressFormat.JPEG, THUMBNAIL_JPEG_QUALITY, buffer)) {
            buffer.toByteArray()
          } else {
            null
          }
        }
      }.getOrNull() ?: return

    diskCacheLock.write {
      runCatching {
        FileOutputStream(file).use { output ->
          output.write(encoded)
        }
      }
    }
  }

  private fun keyToFileName(key: String): String =
    MessageDigest
      .getInstance("SHA-256")
      .digest(key.toByteArray())
      .joinToString("") { byte -> "%02x".format(byte) } + ".jpg"

  private fun scaleBitmap(
    bitmap: Bitmap,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap {
    if (widthPx <= 0 || heightPx <= 0 || bitmap.isRecycled) {
      return bitmap
    }

    val scale = max(widthPx / bitmap.width.toFloat(), heightPx / bitmap.height.toFloat())
    if (scale >= 1f && bitmap.width <= widthPx * 2 && bitmap.height <= heightPx * 2) {
      return bitmap
    }

    val scaledWidth = max(1, (bitmap.width * scale).roundToInt())
    val scaledHeight = max(1, (bitmap.height * scale).roundToInt())
    val scaled =
      try {
        Bitmap.createScaledBitmap(bitmap, scaledWidth, scaledHeight, true)
      } catch (_: IllegalArgumentException) {
        // Bitmap was recycled between the check and the scale call
        return bitmap
      }
    if (scaled != bitmap && !bitmap.isRecycled) {
      bitmap.recycle()
    }
    return scaled
  }

  private fun isNetworkUrl(path: String): Boolean =
    path.startsWith("http://", ignoreCase = true) ||
      path.startsWith("https://", ignoreCase = true) ||
      path.startsWith("rtmp://", ignoreCase = true) ||
      path.startsWith("rtsp://", ignoreCase = true) ||
      path.startsWith("ftp://", ignoreCase = true) ||
      path.startsWith("sftp://", ignoreCase = true) ||
      path.startsWith("smb://", ignoreCase = true)

  private fun isHttpUrl(path: String): Boolean =
    path.startsWith("http://", ignoreCase = true) ||
      path.startsWith("https://", ignoreCase = true)

  private suspend fun getOrCreateNetworkVideoThumbnail(
    video: Video,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? {
    val jellyfinImageUrls = extractJellyfinImageUrls(video.path, maxOf(widthPx, heightPx, 400))
    for (url in jellyfinImageUrls) {
      val jellyfinBitmap = fetchHttpImage(url)
      if (jellyfinBitmap != null) {
        return scaleBitmap(jellyfinBitmap, widthPx, heightPx)
      }
    }

    if (!appearancePreferences.showNetworkThumbnails.get()) {
      return null
    }

    val strategy =
      browserPreferences.thumbnailMode.get().toThumbnailStrategy(
        browserPreferences.thumbnailFramePosition.get(),
      )

    val rotated =
      extractNetworkVideoFrame(
        url = video.path,
        strategy = strategy,
        targetWidth = widthPx.takeIf { it > 0 },
        targetHeight = heightPx.takeIf { it > 0 },
      ) ?: generateFastNetworkThumbnail(video.path, widthPx, heightPx) ?: return null

    return scaleBitmap(rotated, widthPx, heightPx)
  }

  private fun isNetworkThumbnailAllowed(path: String): Boolean =
    extractJellyfinImageUrls(path).isNotEmpty() || appearancePreferences.showNetworkThumbnails.get()

  private fun extractJellyfinImageUrls(url: String, maxWidth: Int = 400): List<String> =
    runCatching {
      val uri = Uri.parse(url)
      val pathSegments = uri.pathSegments
      val videosIndex = pathSegments.indexOf("Videos")
      val itemsIndex = pathSegments.indexOf("Items")
      val audioIndex = pathSegments.indexOf("Audio")
      val targetIndex =
        when {
          videosIndex != -1 -> videosIndex
          itemsIndex != -1 -> itemsIndex
          audioIndex != -1 -> audioIndex
          else -> -1
        }
      if (targetIndex == -1 || targetIndex + 1 >= pathSegments.size) return emptyList()
      val itemId = pathSegments[targetIndex + 1]
      val apiKey = uri.getQueryParameter("api_key") ?: uri.getQueryParameter("ApiKey")
      val scheme = uri.scheme ?: "http"
      val authority = uri.encodedAuthority ?: return emptyList()
      val subPathSegments = pathSegments.subList(0, targetIndex)
      val base =
        if (subPathSegments.isEmpty()) {
          "$scheme://$authority"
        } else {
          "$scheme://$authority/" + subPathSegments.joinToString("/")
        }
      val tokenParam = if (!apiKey.isNullOrBlank()) "&api_key=$apiKey" else ""
      listOf(
        "$base/Items/$itemId/Images/Primary?maxWidth=$maxWidth&quality=80$tokenParam",
        "$base/Items/$itemId/Images/Primary?fallback=true&maxWidth=$maxWidth&quality=80$tokenParam",
        "$base/Items/$itemId/Images/Thumb?maxWidth=$maxWidth&quality=80$tokenParam",
        "$base/Items/$itemId/Images/Backdrop/0?maxWidth=$maxWidth&quality=80$tokenParam",
      )
    }.getOrDefault(emptyList())

  private suspend fun fetchHttpImage(url: String): Bitmap? =
    withContext(Dispatchers.IO) {
      runCatching {
        val connection =
          (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = 4000
            readTimeout = 6000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "MpvInfinity/1.0")
          }
        if (connection.responseCode in 200..299) {
          connection.inputStream.use { stream ->
            BitmapFactory.decodeStream(stream)
          }
        } else {
          null
        }
      }.getOrNull()
    }

  private fun youtubePosterUrl(url: String): String? {
    val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return null
    val host = uri.host?.lowercase().orEmpty()
    val videoId = when {
      host == "youtu.be" -> uri.pathSegments.firstOrNull()
      host == "youtube.com" || host.endsWith(".youtube.com") ->
        uri.getQueryParameter("v")
          ?: uri.pathSegments.firstOrNull { it == "shorts" || it == "embed" }
            ?.let { marker -> uri.pathSegments.getOrNull(uri.pathSegments.indexOf(marker) + 1) }
      else -> null
    }?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{6,}")) }
    return videoId?.let { "https://i.ytimg.com/vi/$it/hqdefault.jpg" }
  }

  private fun extractNetworkVideoFrame(
    url: String,
    strategy: ThumbnailStrategy,
    targetWidth: Int?,
    targetHeight: Int?,
  ): Bitmap? =
    runCatching {
      val retriever = MediaMetadataRetriever()
      try {
        retriever.setDataSource(url, networkVideoHeaders())

        val primary = extractFrameWithStrategy(retriever, strategy, targetWidth, targetHeight)
        if (primary == null || (!isMostlySolidThumbnail(primary) && !isMostlyDarkThumbnail(primary))) {
          primary
        } else {
          // Some movie and episode streams legitimately begin with a black/solid frame. Keep it
          // as a fallback so WebDAV cards are never blank when no later frame can be decoded.
          var fallback: Bitmap? = primary
          listOf(0.33f, 0.66f, 0.85f)
            .asSequence()
            .mapNotNull { percentage ->
              getFrameAt(
                retriever,
                frameTimeMicros(retriever, percentage),
                targetWidth,
                targetHeight,
              )
            }
            .firstOrNull { candidate ->
              if (isMostlySolidThumbnail(candidate) || isMostlyDarkThumbnail(candidate)) {
                fallback?.takeUnless { it.isRecycled }?.recycle()
                fallback = candidate
                false
              } else {
                fallback?.takeUnless { it.isRecycled }?.recycle()
                fallback = null
                true
              }
            }
            ?: fallback
        }
      } finally {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) retriever.close() else retriever.release()
      }
    }.onFailure { error ->
      Log.e("ThumbnailRepository", "Network thumbnail decode failed url=$url", error)
    }.getOrNull()

  private fun extractFrameWithStrategy(
    retriever: MediaMetadataRetriever,
    strategy: ThumbnailStrategy,
    targetWidth: Int?,
    targetHeight: Int?,
    videoPath: String? = null,
  ): Bitmap? {
    val embeddedPicture =
      if (strategy.prefersEmbeddedPicture()) {
        EmbeddedArtworkResolver.decodeEmbeddedArtwork(videoPath, retriever)
      } else {
        null
      }
    val timeUs =
      when (strategy) {
        ThumbnailStrategy.FirstFrame -> 0L
        is ThumbnailStrategy.FrameAtPercentage -> frameTimeMicros(retriever, strategy.percentage)
        is ThumbnailStrategy.Hybrid, is ThumbnailStrategy.EmbeddedOrHybrid -> 0L
        ThumbnailStrategy.EmbeddedOrFirstFrame -> 0L
      }

    var shouldRotate = true
    val raw =
      when (strategy) {
        ThumbnailStrategy.EmbeddedOrFirstFrame ->
          embeddedPicture?.also { shouldRotate = false }
            ?: getFrameAt(retriever, timeUs, targetWidth, targetHeight)
        ThumbnailStrategy.FirstFrame -> getFrameAt(retriever, 0L, targetWidth, targetHeight)
        is ThumbnailStrategy.FrameAtPercentage -> getFrameAt(retriever, timeUs, targetWidth, targetHeight)
        is ThumbnailStrategy.Hybrid -> decodeHybridFrame(retriever, strategy.percentage, targetWidth, targetHeight)
        is ThumbnailStrategy.EmbeddedOrHybrid ->
          embeddedPicture?.also { shouldRotate = false }
            ?: decodeHybridFrame(retriever, strategy.percentage, targetWidth, targetHeight)
      } ?: return null

    return if (shouldRotate) rotateBitmapIfNeeded(retriever, raw) else raw
  }

  private fun decodeHybridFrame(
    retriever: MediaMetadataRetriever,
    percentage: Float,
    targetWidth: Int?,
    targetHeight: Int?,
  ): Bitmap? {
    val first = getFrameAt(retriever, 0L, targetWidth, targetHeight) ?: return null
    if (!isMostlySolidThumbnail(first)) return first
    first.recycle()
    return getFrameAt(
      retriever,
      frameTimeMicros(retriever, percentage),
      targetWidth,
      targetHeight,
    )
  }

  private fun getFrameAt(
    retriever: MediaMetadataRetriever,
    timeUs: Long,
    targetWidth: Int?,
    targetHeight: Int?,
  ): Bitmap? {
    val w = targetWidth ?: return retriever.getFrameAtTime(timeUs)
    val h = targetHeight ?: return retriever.getFrameAtTime(timeUs)
    if (w <= 0 || h <= 0) {
      return retriever.getFrameAtTime(timeUs)
    }
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
      runCatching {
        retriever.getScaledFrameAtTime(
          timeUs,
          MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
          w,
          h,
        )
      }.getOrNull()
        ?: retriever.getFrameAtTime(timeUs)
    } else {
      retriever.getFrameAtTime(timeUs)
    }
  }

  private fun frameTimeMicros(
    retriever: MediaMetadataRetriever,
    percentage: Float,
  ): Long {
    val durationMs =
      retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    return (durationMs * percentage.coerceIn(0f, 1f) * 1000).toLong()
  }

  private fun rotateBitmapIfNeeded(
    retriever: MediaMetadataRetriever,
    bitmap: Bitmap,
  ): Bitmap {
    val rotation =
      retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull()
        ?: return bitmap
    if (rotation == 0) {
      return bitmap
    }

    val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
    val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    if (rotated != bitmap) {
      bitmap.recycle()
    }
    return rotated
  }

  private fun networkVideoHeaders(): Map<String, String> =
    mapOf(
      // Some servers refuse requests without a UA. MediaMetadataRetriever handles the rest.
      "User-Agent" to "Mozilla/5.0 (Android) MpvInfinity",
      "Accept" to "*/*",
    )

  /**
   * Retrieve a thumbnail for a raw network file path (for use from [NetworkVideoCard]).
   * For HTTP/HTTPS URLs, uses [MediaMetadataRetriever]'s built-in HTTP streaming.
   * For other protocols (SMB, FTP, WebDAV), uses [NetworkStreamingProxy] to create
   * a local HTTP stream and then extracts the frame.
   * Respects the [showNetworkThumbnails] preference gate.
   */
  suspend fun getThumbnailForNetworkPath(
    path: String,
    widthPx: Int,
    heightPx: Int,
    connection: NetworkConnection? = null,
    fileSize: Long = -1L,
    mimeType: String? = null,
    lastModified: Long = 0L,
  ): Bitmap? =
    withContext(Dispatchers.IO) {
      if (!appearancePreferences.showNetworkThumbnails.get()) return@withContext null

      val identity = networkThumbnailIdentity(path, connection, fileSize, lastModified)
      val memKey = networkThumbnailMemoryKey(identity, widthPx, heightPx)
      synchronized(memoryCache) { memoryCache.get(memKey) }?.let { return@withContext it }
      ongoingOperations[memKey]?.let { return@withContext it.await() }

      val candidate =
        async(start = CoroutineStart.LAZY) {
          if (!isHttpUrl(path)) {
            return@async getNonHttpNetworkThumbnail(
              path = path,
              connection = connection,
              widthPx = widthPx,
              heightPx = heightPx,
              identity = identity,
              fileSize = fileSize,
              mimeType = mimeType,
            )
          }

          if (hasRecentNetworkThumbnailFailure(identity)) {
            android.util.Log.d("ThumbnailRepository", "Skipping network thumbnail (previously failed): $path")
            return@async null
          }

          val diskKey = networkThumbnailDiskKey(identity)
          readBitmapFromDisk(diskKey, network = true)?.let { bitmap ->
            val scaled = scaleBitmap(bitmap, widthPx, heightPx)
            synchronized(memoryCache) { memoryCache.put(memKey, scaled) }
            return@async scaled
          }

          val strategy =
            browserPreferences.thumbnailMode.get().toThumbnailStrategy(
              browserPreferences.thumbnailFramePosition.get(),
            )
          val networkStrategy = when (strategy) {
            ThumbnailStrategy.FirstFrame, ThumbnailStrategy.EmbeddedOrFirstFrame -> ThumbnailStrategy.Hybrid(0.33f)
            is ThumbnailStrategy.EmbeddedOrHybrid -> ThumbnailStrategy.Hybrid(strategy.percentage)
            else -> strategy
          }
          youtubePosterUrl(path)?.let { posterUrl ->
            fetchHttpImage(posterUrl)?.let { bitmap ->
              val scaled = scaleBitmap(bitmap, widthPx, heightPx)
              networkThumbnailFailedAt.remove(identity)
              writeBitmapToDisk(diskKey, scaled, network = true)
              synchronized(memoryCache) { memoryCache.put(memKey, scaled) }
              _thumbnailReadyKeys.tryEmit(memKey)
              return@async scaled
            }
          }
          val bitmap =
            networkGenerationSemaphore.withPermit {
              (
                extractNetworkVideoFrame(
                  url = path,
                  strategy = networkStrategy,
                  targetWidth = widthPx.takeIf { it > 0 },
                  targetHeight = heightPx.takeIf { it > 0 },
                ) ?: generateFastNetworkThumbnail(path, widthPx, heightPx)
              )?.let { scaleBitmap(it, widthPx, heightPx) }
            }

          if (bitmap == null) {
            android.util.Log.w("ThumbnailRepository", "All strategies failed for network stream $path")
            networkThumbnailFailedAt[identity] = SystemClock.elapsedRealtime()
            return@async null
          }

          networkThumbnailFailedAt.remove(identity)
          writeBitmapToDisk(diskKey, bitmap, network = true)
          synchronized(memoryCache) { memoryCache.put(memKey, bitmap) }
          _thumbnailReadyKeys.tryEmit(memKey)
          bitmap
        }

      val operation =
        ongoingOperations.putIfAbsent(memKey, candidate)?.also {
          candidate.cancel()
        } ?: candidate.also { owned ->
          owned.invokeOnCompletion { ongoingOperations.remove(memKey, owned) }
          owned.start()
        }
      operation.await()
    }

  suspend fun getThumbnailForNetworkSource(
    connectionId: Long,
    path: String,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? {
    val connection = networkRepository.getConnectionById(connectionId) ?: return null
    return getThumbnailForNetworkPath(
      path = path,
      widthPx = widthPx,
      heightPx = heightPx,
      connection = connection,
    )
  }

  private suspend fun getNonHttpNetworkThumbnail(
    path: String,
    connection: NetworkConnection?,
    widthPx: Int,
    heightPx: Int,
    identity: String,
    fileSize: Long,
    mimeType: String?,
  ): Bitmap? {
    if (hasRecentNetworkThumbnailFailure(identity)) {
      android.util.Log.d("ThumbnailRepository", "Skipping network thumbnail (previously failed): $path")
      return null
    }

    val memKey = networkThumbnailMemoryKey(identity, widthPx, heightPx)
    val diskKey = networkThumbnailDiskKey(identity)

    // Memory cache hit
    synchronized(memoryCache) { memoryCache.get(memKey) }?.let { return it }

    // Disk cache hit
    readBitmapFromDisk(diskKey, network = true)?.let { bitmap ->
      val scaled = scaleBitmap(bitmap, widthPx, heightPx)
      synchronized(memoryCache) { memoryCache.put(memKey, scaled) }
      return scaled
    }

    val strategy =
      browserPreferences.thumbnailMode.get().toThumbnailStrategy(
        browserPreferences.thumbnailFramePosition.get(),
      )
    // A remote WebDAV MKV cannot satisfy a second random seek from the bounded thumbnail probe.
    // Use one first-frame decode here; normal playback remains seek-capable through the full proxy.
    val networkStrategy = ThumbnailStrategy.FirstFrame

    // WebDAV providers are intentionally not probed for media metadata here. Resolve a
    // poster from the public, keyless Cinemeta catalog using only the filename, then keep
    // the existing authenticated frame extraction as a fallback.
    // Prefer the provider-safe poster. Keep frame extraction only for smaller files where
    // the fallback cannot create the large range-read/cache buildup seen on remuxes.
    val bitmap =
      getCinemetaPoster(path, widthPx, heightPx)
        ?: networkGenerationSemaphore.withPermit {
            (
              if (connection != null) {
                extractNetworkVideoFrameViaProxy(
                  path = path,
                  connection = connection,
                  strategy = networkStrategy,
                  targetWidth = widthPx,
                  targetHeight = heightPx,
                  fileSize = fileSize,
                  mimeType = mimeType,
                )
              } else {
                generateFastNetworkThumbnail(path, widthPx, heightPx)
              }
            )?.let { scaleBitmap(it, widthPx, heightPx) }
          }

    if (bitmap == null) {
      android.util.Log.w("ThumbnailRepository", "All strategies failed for network path $path")
      networkThumbnailFailedAt[identity] = SystemClock.elapsedRealtime()
      return null
    }

    networkThumbnailFailedAt.remove(identity)

    // Write to disk cache
    writeBitmapToDisk(diskKey, bitmap, network = true)

    synchronized(memoryCache) { memoryCache.put(memKey, bitmap) }
    _thumbnailReadyKeys.tryEmit(memKey)
    return bitmap
  }

  private suspend fun getCinemetaPoster(path: String, widthPx: Int, heightPx: Int): Bitmap? =
    withContext(Dispatchers.IO) {
      val imdbId = Regex("(?i)\\{imdb-(tt\\d+)\\}").find(path)?.groupValues?.get(1)?.lowercase()
      val filename = path.substringAfterLast('/').substringAfterLast('\\')
      val pathSegments = path.split('/').filter { it.isNotBlank() }
      val seasonIndex = pathSegments.indexOfLast { it.matches(Regex("(?i)(?:Season[\\s._-]*\\d{1,2}|S\\d{1,2})(?:\\s|[._-]|\\(|$).*")) }
      val folderTitle =
        if (seasonIndex > 0) pathSegments[seasonIndex - 1]
        else pathSegments.dropLast(1).lastOrNull().orEmpty()
      val episodeLike =
        seasonIndex > 0 || filename.matches(Regex("(?i).*(?:\\bS\\d{1,2}E\\d{1,4}\\b|\\s-\\s\\d{2,4}\\b).*"))
      fun cleanAnimeTitle(raw: String): String =
        raw.substringBeforeLast('.', missingDelimiterValue = "")
          .replace(Regex("(?i)\\{imdb-tt\\d+\\}"), " ")
          .replace(Regex("\\[[^]]*]"), " ")
          .replace(Regex("(?i)\\([^)]*(?:1080|2160|4k|x26[45]|hevc|av1|web[- .]?dl|bluray|bd|dual[- .]?audio|opus|flac|vodes|purple)[^)]*\\)"), " ")
          .replace(Regex("(?i)\\bS\\d{1,2}(?:E\\d{1,4})?\\b"), " ")
          .replace(Regex("(?i)\\b(?:season|cour|part|split[- .]?cour)\\s*[0-9ivx]+\\b"), " ")
          .replace(Regex("(?i)\\b(?:episode|ep|ova|movie)\\s*[0-9]+\\b"), " ")
          .replace(Regex("(?i)\\s+-\\s+(?:\\d{2,4}|episode|ep)\\b.*$"), " ")
          .replace(Regex("(?i)\\b(?:1080p|2160p|720p|480p|4k|8bit|10bit|x26[45]|hevc|av1|web[- .]?dl|bluray|bdrip|remux|dual[- .]?audio|multi[- .]?audio|aac|opus|flac)\\b"), " ")
          .replace(Regex("[._]+"), " ")
          .replace(Regex("\\s+"), " ")
          .trim(' ', '-', '_')
      val rawTitle = if (episodeLike && folderTitle.isNotBlank()) folderTitle else filename
      val title = cleanAnimeTitle(rawTitle)
      val folderCandidate = cleanAnimeTitle(folderTitle)
      val filenameCandidate = cleanAnimeTitle(filename)
      val animeCandidates = listOf(title, folderCandidate, filenameCandidate)
        .filter { it.length >= 3 }
        .distinct()
      fun normalized(value: String): String = value.lowercase().replace(Regex("[^a-z0-9]+"), "")
      if (imdbId == null && title.isBlank()) return@withContext null
      val cacheKey = imdbId ?: title
      val posterUrl =
        (if (episodeLike) getKitsuPoster(animeCandidates, ::normalized) else null)
          ?: metadataPosterUrls[cacheKey] ?: run {
        val failedAt = metadataPosterFailedAt[cacheKey]
        if (failedAt != null && SystemClock.elapsedRealtime() - failedAt < METADATA_POSTER_FAILURE_RETRY_MS) {
          return@withContext null
        }
        val resolved = if (imdbId != null) {
          listOf("movie", "series").firstNotNullOfOrNull { type ->
            runCatching {
              val request = Request.Builder()
                .url("https://v3-cinemeta.strem.io/meta/$type/$imdbId.json")
                .header("Accept", "application/json")
                .build()
              metadataPosterClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@runCatching null
                metadataPosterJson.parseToJsonElement(response.body.string()).jsonObject["meta"]
                  ?.jsonObject?.get("poster")?.jsonPrimitive?.contentOrNull
              }
            }.getOrNull()
          }
        } else {
          val encoded = java.net.URLEncoder.encode(title, Charsets.UTF_8.name())
          listOf("movie", "series").firstNotNullOfOrNull { type ->
            runCatching {
              val request = Request.Builder()
                .url("$CINEMETA_CATALOG_URL/$type/top/search=$encoded.json")
                .header("Accept", "application/json")
                .build()
              metadataPosterClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@runCatching null
                metadataPosterJson.parseToJsonElement(response.body.string()).jsonObject["metas"]
                  ?.jsonArray?.firstNotNullOfOrNull { entry ->
                    val meta = entry.jsonObject
                    val name = meta["name"]?.jsonPrimitive?.contentOrNull.orEmpty()
                    if (normalized(name) == normalized(title)) {
                      meta["poster"]?.jsonPrimitive?.contentOrNull
                    } else {
                      null
                    }
                  }
              }
            }.getOrNull()
          }
        }
        if (resolved == null) metadataPosterFailedAt[cacheKey] = SystemClock.elapsedRealtime()
        resolved
      } ?: return@withContext null
      metadataPosterUrls[cacheKey] = posterUrl
      runCatching {
        val request = Request.Builder().url(posterUrl).header("Accept", "image/*").build()
        metadataPosterClient.newCall(request).execute().use { response ->
          if (!response.isSuccessful) return@runCatching null
          val bytes = response.body.bytes()
          BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { scaleBitmap(it, widthPx, heightPx) }
        }
      }.getOrNull()
    }

  private suspend fun getKitsuPoster(titles: List<String>, normalized: (String) -> String): String? {
    val candidates = titles.filter { it.isNotBlank() }.distinct()
    if (candidates.isEmpty()) return null
    val cacheKey = "kitsu:" + candidates.joinToString("|")
    metadataPosterUrls[cacheKey]?.let { return it }
    val failedAt = metadataPosterFailedAt[cacheKey]
    if (failedAt != null && SystemClock.elapsedRealtime() - failedAt < METADATA_POSTER_FAILURE_RETRY_MS) return null
    val resolved = runCatching {
      candidates.asSequence().mapNotNull { title ->
        val encoded = java.net.URLEncoder.encode(title, Charsets.UTF_8.name())
        val request = Request.Builder()
          .url("https://kitsu.io/api/edge/anime?filter[text]=$encoded&page[limit]=20")
          .header("Accept", "application/vnd.api+json")
          .build()
        metadataPosterClient.newCall(request).execute().use { response ->
          if (!response.isSuccessful) return@use null
          metadataPosterJson.parseToJsonElement(response.body.string()).jsonObject["data"]
            ?.jsonArray?.mapNotNull { entry ->
              val attributes = entry.jsonObject["attributes"]?.jsonObject ?: return@mapNotNull null
              val names = listOfNotNull(
                attributes["canonicalTitle"]?.jsonPrimitive?.contentOrNull,
                attributes["english"]?.jsonPrimitive?.contentOrNull,
                attributes["romaji"]?.jsonPrimitive?.contentOrNull,
                attributes["slug"]?.jsonPrimitive?.contentOrNull,
              )
              val wantedTokens = normalized(title).chunked(3).toSet()
              val score = names.maxOfOrNull { candidate ->
                val value = normalized(candidate)
                when {
                  value == normalized(title) -> 1000
                  value.startsWith(normalized(title)) || normalized(title).startsWith(value) -> 800
                  wantedTokens.count { token -> value.contains(token) } >= 2 -> 500
                  else -> 0
                }
              } ?: 0
              if (score == 0) null else score to attributes
            }
            ?.maxByOrNull { it.first }
            ?.second
            ?.let { attributes ->
              val poster = attributes["posterImage"]?.jsonObject
              listOf("original", "large", "medium", "small")
                .firstNotNullOfOrNull { key -> poster?.get(key)?.jsonPrimitive?.contentOrNull }
            }
        }
      }.firstOrNull { it.isNotBlank() }
    }.getOrNull()
    if (resolved == null) metadataPosterFailedAt[cacheKey] = SystemClock.elapsedRealtime()
    if (resolved != null) metadataPosterUrls[cacheKey] = resolved
    return resolved
  }

  private suspend fun extractNetworkVideoFrameViaProxy(
    path: String,
    connection: NetworkConnection,
    strategy: ThumbnailStrategy,
    targetWidth: Int,
    targetHeight: Int,
    fileSize: Long,
    mimeType: String?,
  ): Bitmap? {
    val proxy = NetworkStreamingProxy.getInstance()
    val streamId = "thumb_${path.hashCode()}_${System.nanoTime()}"

    return try {
      val localUrl =
        proxy.registerStream(
          streamId = streamId,
          connection = connection,
          filePath = path,
          fileSize = fileSize.coerceAtLeast(-1L),
          mimeType = mimeType ?: NetworkMimeTypes.forFileName(path) ?: "application/octet-stream",
        )
      val thumbnailUrl = Uri.parse(localUrl).buildUpon()
        .appendQueryParameter("thumbnail", "1")
        .build()

      // FastThumbnails uses the MPV demuxer and performs seekable range reads through the
      // authenticated proxy. MediaMetadataRetriever cannot reliably decode large remote MKVs:
      // it requests the Matroska cues and clusters as hidden random reads and often blocks for
      // tens of seconds or returns no bitmap at all.
      generateFastNetworkThumbnail(thumbnailUrl.toString(), targetWidth, targetHeight)
        ?: extractNetworkVideoFrame(
        url = thumbnailUrl.toString(),
        strategy = strategy,
        targetWidth = targetWidth.takeIf { it > 0 },
        targetHeight = targetHeight.takeIf { it > 0 },
      )
    } catch (cancellation: CancellationException) {
      throw cancellation
    } catch (_: Exception) {
      null
    } finally {
      proxy.unregisterStream(streamId)
    }
  }

  /** The memory-cache key used by [getThumbnailForNetworkPath]. */
  fun thumbnailKeyForNetworkPath(
    path: String,
    widthPx: Int,
    heightPx: Int,
    connection: NetworkConnection? = null,
    fileSize: Long = -1L,
    lastModified: Long = 0L,
  ): String =
    networkThumbnailMemoryKey(
      networkThumbnailIdentity(path, connection, fileSize, lastModified),
      widthPx,
      heightPx,
    )

  private fun networkThumbnailIdentity(
    path: String,
    connection: NetworkConnection?,
    fileSize: Long,
    lastModified: Long,
  ): String {
    val endpoint =
      connection?.let {
        "${it.id}|${it.protocol.name}|${it.host.lowercase()}|${it.port}|${it.path}|${it.useHttps}"
      } ?: "direct"
    return "$endpoint|$path|$fileSize|$lastModified"
  }

  private fun networkThumbnailMemoryKey(
    identity: String,
    widthPx: Int,
    heightPx: Int,
  ): String = "$identity|network|$widthPx|$heightPx|${thumbnailModeKey()}|${thumbnailQualityKey()}"

  private fun networkThumbnailDiskKey(identity: String): String =
    "video-thumb-v4|$identity|network|${thumbnailModeKey()}|${thumbnailQualityKey()}"

  private fun hasRecentNetworkThumbnailFailure(identity: String): Boolean {
    val failedAt = networkThumbnailFailedAt[identity] ?: return false
    if (SystemClock.elapsedRealtime() - failedAt < NETWORK_THUMBNAIL_FAILURE_RETRY_MS) return true
    networkThumbnailFailedAt.remove(identity, failedAt)
    return false
  }

  /**
   * Get a thumbnail for a folder using the first video in the folder.
   * Returns null if the folder has no videos or thumbnail generation fails.
   */
  suspend fun getFolderThumbnail(
    folderId: String,
    videos: List<Video>,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? =
    withContext(Dispatchers.IO) {
      if (videos.isEmpty()) return@withContext null

      // Filter out network videos if network thumbnails are disabled
      val filteredVideos =
        if (appearancePreferences.showNetworkThumbnails.get()) {
          videos
        } else {
          videos.filterNot { isNetworkUrl(it.path) }
        }

      if (filteredVideos.isEmpty()) return@withContext null

      // Use the first video as the folder thumbnail
      getThumbnail(filteredVideos.first(), widthPx, heightPx)
    }

  private fun folderSignature(
    videos: List<Video>,
    widthPx: Int,
    heightPx: Int,
  ): String {
    val md = MessageDigest.getInstance("MD5")
    md.update("$widthPx|$heightPx|${thumbnailModeKey()}|${thumbnailQualityKey()}|".toByteArray())
    for (video in videos) {
      md.update(video.path.toByteArray())
      md.update("|".toByteArray())
      md.update(video.size.toString().toByteArray())
      md.update("|".toByteArray())
      md.update(video.dateModified.toString().toByteArray())
      md.update(";".toByteArray())
    }
    return md.digest().joinToString("") { byte -> "%02x".format(byte) }
  }

  private fun thumbnailModeKey(): String =
    browserPreferences.thumbnailMode.get().thumbnailModeCacheKey(browserPreferences.thumbnailFramePosition.get())

  private fun thumbnailQualityKey(): String = browserPreferences.thumbnailQuality.get().name

  private fun thumbnailMaxSize(): Int = browserPreferences.thumbnailQuality.get().maxSizePx

  private fun resolveLocalGenerationParallelism(): Int {
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    val processorCount = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
    return when {
      activityManager?.isLowRamDevice == true || processorCount <= 2 -> 1
      processorCount <= 4 -> 2
      processorCount <= 6 -> 3
      else -> 4
    }
  }

  private suspend fun generateFastNetworkThumbnail(
    path: String,
    widthPx: Int,
    heightPx: Int,
  ): Bitmap? =
    try {
      FastThumbnails.generateAsync(
        path,
        10.0,
        maxOf(widthPx, heightPx).coerceAtMost(thumbnailMaxSize()),
        useHwDec = false,
      )
    } catch (cancellation: CancellationException) {
      throw cancellation
    } catch (_: Exception) {
      null
    }
}
