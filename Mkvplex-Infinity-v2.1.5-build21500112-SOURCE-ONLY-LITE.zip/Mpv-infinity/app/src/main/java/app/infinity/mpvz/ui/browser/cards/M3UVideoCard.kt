/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.ui.browser.cards

import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.infinity.mpvz.domain.media.model.Video
import app.infinity.mpvz.domain.network.NetworkPlaybackUri
import app.infinity.mpvz.domain.thumbnail.ThumbnailRepository
import app.infinity.mpvz.preferences.AppearancePreferences
import app.infinity.mpvz.preferences.preference.collectAsState
import app.infinity.mpvz.presentation.components.RemoteImage
import app.infinity.mpvz.ui.icons.Icon
import app.infinity.mpvz.ui.icons.Icons
import app.infinity.mpvz.ui.theme.AppShapeScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.withContext
import org.koin.compose.koinInject
import kotlin.math.roundToInt

/**
 * Card for displaying M3U/M3U8 playlist items (streaming URLs)
 */
@Composable
fun M3UVideoCard(
  title: String,
  url: String,
  logoUrl: String?,
  groupTitle: String?,
  hasDrm: Boolean,
  hasCustomUserAgent: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  onLongClick: (() -> Unit)? = null,
  onFavoriteClick: (() -> Unit)? = null,
  isSelected: Boolean = false,
  isRecentlyPlayed: Boolean = false,
  isFavorite: Boolean = false,
  video: Video? = null,
  isGridMode: Boolean = false,
) {
  val thumbnailRepository = koinInject<ThumbnailRepository>()
  val appearancePreferences = koinInject<AppearancePreferences>()
  val showNetworkThumbnails by appearancePreferences.showNetworkThumbnails.collectAsState()
  var thumbnail by remember(url, logoUrl) { mutableStateOf<android.graphics.Bitmap?>(null) }
  val networkReference = remember(url) { NetworkPlaybackUri.parse(url) }
  val isYouTubeArtwork =
    remember(logoUrl) {
      val host = runCatching { android.net.Uri.parse(logoUrl).host.orEmpty().lowercase() }.getOrDefault("")
      host == "i.ytimg.com" || host.endsWith(".ytimg.com")
    }

  val isNetwork =
    remember(url, networkReference) {
      networkReference != null ||
        url.startsWith("http://", ignoreCase = true) ||
        url.startsWith("https://", ignoreCase = true) ||
        url.startsWith("rtmp://", ignoreCase = true) ||
        url.startsWith("rtsp://", ignoreCase = true) ||
        url.startsWith("ftp://", ignoreCase = true) ||
        url.startsWith("sftp://", ignoreCase = true) ||
        url.startsWith("smb://", ignoreCase = true)
    }

  if (!isYouTubeArtwork && (!isNetwork || showNetworkThumbnails)) {
    val density = LocalDensity.current
    val targetThumbnailSize = 128.dp
    val thumbWidthPx = with(density) { targetThumbnailSize.toPx().roundToInt() }
    val thumbHeightPx = (thumbWidthPx / (16f / 9f)).roundToInt()

    val actualVideo =
      remember(video, url) {
        video ?: Video(
          id = url.hashCode().toLong(),
          title = title,
          displayName = title,
          path = url,
          uri = android.net.Uri.parse(url),
          duration = 0,
          durationFormatted = "",
          size = 0,
          sizeFormatted = "",
          dateModified = 0,
          dateAdded = 0,
          mimeType = "video/*",
          bucketId = "",
          bucketDisplayName = "",
          width = 0,
          height = 0,
          fps = 0f,
          resolution = "",
        )
      }

    val thumbnailKey =
      remember(actualVideo.id, thumbWidthPx, thumbHeightPx, isNetwork) {
        if (networkReference != null) {
          "network-m3u|${networkReference.connectionId}|${networkReference.path.value}|$thumbWidthPx|$thumbHeightPx"
        } else if (isNetwork) {
          thumbnailRepository.thumbnailKeyForNetworkPath(url, thumbWidthPx, thumbHeightPx)
        } else {
          thumbnailRepository.thumbnailKey(actualVideo, thumbWidthPx, thumbHeightPx)
        }
      }

    LaunchedEffect(thumbnailKey, showNetworkThumbnails) {
      thumbnailRepository.thumbnailReadyKeys.filter { it == thumbnailKey }.collect {
        thumbnail =
          if (networkReference != null) {
            thumbnailRepository.getThumbnailForNetworkSource(
              connectionId = networkReference.connectionId,
              path = networkReference.path.value,
              widthPx = thumbWidthPx,
              heightPx = thumbHeightPx,
            )
          } else if (isNetwork) {
            thumbnailRepository.getThumbnailForNetworkPath(url, thumbWidthPx, thumbHeightPx)
          } else {
            thumbnailRepository.getThumbnailFromMemory(
              actualVideo,
              thumbWidthPx,
              thumbHeightPx,
            )
          }
      }
    }

    LaunchedEffect(thumbnailKey, showNetworkThumbnails) {
      if (thumbnail == null) {
        thumbnail =
          withContext(Dispatchers.IO) {
            if (networkReference != null) {
              thumbnailRepository.getThumbnailForNetworkSource(
                connectionId = networkReference.connectionId,
                path = networkReference.path.value,
                widthPx = thumbWidthPx,
                heightPx = thumbHeightPx,
              )
            } else if (isNetwork) {
              thumbnailRepository.getThumbnailForNetworkPath(url, thumbWidthPx, thumbHeightPx)
            } else {
              thumbnailRepository.getThumbnail(actualVideo, thumbWidthPx, thumbHeightPx)
            }
          }
      }
    }
  }

  val unlimitedNameLines by appearancePreferences.unlimitedNameLines.collectAsState()
  val maxLines = if (unlimitedNameLines) Int.MAX_VALUE else 2

  val thumbnailWidth = 128.dp

  Card(
    modifier =
      modifier
        .fillMaxWidth()
        .clip(AppShapeScale.large)
        .combinedClickable(
          onClick = onClick,
          onLongClick = onLongClick,
        ),
    shape = AppShapeScale.large,
    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
  ) {
    Box(modifier = Modifier.fillMaxWidth()) {
      if (isSelected) {
        Box(
          modifier =
            Modifier
              .matchParentSize()
              .padding(2.dp)
              .clip(AppShapeScale.large)
              .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f)),
        )
      }

      if (isGridMode) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(8.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Box(
            modifier =
              Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .combinedClickable(onClick = onClick, onLongClick = onLongClick),
            contentAlignment = Alignment.Center,
          ) {
            val currentImageBitmap = remember(thumbnail) { thumbnail?.asImageBitmap() }
            if (currentImageBitmap != null) {
              androidx.compose.foundation.Image(
                bitmap = currentImageBitmap,
                contentDescription = title,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.Crop,
              )
            } else if (!logoUrl.isNullOrBlank()) {
              RemoteImage(
                url = logoUrl,
                contentDescription = title,
                contentScale = if (isYouTubeArtwork) ContentScale.Crop else ContentScale.Fit,
                modifier = Modifier.matchParentSize().padding(6.dp),
              )
            } else {
              Icon(
                Icons.RoundedFilled.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(42.dp),
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.82f),
              )
            }
          }
          Box(modifier = Modifier.fillMaxWidth()) {
            Text(
              text = title,
              style = MaterialTheme.typography.titleSmall,
              color = if (isRecentlyPlayed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
              fontWeight = if (isFavorite) FontWeight.SemiBold else FontWeight.Normal,
              maxLines = 2,
              minLines = 2,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.fillMaxWidth().padding(end = if (onFavoriteClick != null) 34.dp else 0.dp),
            )
            if (onFavoriteClick != null) {
              IconButton(
                onClick = onFavoriteClick,
                modifier = Modifier.size(32.dp).align(Alignment.TopEnd),
              ) {
                Icon(
                  imageVector = Icons.RoundedFilled.Bookmarks,
                  contentDescription = if (isFavorite) "Unsave stream" else "Save stream",
                  tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
          Text(
            text = url,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth(),
          )
          FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            if (!groupTitle.isNullOrBlank()) {
              M3UMetadataChip(
                text = groupTitle,
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
              )
            }
            if (hasDrm) {
              M3UMetadataChip(
                text = "DRM",
                containerColor = MaterialTheme.colorScheme.errorContainer,
                contentColor = MaterialTheme.colorScheme.onErrorContainer,
              )
            }
            if (hasCustomUserAgent) {
              M3UMetadataChip(
                text = "UA",
                containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
              )
            }
            if (isFavorite) {
              M3UMetadataChip(
                text = "Saved",
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
              )
            }
          }
        }
      } else Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
      Box(
        modifier =
          Modifier
            .width(thumbnailWidth)
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .combinedClickable(
              onClick = onClick,
              onLongClick = onLongClick,
            ),
        contentAlignment = Alignment.Center,
      ) {
        val currentImageBitmap = remember(thumbnail) { thumbnail?.asImageBitmap() }
        if (currentImageBitmap != null) {
          androidx.compose.foundation.Image(
            bitmap = currentImageBitmap,
            contentDescription = null,
            modifier = Modifier.matchParentSize(),
            contentScale = ContentScale.Crop,
          )
        } else if (!logoUrl.isNullOrBlank()) {
          RemoteImage(
            url = logoUrl,
            contentDescription = null,
            contentScale = if (isYouTubeArtwork) ContentScale.Crop else ContentScale.Fit,
            modifier =
              if (isYouTubeArtwork) {
                Modifier.matchParentSize()
              } else {
                Modifier
                  .matchParentSize()
                  .padding(8.dp)
              },
          )
        } else {
          Icon(
            Icons.RoundedFilled.PlayArrow,
            contentDescription = null,
            modifier = Modifier.size(42.dp),
            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.82f),
          )
        }
      }
      Spacer(modifier = Modifier.width(16.dp))
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Text(
          title,
          style = MaterialTheme.typography.titleSmall,
          color =
            if (isRecentlyPlayed) {
              MaterialTheme.colorScheme.primary
            } else {
              MaterialTheme.colorScheme.onSurface
            },
          maxLines = maxLines,
          overflow = TextOverflow.Ellipsis,
          fontWeight = if (isFavorite) FontWeight.SemiBold else FontWeight.Normal,
        )
        Text(
          url,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
        FlowRow(
          horizontalArrangement =
            androidx.compose.foundation.layout.Arrangement
              .spacedBy(6.dp),
          verticalArrangement =
            androidx.compose.foundation.layout.Arrangement
              .spacedBy(6.dp),
        ) {
          if (!groupTitle.isNullOrBlank()) {
            M3UMetadataChip(
              text = groupTitle,
              containerColor = MaterialTheme.colorScheme.secondaryContainer,
              contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
            )
          }
          if (hasDrm) {
            M3UMetadataChip(
              text = "DRM",
              containerColor = MaterialTheme.colorScheme.errorContainer,
              contentColor = MaterialTheme.colorScheme.onErrorContainer,
            )
          }
          if (hasCustomUserAgent) {
            M3UMetadataChip(
              text = "UA",
              containerColor = MaterialTheme.colorScheme.tertiaryContainer,
              contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
            )
          }
          if (isFavorite) {
            M3UMetadataChip(
              text = "Saved",
              containerColor = MaterialTheme.colorScheme.primaryContainer,
              contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
            )
          }
        }
      }

        if (onFavoriteClick != null) {
          Spacer(modifier = Modifier.width(8.dp))
          IconButton(onClick = onFavoriteClick) {
            Icon(
              imageVector = Icons.RoundedFilled.Bookmarks,
              contentDescription = if (isFavorite) "Unsave stream" else "Save stream",
              tint =
                if (isFavorite) {
                  MaterialTheme.colorScheme.primary
                } else {
                  MaterialTheme.colorScheme.onSurfaceVariant
                },
            )
          }
        }
      }
    }
  }
}

@Composable
private fun M3UMetadataChip(
  text: String,
  containerColor: Color,
  contentColor: Color,
) {
  Text(
    text = text,
    style = MaterialTheme.typography.labelSmall,
    modifier =
      Modifier
        .clip(RoundedCornerShape(999.dp))
        .background(containerColor)
        .padding(horizontal = 8.dp, vertical = 4.dp),
    color = contentColor,
    maxLines = 1,
    overflow = TextOverflow.Ellipsis,
  )
}
