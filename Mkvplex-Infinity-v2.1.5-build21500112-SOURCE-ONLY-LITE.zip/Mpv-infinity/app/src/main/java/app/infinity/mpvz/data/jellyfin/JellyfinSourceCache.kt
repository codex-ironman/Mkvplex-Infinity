/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.data.jellyfin

import app.infinity.mpvz.domain.jellyfin.JellyfinMediaSource

/** Short-lived, process-only cache. Never shares sources across servers or credentials. */
internal class JellyfinSourceCache(
  private val lifetimeMillis: Long = 30_000,
  private val capacity: Int = 16,
  private val clock: () -> Long = { System.nanoTime() / 1_000_000 },
) {
  data class Key(val server: String, val user: String, val token: String, val item: String)
  private data class Entry(val sources: List<JellyfinMediaSource>, val at: Long)
  private val entries = linkedMapOf<Key, Entry>()

  @Synchronized
  fun get(key: Key): List<JellyfinMediaSource>? {
    val entry = entries[key] ?: return null
    val age = clock() - entry.at
    if (age < 0 || age >= lifetimeMillis) {
      entries.remove(key)
      return null
    }
    return entry.sources
  }

  @Synchronized
  fun remember(key: Key, sources: List<JellyfinMediaSource>, keepRicherStreams: Boolean = false): List<JellyfinMediaSource> {
    // Do not cache errors/empty lists or retain unusually large provider responses.
    if (sources.isEmpty() || sources.size > 1_024 || capacity <= 0) return sources
    val previous = if (keepRicherStreams) get(key).orEmpty().associateBy { it.id } else emptyMap()
    val snapshot = sources.map { source ->
      val old = previous[source.id]
      if (old != null && old.streams.any { it.isExternal } && source.streams.none { it.isExternal }) {
        source.copy(streams = old.streams)
      } else source
    }
    entries.remove(key)
    entries[key] = Entry(snapshot, clock())
    while (entries.size > capacity) entries.remove(entries.keys.first())
    return snapshot
  }

  @Synchronized
  fun invalidate(server: String, user: String, token: String) {
    entries.keys.removeAll { it.server == server && it.user == user && it.token == token }
  }
}
