/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.data.jellyfin

import app.infinity.mpvz.domain.jellyfin.JellyfinLinkPolicy
import app.infinity.mpvz.domain.jellyfin.JellyfinLinkStatus
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

internal class JellyfinLinkChecker(client: OkHttpClient) {
  private val client = client.newBuilder().followRedirects(false).followSslRedirects(false)
    .retryOnConnectionFailure(false).connectTimeout(8, TimeUnit.SECONDS)
    .readTimeout(10, TimeUnit.SECONDS).callTimeout(30, TimeUnit.SECONDS).build()

  suspend fun check(url: String, headers: Map<String, String>): JellyfinLinkStatus = withContext(Dispatchers.IO) {
    try {
      var target = url.toHttpUrl()
      val origin = target
      val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(30)
      repeat(6) {
        val remaining = deadline - System.nanoTime()
        if (remaining <= 0) return@withContext JellyfinLinkStatus.UNKNOWN
        val request = Request.Builder().url(target).header("Range", "bytes=0-1023")
          .header("Accept-Encoding", "identity").apply {
            // Jellyfin account headers belong only to the server, never a redirected CDN.
            if (target.scheme == origin.scheme && target.host == origin.host && target.port == origin.port) {
              headers.forEach { (key, value) -> header(key, value) }
            }
          }.build()
        val call = client.newCall(request)
        call.timeout().timeout(remaining, TimeUnit.NANOSECONDS)
        val sample = readSample(call)
        if (sample.code in setOf(301, 302, 303, 307, 308)) {
          val next = sample.location?.let(target::resolve)
            ?: return@withContext JellyfinLinkStatus.UNKNOWN
          if (target.isHttps && !next.isHttps) return@withContext JellyfinLinkStatus.UNKNOWN
          target = next
        } else {
          if (sample.code in setOf(401, 403, 404, 410, 416, 500, 502, 503, 504)) {
            return@withContext JellyfinLinkStatus.UNAVAILABLE
          }
          if (sample.code !in setOf(200, 206)) return@withContext JellyfinLinkStatus.UNKNOWN
          return@withContext if (JellyfinLinkPolicy.mediaPrefix(sample.prefix)) JellyfinLinkStatus.REACHABLE
            else JellyfinLinkStatus.UNKNOWN
        }
      }
      JellyfinLinkStatus.UNKNOWN
    } catch (cancelled: CancellationException) {
      throw cancelled
    } catch (_: Exception) {
      JellyfinLinkStatus.UNKNOWN
    }
  }

  private data class Sample(val code: Int, val location: String?, val prefix: ByteArray)

  // Keep cancellation attached until the bounded body read finishes, so Play immediately cancels probes.
  private suspend fun readSample(call: Call): Sample = suspendCancellableCoroutine { continuation ->
    continuation.invokeOnCancellation { call.cancel() }
    call.enqueue(object : Callback {
      override fun onFailure(call: Call, e: IOException) {
        if (continuation.isActive) continuation.resumeWith(Result.failure(e))
      }
      override fun onResponse(call: Call, response: Response) {
        try {
          val sample = response.use {
            val buffer = ByteArray(1024)
            var count = 0
            if (response.code in setOf(200, 206)) {
              val input = response.body.byteStream()
              while (count < buffer.size) {
                val read = input.read(buffer, count, buffer.size - count)
                if (read <= 0) break
                count += read
              }
            }
            Sample(response.code, response.header("Location"), buffer.copyOf(count))
          }
          if (continuation.isActive) continuation.resumeWith(Result.success(sample))
        } catch (error: Exception) {
          if (continuation.isActive) continuation.resumeWith(Result.failure(error))
        }
      }
    })
  }
}
