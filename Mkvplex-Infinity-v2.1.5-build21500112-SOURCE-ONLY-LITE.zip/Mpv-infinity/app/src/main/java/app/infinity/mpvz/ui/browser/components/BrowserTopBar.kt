/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.ui.browser.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarColors
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.infinity.mpvz.R
import app.infinity.mpvz.preferences.AppearancePreferences
import app.infinity.mpvz.preferences.preference.collectAsState
import app.infinity.mpvz.ui.icons.Icon
import app.infinity.mpvz.ui.icons.Icons
import app.infinity.mpvz.ui.theme.DarkMode
import app.infinity.mpvz.ui.theme.LocalThemeTransitionState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.koin.compose.koinInject

/**
 * Unified top bar for browser screens that switches between normal and selection modes
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserTopBar(
  title: String,
  showTitle: Boolean = true,
  isInSelectionMode: Boolean,
  selectedCount: Int,
  totalCount: Int,
  onCancelSelection: () -> Unit,
  modifier: Modifier = Modifier,
  onBackClick: (() -> Unit)? = null,
  onSortClick: (() -> Unit)? = null,
  onSearchClick: (() -> Unit)? = null,
  onRequestClick: (() -> Unit)? = null,
  onSettingsClick: (() -> Unit)? = null,
  onDeleteClick: (() -> Unit)? = null,
  onRenameClick: (() -> Unit)? = null,
  isSingleSelection: Boolean = false,
  onInfoClick: (() -> Unit)? = null,
  onShareClick: (() -> Unit)? = null,
  onPlayClick: (() -> Unit)? = null,
  onPinClick: (() -> Unit)? = null,
  onBlacklistClick: (() -> Unit)? = null,
  onSelectAll: (() -> Unit)? = null,
  onInvertSelection: (() -> Unit)? = null,
  onDeselectAll: (() -> Unit)? = null,
  leadingActions: @Composable RowScope.() -> Unit = { },
  preSearchActions: @Composable RowScope.() -> Unit = { },
  additionalActions: @Composable RowScope.() -> Unit = { },
  onTitleLongPress: (() -> Unit)? = null,
  onTitleDoubleTap: (() -> Unit)? = null,
  onMoveToSecureClick: (() -> Unit)? = null,
  useRemoveIcon: Boolean = false,
  onAddToPlaylistClick: (() -> Unit)? = null,
  onRestoreClick: (() -> Unit)? = null,
  colors: TopAppBarColors? = null,
  forceHeadlineSmall: Boolean = false,
  showBetaBadge: Boolean = false,
  windowInsets: WindowInsets? = null,
) {
  if (isInSelectionMode) {
    SelectionTopBar(
      selectedCount = selectedCount,
      totalCount = totalCount,
      onCancel = onCancelSelection,
      onDelete = onDeleteClick,
      onRename = onRenameClick,
      isSingleSelection = isSingleSelection,
      onInfo = onInfoClick,
      onShare = onShareClick,
      onPlay = onPlayClick,
      onPin = onPinClick,
      onBlacklist = onBlacklistClick,
      onSelectAll = onSelectAll,
      onInvertSelection = onInvertSelection,
      onDeselectAll = onDeselectAll,
      onMoveToSecure = onMoveToSecureClick,
      onRestore = onRestoreClick,
      modifier = modifier,
      useRemoveIcon = useRemoveIcon,
      onAddToPlaylist = onAddToPlaylistClick,
      colors = colors,
      windowInsets = windowInsets,
      additionalActions = additionalActions,
    )
  } else {
            NormalTopBar(
              title = title,
              showTitle = showTitle,
      onBackClick = onBackClick,
      onSortClick = onSortClick,
      onSearchClick = onSearchClick,
      onRequestClick = onRequestClick,
      onSettingsClick = onSettingsClick,
      leadingActions = leadingActions,
      preSearchActions = preSearchActions,
      additionalActions = additionalActions,
      modifier = modifier,
      onTitleLongPress = onTitleLongPress,
      onTitleDoubleTap = onTitleDoubleTap,
      colors = colors,
      windowInsets = windowInsets,
      forceHeadlineSmall = forceHeadlineSmall,
      showBetaBadge = showBetaBadge,
    )
  }
}

/**
 * Normal mode top bar
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NormalTopBar(
  title: String,
  showTitle: Boolean = true,
  onBackClick: (() -> Unit)?,
  onSortClick: (() -> Unit)?,
  onSearchClick: (() -> Unit)?,
  onRequestClick: (() -> Unit)? = null,
  onSettingsClick: (() -> Unit)?,
  leadingActions: @Composable RowScope.() -> Unit = { },
  preSearchActions: @Composable RowScope.() -> Unit = { },
  additionalActions: @Composable RowScope.() -> Unit,
  modifier: Modifier = Modifier,
  onTitleLongPress: (() -> Unit)?,
  onTitleDoubleTap: (() -> Unit)? = null,
  colors: TopAppBarColors? = null,
  windowInsets: WindowInsets? = null,
  forceHeadlineSmall: Boolean = false,
  showBetaBadge: Boolean = false,
) {
  val preferences = koinInject<AppearancePreferences>()
  val darkMode by preferences.darkMode.collectAsState()
  val darkTheme = isSystemInDarkTheme()
  val themeTransition = LocalThemeTransitionState.current
  val coroutineScope = rememberCoroutineScope()

  // Track title bounds for animation position
  val titleBounds = remember { mutableStateOf(Rect.Zero) }

  // Helper function to toggle dark mode
  fun toggleDarkMode() {
    when (darkMode) {
      DarkMode.System ->
        if (darkTheme) {
          preferences.darkMode.set(DarkMode.Light)
        } else {
          preferences.darkMode.set(DarkMode.Dark)
        }
      DarkMode.Light ->
        if (darkTheme) {
          preferences.darkMode.set(DarkMode.System)
        } else {
          preferences.darkMode.set(DarkMode.Dark)
        }
      DarkMode.Dark ->
        if (darkTheme) {
          preferences.darkMode.set(DarkMode.Light)
        } else {
          preferences.darkMode.set(DarkMode.System)
        }
    }
  }

  TopAppBar(
    colors =
      colors ?: TopAppBarDefaults.topAppBarColors(
        containerColor =
          if (MaterialTheme.colorScheme.background == Color.Black) {
            Color.Black
          } else {
            MaterialTheme.colorScheme.surfaceContainer
          },
      ),
    windowInsets = windowInsets ?: TopAppBarDefaults.windowInsets,
    title = {
      if (showTitle) {
      val betaBadgeSuffix =
        if (showBetaBadge) {
          stringResource(R.string.ui_beta_badge_suffix)
        } else {
          ""
        }
      val titleModifier =
        Modifier
          .onGloballyPositioned { coordinates ->
            titleBounds.value = coordinates.boundsInWindow()
          }.pointerInput(onTitleLongPress, onTitleDoubleTap) {
            detectTapGestures(
              onTap = { localOffset ->
                // Don't allow theme change if animation is in progress
                if (themeTransition?.isAnimating == true) return@detectTapGestures

                // Calculate window position for circular reveal
                val windowOffset =
                  Offset(
                    titleBounds.value.left + localOffset.x,
                    titleBounds.value.top + localOffset.y,
                  )
                themeTransition?.startTransition(windowOffset)
                // Delay theme change to allow overlay to display first
                coroutineScope.launch {
                  delay(50)
                  toggleDarkMode()
                }
              },
              onDoubleTap =
                if (onTitleDoubleTap != null) {
                  { onTitleDoubleTap() }
                } else {
                  null
                },
              onLongPress =
                if (onTitleLongPress != null) {
                  { onTitleLongPress() }
                } else {
                  null
                },
            )
          }

      Text(
        buildAnnotatedString {
          append(title)
          if (showBetaBadge) {
            withStyle(
              SpanStyle(
                fontSize = MaterialTheme.typography.labelSmall.fontSize,
                fontWeight = FontWeight.SemiBold,
                baselineShift = BaselineShift.Superscript,
              ),
            ) {
              append(betaBadgeSuffix)
            }
          }
        },
        style =
          if (forceHeadlineSmall || onBackClick != null) {
            MaterialTheme.typography.headlineSmall
          } else {
            MaterialTheme.typography.headlineMedium
          },
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier =
          titleModifier.then(
            if (onBackClick == null) {
              Modifier.padding(start = 8.dp)
            } else {
              Modifier
            },
          ),
      )
      }
    },
    navigationIcon = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        if (onBackClick != null) {
          IconButton(
            onClick = onBackClick,
            modifier = Modifier.padding(horizontal = 2.dp),
          ) {
            Icon(
              Icons.RoundedFilled.ArrowBack,
              contentDescription = stringResource(R.string.back),
              modifier = Modifier.size(24.dp),
              tint = MaterialTheme.colorScheme.onSurface,
            )
          }
        }
        leadingActions()
      }
    },
    actions = {
      preSearchActions()
      if (onSearchClick != null) {
        IconButton(
          onClick = onSearchClick,
          modifier = Modifier.padding(horizontal = 2.dp),
        ) {
          Icon(
            Icons.RoundedFilled.Search,
            contentDescription =
              androidx.compose.ui.res.stringResource(
                app.infinity.mpvz.R.string.settings_search_title,
              ),
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }
      if (onRequestClick != null) {
        IconButton(
          onClick = onRequestClick,
          modifier = Modifier.padding(horizontal = 2.dp),
        ) {
          Icon(
            Icons.RoundedFilled.Explore,
            contentDescription =
              androidx.compose.ui.res.stringResource(
                app.infinity.mpvz.R.string.seerr_discover,
              ),
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }
      if (onSortClick != null) {
        IconButton(
          onClick = onSortClick,
          modifier = Modifier.padding(horizontal = 2.dp),
        ) {
          Icon(
            Icons.RoundedFilled.SortByAlpha,
            contentDescription = stringResource(R.string.sort),
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }
      additionalActions()
      if (onSettingsClick != null) {
        IconButton(
          onClick = onSettingsClick,
          modifier = Modifier.padding(horizontal = 2.dp),
        ) {
          Icon(
            Icons.RoundedFilled.Settings,
            contentDescription =
              androidx.compose.ui.res
                .stringResource(app.infinity.mpvz.R.string.ui_settings),
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }
    },
    modifier = modifier,
  )
}

/**
 * Selection mode top bar
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SelectionTopBar(
  selectedCount: Int,
  totalCount: Int,
  onCancel: () -> Unit,
  onDelete: (() -> Unit)?,
  onRename: (() -> Unit)?,
  isSingleSelection: Boolean,
  onInfo: (() -> Unit)?,
  onShare: (() -> Unit)?,
  onPlay: (() -> Unit)?,
  onPin: (() -> Unit)?,
  onBlacklist: (() -> Unit)?,
  onSelectAll: (() -> Unit)?,
  onInvertSelection: (() -> Unit)?,
  onDeselectAll: (() -> Unit)?,
  modifier: Modifier = Modifier,
  useRemoveIcon: Boolean = false,
  onAddToPlaylist: (() -> Unit)? = null,
  onMoveToSecure: (() -> Unit)? = null,
  onRestore: (() -> Unit)? = null,
  colors: TopAppBarColors? = null,
  windowInsets: WindowInsets? = null,
  additionalActions: @Composable RowScope.() -> Unit = { },
) {
  var showDropdown by remember { mutableStateOf(false) }
  val lifecycleOwner = LocalLifecycleOwner.current

  DisposableEffect(lifecycleOwner) {
    val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_STOP) showDropdown = false
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  TopAppBar(
    colors =
      colors ?: TopAppBarDefaults.topAppBarColors(
        containerColor =
          if (MaterialTheme.colorScheme.background == Color.Black) {
            Color.Black
          } else {
            MaterialTheme.colorScheme.surfaceContainer
          },
      ),
    windowInsets = windowInsets ?: TopAppBarDefaults.windowInsets,
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { showDropdown = true },
      ) {
        Text(
          stringResource(R.string.selected_items, selectedCount, totalCount),
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Icon(
          Icons.RoundedFilled.ArrowDropDown,
          contentDescription = stringResource(R.string.selection_options),
          modifier = Modifier.size(24.dp),
          tint = MaterialTheme.colorScheme.onSurface,
        )

        DropdownMenu(
          expanded = showDropdown,
          onDismissRequest = { showDropdown = false },
        ) {
          if (onSelectAll != null) {
            DropdownMenuItem(
              text = { Text(stringResource(R.string.select_all)) },
              onClick = {
                onSelectAll()
                showDropdown = false
              },
            )
          }
          if (onInvertSelection != null) {
            DropdownMenuItem(
              text = { Text(stringResource(R.string.invert_selection)) },
              onClick = {
                onInvertSelection()
                showDropdown = false
              },
            )
          }
          if (onDeselectAll != null) {
            DropdownMenuItem(
              text = { Text(stringResource(R.string.deselect_all)) },
              onClick = {
                onDeselectAll()
                showDropdown = false
              },
            )
          }
        }
      }
    },
    navigationIcon = {
      IconButton(
        onClick = onCancel,
        modifier = Modifier.padding(horizontal = 2.dp),
      ) {
        Icon(
          Icons.RoundedFilled.Close,
          contentDescription = stringResource(R.string.generic_cancel),
          modifier = Modifier.size(28.dp),
          tint = MaterialTheme.colorScheme.onSurface,
        )
      }
    },
    actions = {
      additionalActions()
      if (onRestore != null) {
        IconButton(
          onClick = onRestore,
          modifier = Modifier.padding(horizontal = 1.dp),
        ) {
          Icon(
            Icons.RoundedFilled.Restore,
            contentDescription = stringResource(R.string.secure_folder_restore),
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }
      // Play icon
      if (onPlay != null) {
        IconButton(
          onClick = onPlay,
          modifier = Modifier.padding(horizontal = 1.dp),
        ) {
          Icon(
            Icons.RoundedFilled.PlayArrow,
            contentDescription =
              androidx.compose.ui.res
                .stringResource(app.infinity.mpvz.R.string.ui_play),
            modifier = Modifier.size(28.dp),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }

      if (onPin != null) {
        IconButton(
          onClick = onPin,
          modifier = Modifier.padding(horizontal = 1.dp),
        ) {
          Icon(
            Icons.RoundedFilled.PushPin,
            contentDescription =
              androidx.compose.ui.res
                .stringResource(app.infinity.mpvz.R.string.ui_pin_folders),
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }

      // Add to Playlist icon (for Play Store builds)
      if (onAddToPlaylist != null) {
        IconButton(
          onClick = onAddToPlaylist,
          modifier = Modifier.padding(horizontal = 1.dp),
        ) {
          Icon(
            Icons.RoundedFilled.PlaylistAdd,
            contentDescription =
              androidx.compose.ui.res
                .stringResource(app.infinity.mpvz.R.string.ui_add_to_playlist),
            modifier = Modifier.size(28.dp),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }

      // Rename icon
      if (onRename != null) {
        IconButton(
          onClick = onRename,
          enabled = isSingleSelection,
          modifier = Modifier.padding(horizontal = 1.dp),
        ) {
          Icon(
            Icons.RoundedFilled.DriveFileRenameOutline,
            contentDescription = stringResource(R.string.rename),
            modifier = Modifier.size(24.dp),
            tint =
              if (isSingleSelection) {
                MaterialTheme.colorScheme.onSurface
              } else {
                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
              },
          )
        }
      }

      // Info icon
      if (onInfo != null) {
        IconButton(
          onClick = onInfo,
          enabled = isSingleSelection,
          modifier = Modifier.padding(horizontal = 1.dp),
        ) {
          Icon(
            Icons.RoundedFilled.Info,
            contentDescription = stringResource(R.string.info),
            modifier = Modifier.size(24.dp),
            tint =
              if (isSingleSelection) {
                MaterialTheme.colorScheme.onSurface
              } else {
                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
              },
          )
        }
      }

      // Share icon
      if (onShare != null) {
        IconButton(
          onClick = onShare,
          modifier = Modifier.padding(horizontal = 1.dp),
        ) {
          Icon(
            Icons.RoundedFilled.Share,
            contentDescription = stringResource(R.string.generic_share),
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }


      // Move to Secure Folder icon
      if (onMoveToSecure != null) {
        IconButton(
          onClick = onMoveToSecure,
          modifier = Modifier.padding(horizontal = 1.dp),
        ) {
          Icon(
            Icons.RoundedFilled.Lock,
            contentDescription = stringResource(R.string.secure_folder_move_to),
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }

      // Blacklist icon
      if (onBlacklist != null) {
        IconButton(
          onClick = onBlacklist,
          modifier = Modifier.padding(horizontal = 1.dp),
        ) {
          Icon(
            Icons.RoundedFilled.Block,
            contentDescription = stringResource(R.string.pref_folders_blacklist),
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
      }

      // Delete/Remove icon
      if (onDelete != null) {
        IconButton(
          onClick = onDelete,
          modifier = Modifier.padding(horizontal = 2.dp),
        ) {
          Icon(
            imageVector = if (useRemoveIcon) Icons.RoundedFilled.RemoveCircle else Icons.RoundedFilled.Delete,
            contentDescription = stringResource(R.string.delete),
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.error,
          )
        }
      }
    },
    modifier =
      modifier.clip(
        RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp, bottomStart = 28.dp, bottomEnd = 28.dp),
      ),
  )
}
