/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.ui.browser.playlist

import android.app.Application
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.infinity.mpvz.R
import app.infinity.mpvz.domain.media.model.Video
import app.infinity.mpvz.domain.media.model.VideoFolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import app.infinity.mpvz.preferences.BrowserPreferences
import app.infinity.mpvz.preferences.preference.collectAsState
import app.infinity.mpvz.presentation.Screen
import app.infinity.mpvz.ui.browser.cards.FolderCard
import app.infinity.mpvz.ui.browser.cards.VideoCard
import app.infinity.mpvz.ui.browser.cards.rememberVideoCardUiConfig
import app.infinity.mpvz.ui.browser.components.BrowserTopBar
import app.infinity.mpvz.ui.browser.dialogs.FolderSortDialog
import app.infinity.mpvz.ui.browser.dialogs.VideoSortDialog
import app.infinity.mpvz.ui.browser.folderlist.FolderListViewModel
import app.infinity.mpvz.ui.browser.selection.rememberSelectionManager
import app.infinity.mpvz.ui.browser.states.EmptyState
import app.infinity.mpvz.ui.browser.videolist.VideoListViewModel
import app.infinity.mpvz.ui.icons.Icons
import app.infinity.mpvz.ui.utils.LocalBackStack
import app.infinity.mpvz.ui.utils.popSafely
import app.infinity.mpvz.utils.sort.SortUtils
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import org.koin.compose.koinInject

/**
 * In-app file picker for adding videos to a playlist: browse storage folders (same folder
 * browsing/sort experience as [app.infinity.mpvz.ui.browser.folderlist.FolderListScreen]), drill
 * into one and multi-select videos using the app's own [rememberSelectionManager] + [BrowserTopBar]
 * (same as [app.infinity.mpvz.ui.browser.videolist.VideoListScreen]), then add them to the
 * playlist via [PlaylistDetailViewModel.addVideosToPlaylist] — mirrors
 * [app.infinity.mpvz.ui.securefolder.SecureFolderAddFilesScreen] for the Secure Folder flow.
 */
@Serializable
data class PlaylistAddVideosScreen(
  val playlistId: Int,
  val isAudio: Boolean = false,
) : Screen {
  @OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
  @Composable
  override fun Content() {
    val context = LocalContext.current
    val application = context.applicationContext as Application
    val backstack = LocalBackStack.current
    val scope = rememberCoroutineScope()

    val browserPreferences = koinInject<BrowserPreferences>()
    val videoCardUiConfig = rememberVideoCardUiConfig()
    val videoListState = rememberLazyListState()
    val isVideoListScrolling by
      remember(videoListState) {
        derivedStateOf { videoListState.isScrollInProgress }
      }

    val playlistDetailViewModel: PlaylistDetailViewModel =
      viewModel(
        key = "PlaylistDetailViewModel_$playlistId",
        factory = PlaylistDetailViewModel.factory(application, playlistId),
      )

    // Folder list step (mirrors FolderListScreen's browsing + sort)
    val folderListViewModel: FolderListViewModel =
      viewModel(factory = FolderListViewModel.factory(application))
    val videoFolders by folderListViewModel.videoFolders.collectAsState()
    val folderSortType by browserPreferences.folderSortType.collectAsState()
    val folderSortOrder by browserPreferences.folderSortOrder.collectAsState()
    val sortedFolders = remember(videoFolders, folderSortType, folderSortOrder) {
      SortUtils.sortFolders(videoFolders, folderSortType, folderSortOrder)
    }

    var selectedFolder by remember { mutableStateOf<VideoFolder?>(null) }
    val folder = selectedFolder

    var sortDialogOpen by remember { mutableStateOf(false) }

    // Video list step (mirrors VideoListScreen's browsing, sort and selection)
    val videoListViewModel: VideoListViewModel? =
      if (folder != null) {
        viewModel(
          key = "PlaylistAddVideosVideos_${folder.bucketId}_$isAudio",
          factory = VideoListViewModel.factory(application, folder.bucketId, includeAudio = isAudio),
        )
      } else {
        null
      }
    val currentVideos: List<Video> =
      if (videoListViewModel != null) {
        videoListViewModel.videos.collectAsState().value
      } else {
        emptyList()
      }
    val videoSortType by browserPreferences.videoSortType.collectAsState()
    val videoSortOrder by browserPreferences.videoSortOrder.collectAsState()
    val sortedVideos = remember(currentVideos, videoSortType, videoSortOrder, isAudio) {
      val filtered = if (isAudio) currentVideos.filter { it.isAudio } else currentVideos
      SortUtils.sortVideos(filtered, videoSortType, videoSortOrder)
    }

    // Selection manager for multi-select videos step
    val selectionManager =
      if (folder != null) {
        rememberSelectionManager(
          items = sortedVideos,
          getId = { it.id },
          onDeleteItems = { _, _ -> Pair(0, 0) },
        )
      } else {
        null
      }

    fun addSelectedToPlaylist() {
      val videos = selectionManager?.getSelectedItems() ?: emptyList()
      if (videos.isEmpty()) return
      scope.launch {
        playlistDetailViewModel.addVideosToPlaylist(videos)
        withContext(Dispatchers.Main) {
          Toast.makeText(
            context,
            if (isAudio) "Added ${videos.size} songs to playlist" else context.getString(R.string.playlist_add_videos_success, videos.size),
            Toast.LENGTH_SHORT,
          ).show()
          backstack.popSafely()
        }
      }
    }

    BackHandler {
      when {
        selectionManager?.isInSelectionMode == true -> selectionManager.clear()
        folder != null -> selectedFolder = null
        else -> backstack.popSafely()
      }
    }

    Scaffold(
      topBar = {
        if (folder == null) {
          BrowserTopBar(
            title = if (isAudio) "Add Songs" else stringResource(R.string.playlist_add_videos_title),
            isInSelectionMode = false,
            selectedCount = 0,
            totalCount = sortedFolders.size,
            onCancelSelection = {},
            onBackClick = { backstack.popSafely() },
            onSortClick = { sortDialogOpen = true },
          )
        } else {
          BrowserTopBar(
            title = folder.name,
            isInSelectionMode = selectionManager?.isInSelectionMode == true,
            selectedCount = selectionManager?.selectedCount ?: 0,
            totalCount = sortedVideos.size,
            onCancelSelection = { selectionManager?.clear() },
            onBackClick = { selectedFolder = null },
            onSortClick = { sortDialogOpen = true },
            onSelectAll = { selectionManager?.selectAll() },
            onInvertSelection = { selectionManager?.invertSelection() },
            onDeselectAll = { selectionManager?.clear() },
          )
        }
      },
      bottomBar = {
        val selectedCount = selectionManager?.selectedCount ?: 0
        if (selectedCount > 0) {
          Surface(tonalElevation = 3.dp) {
            Button(
              onClick = { addSelectedToPlaylist() },
              modifier = Modifier.fillMaxWidth().padding(16.dp),
            ) {
              Text(if (isAudio) "Add $selectedCount Songs" else stringResource(R.string.playlist_add_videos_button, selectedCount))
            }
          }
        }
      },
    ) { padding ->
      if (folder == null) {
        if (sortedFolders.isEmpty()) {
          EmptyState(
            icon = Icons.RoundedFilled.Folder,
            title = if (isAudio) "No music folders found" else stringResource(R.string.playlist_add_videos_empty_title),
            message = if (isAudio) "No folders with songs available" else stringResource(R.string.playlist_add_videos_empty_message),
            modifier = Modifier.padding(padding),
          )
        } else {
          LazyColumn(modifier = Modifier.padding(padding)) {
            items(
              items = sortedFolders,
              key = { it.bucketId },
              contentType = { "folder" },
            ) { videoFolder ->
              FolderCard(
                folder = videoFolder,
                onClick = { selectedFolder = videoFolder },
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
              )
            }
          }
        }
      } else if (sortedVideos.isEmpty()) {
        EmptyState(
          icon = Icons.RoundedFilled.Folder,
          title = if (isAudio) "No songs found" else stringResource(R.string.playlist_add_videos_empty_title),
          message = if (isAudio) "No songs available in this folder" else stringResource(R.string.playlist_add_videos_empty_message),
          modifier = Modifier.padding(padding),
        )
      } else {
        LazyColumn(
          state = videoListState,
          modifier = Modifier.padding(padding),
        ) {
          items(
            items = sortedVideos,
            key = { it.id },
            contentType = { "video" },
          ) { video: Video ->
            VideoCard(
              video = video,
              isSelected = selectionManager?.isSelected(video) == true,
              onClick = { selectionManager?.toggle(video) },
              onThumbClick = { selectionManager?.toggle(video) },
              onLongClick = { selectionManager?.handleLongClick(video) },
              allowThumbnailLoading = !isVideoListScrolling,
              uiConfig = videoCardUiConfig,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            )
          }
        }
      }
    }

    if (folder == null) {
      FolderSortDialog(
        isOpen = sortDialogOpen,
        onDismiss = { sortDialogOpen = false },
        sortType = folderSortType,
        sortOrder = folderSortOrder,
        onSortTypeChange = { browserPreferences.folderSortType.set(it) },
        onSortOrderChange = { browserPreferences.folderSortOrder.set(it) },
      )
    } else {
      VideoSortDialog(
        isOpen = sortDialogOpen,
        onDismiss = { sortDialogOpen = false },
        sortType = videoSortType,
        sortOrder = videoSortOrder,
        onSortTypeChange = { browserPreferences.videoSortType.set(it) },
        onSortOrderChange = { browserPreferences.videoSortOrder.set(it) },
      )
    }
  }
}
