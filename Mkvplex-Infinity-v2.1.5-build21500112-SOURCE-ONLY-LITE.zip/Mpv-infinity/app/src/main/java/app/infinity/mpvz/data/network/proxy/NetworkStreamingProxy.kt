/*
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package app.infinity.mpvz.data.network.proxy

import android.util.Log
import app.infinity.mpvz.data.network.client.NetworkClient
import app.infinity.mpvz.data.network.client.NetworkMimeTypes
import app.infinity.mpvz.domain.network.NetworkConnection
import app.infinity.mpvz.domain.network.NetworkPath
import app.infinity.mpvz.repository.NetworkRepository
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.io.ByteArrayInputStream
import java.io.IOException
import java.io.InputStream
import java.net.URI
import java.security.SecureRandom
import java.util.Base64
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * A loopback-only authenticated-capability gateway for SMB, FTP, and WebDAV media.
 *
 * Callers keep using their logical [streamId] for unregistering, but it is never exposed on the
 * HTTP endpoint. Every registration gets a cryptographically random capability token. A token can
 * resolve sibling paths below the configured connection root so relative HLS manifests, segments,
 * keys, and maps keep working without embedding remote credentials in a URL.
 */
class NetworkStreamingProxy private constructor() :
  NanoHTTPD("127.0.0.1", 0),
  KoinComponent {
  companion object {
    private const val TAG = "NetworkStreamingProxy"
    private const val TOKEN_BYTES = 24
    private const val PROXY_OPERATION_TIMEOUT_SECONDS = 75L
    private const val THUMBNAIL_PROBE_BYTES = 4L * 1024L * 1024L

    @Volatile
    private var instance: NetworkStreamingProxy? = null

    fun getInstance(): NetworkStreamingProxy =
      instance ?: synchronized(this) {
        instance ?: NetworkStreamingProxy().also {
          it.start()
          instance = it
        }
      }

    fun stopInstance() {
      synchronized(this) {
        instance?.let { proxy ->
          proxy.stop()
          proxy.cleanup()
          instance = null
        }
      }
    }
  }

  private class StreamInfo(
    val connectionId: Long,
    val primaryPath: NetworkPath,
    fileSize: Long,
    val primaryMimeType: String,
  ) {
    // Cache sizes for the primary media and sibling resources (HLS segments, keys, maps, etc.).
    // A seek can otherwise issue repeated serialized size probes before every range request.
    val knownSizes = ConcurrentHashMap<NetworkPath, Long>().apply {
      if (fileSize >= 0L) put(primaryPath, fileSize)
    }
    val clientMutex = Mutex()

    @Volatile
    var client: NetworkClient? = null
  }

  private class HeadResponse(
    status: Response.IStatus,
    mimeType: String,
    contentLength: Long,
  ) : Response(status, mimeType, ByteArrayInputStream(ByteArray(0)), contentLength)

  private val repository by inject<NetworkRepository>()
  private val random = SecureRandom()
  private val proxyJob = SupervisorJob()
  private val proxyScope = CoroutineScope(Dispatchers.IO + proxyJob)
  private val tokenByRegistration = ConcurrentHashMap<String, String>()
  private val streamsByToken = ConcurrentHashMap<String, StreamInfo>()
  private val closingStreams = ConcurrentHashMap.newKeySet<StreamInfo>()

  /** Registers a caller-owned logical stream and returns a credential-free loopback URL. */
  @Synchronized
  fun registerStream(
    streamId: String,
    connection: NetworkConnection,
    filePath: String,
    fileSize: Long = -1L,
    mimeType: String = "video/mp4",
  ): String =
    registerStream(
      streamId = streamId,
      connectionId = connection.id,
      filePath = filePath,
      fileSize = fileSize,
      mimeType = mimeType,
    )

  /** Registers a stream by saved connection id without exposing or loading its credentials. */
  @Synchronized
  fun registerStream(
    streamId: String,
    connectionId: Long,
    filePath: String,
    fileSize: Long = -1L,
    mimeType: String = "video/mp4",
  ): String {
    require(connectionId > 0L) { "A saved network connection is required for proxy streaming" }
    require(fileSize >= -1L) { "File size must be -1 (unknown) or non-negative" }

    val path = NetworkPath.from(filePath)
    val token = generateToken()
    val streamInfo =
      StreamInfo(
        connectionId = connectionId,
        primaryPath = path,
        fileSize = fileSize,
        primaryMimeType = sanitizeMimeType(mimeType),
      )

    streamsByToken[token] = streamInfo
    Log.d(
      TAG,
      "register streamId=$streamId token=$token connectionId=$connectionId path=${path.value} fileSize=$fileSize mime=${streamInfo.primaryMimeType}",
    )
    tokenByRegistration.put(streamId, token)?.let { previousToken ->
      streamsByToken.remove(previousToken)?.let(::closeAsync)
    }

    val route = "/$token${path.value}"
    // NanoHTTPD applies form-style URL decoding to the request URI, where a raw '+' becomes a
    // space. URI.toASCIIString() leaves '+' literal in a path, so escape it explicitly at the
    // loopback boundary; all other path characters are already encoded by URI.
    return URI("http", null, "127.0.0.1", listeningPort, route, null, null)
      .toASCIIString()
      .replace("+", "%2B")
  }

  /** Unregisters the logical ID supplied to [registerStream]. */
  @Synchronized
  fun unregisterStream(streamId: String) {
    val token = tokenByRegistration.remove(streamId) ?: return
    streamsByToken.remove(token)?.let(::closeAsync)
  }

  override fun serve(session: IHTTPSession): Response {
    val headOnly = session.method == Method.HEAD
    val route = parseRoute(session.uri) ?: return notFound(headOnly)
    val streamInfo = streamsByToken[route.token] ?: return notFound(headOnly)
    val requestedPath = route.path ?: streamInfo.primaryPath
    val rangeHeader = session.headers["range"]
    val thumbnailProbe = session.parms["thumbnail"]?.contains("1") == true
    Log.d(
      TAG,
      "request method=${session.method} token=${route.token} connectionId=${streamInfo.connectionId} path=${requestedPath.value} range=${rangeHeader ?: "none"}",
    )

    if (session.method != Method.GET && session.method != Method.HEAD) {
      return newFixedLengthResponse(Response.Status.METHOD_NOT_ALLOWED, MIME_PLAINTEXT, "Method not allowed")
        .apply { addHeader("Allow", "GET, HEAD") }
    }

    return try {
      val response =
        if (rangeHeader == null) {
          handleFullRequest(headOnly, streamInfo, requestedPath, thumbnailProbe)
        } else {
          handleRangeRequest(headOnly, streamInfo, requestedPath, rangeHeader, thumbnailProbe)
        }
      // NanoHTTPD keeps a fixed-length socket alive even when the upstream body ends short,
      // leaving the player waiting forever for the missing bytes. Closing per response turns
      // that into a visible disconnect that mpv's reconnect logic recovers from.
      response.addHeader("Connection", "close")
      response
    } catch (cancellation: CancellationException) {
      throw cancellation
    } catch (error: Exception) {
      // Do not include remote URLs, paths, credentials, or exception messages in logs/responses.
      Log.e(TAG, "Proxy request failed (${error::class.java.simpleName})")
      textResponse(Response.Status.INTERNAL_ERROR, "Upstream stream failed", headOnly)
    }
  }

  private fun handleRangeRequest(
    headOnly: Boolean,
    streamInfo: StreamInfo,
    path: NetworkPath,
    rangeHeader: String,
    thumbnailProbe: Boolean = false,
  ): Response {
    val fileSize = getFileSize(streamInfo, path)
    if (fileSize < 0L) {
      val start = HttpByteRange.parseStart(rangeHeader) ?: return rangeNotSatisfiable(fileSize)
      val mimeType = mimeTypeFor(streamInfo, path)
      val response =
        if (headOnly) {
          HeadResponse(Response.Status.PARTIAL_CONTENT, mimeType, 0L)
        } else {
          val inputStream = getStream(streamInfo, path, start, null) ?: return upstreamFailure(headOnly)
          newChunkedResponse(Response.Status.PARTIAL_CONTENT, mimeType, inputStream)
        }
      response.addHeader("Accept-Ranges", "bytes")
      response.addHeader("Content-Range", "bytes $start-/*")
      return response
    }
    val range = HttpByteRange.parse(rangeHeader, fileSize) ?: return rangeNotSatisfiable(fileSize)
    val mimeType = mimeTypeFor(streamInfo, path)

    val response =
      if (headOnly) {
        HeadResponse(Response.Status.PARTIAL_CONTENT, mimeType, range.length)
      } else {
        val inputStream = getStream(streamInfo, path, range.start, range.length)
          ?: return upstreamFailure(headOnly)
        newFixedLengthResponse(
          Response.Status.PARTIAL_CONTENT,
          mimeType,
          inputStream,
          range.length,
        )
      }

    response.addHeader("Accept-Ranges", "bytes")
    response.addHeader("Content-Range", "bytes ${range.start}-${range.endInclusive}/$fileSize")
    return response
  }

  private fun handleFullRequest(
    headOnly: Boolean,
    streamInfo: StreamInfo,
    path: NetworkPath,
    thumbnailProbe: Boolean = false,
  ): Response {
    val fileSize = getFileSize(streamInfo, path)
    val mimeType = mimeTypeFor(streamInfo, path)

    if (headOnly && fileSize < 0L) return upstreamFailure(headOnly)
    if (headOnly) {
      return HeadResponse(Response.Status.OK, mimeType, fileSize).apply {
        addHeader("Accept-Ranges", "bytes")
      }
    }
    if (fileSize == 0L) {
      return emptyResponse(Response.Status.OK, mimeType).apply { addHeader("Accept-Ranges", "bytes") }
    }

    if (thumbnailProbe && fileSize > THUMBNAIL_PROBE_BYTES) {
      val probeLength = THUMBNAIL_PROBE_BYTES
      if (headOnly) {
        return HeadResponse(Response.Status.PARTIAL_CONTENT, mimeType, probeLength).apply {
          addHeader("Accept-Ranges", "bytes")
          addHeader("Content-Range", "bytes 0-${probeLength - 1}/$fileSize")
        }
      }
      val inputStream = getStream(streamInfo, path, 0L, probeLength) ?: return upstreamFailure(false)
      return newFixedLengthResponse(Response.Status.PARTIAL_CONTENT, mimeType, inputStream, probeLength).apply {
        addHeader("Accept-Ranges", "bytes")
        addHeader("Content-Range", "bytes 0-${probeLength - 1}/$fileSize")
      }
    }
    val inputStream = getStream(streamInfo, path, 0L, fileSize.takeIf { it >= 0L }) ?: return upstreamFailure(headOnly)
    return if (fileSize >= 0L) {
      newFixedLengthResponse(Response.Status.OK, mimeType, inputStream, fileSize).apply {
        addHeader("Accept-Ranges", "bytes")
      }
    } else {
      newChunkedResponse(Response.Status.OK, mimeType, inputStream)
    }
  }

  private fun getFileSize(
    streamInfo: StreamInfo,
    path: NetworkPath,
  ): Long {
    streamInfo.knownSizes[path]?.let { return it }

    Log.d(
      TAG,
      "size request connectionId=${streamInfo.connectionId} path=${path.value} cached=${streamInfo.knownSizes.containsKey(path)}",
    )
    val discoveredResult =
      awaitProxyIo {
        withConnectedClient(streamInfo) { client -> client.getFileSize(path.value) }
      }
    val discovered = discoveredResult.getOrNull() ?: -1L
    Log.d(
      TAG,
      "size result connectionId=${streamInfo.connectionId} path=${path.value} size=$discovered error=${discoveredResult.exceptionOrNull()?.message ?: "none"}",
    )

    if (discovered >= 0L) {
      streamInfo.knownSizes.putIfAbsent(path, discovered)
    }
    return discovered
  }

  private fun getStream(
    streamInfo: StreamInfo,
    path: NetworkPath,
    offset: Long,
    length: Long?,
  ): InputStream? {
    Log.d(
      TAG,
      "stream request connectionId=${streamInfo.connectionId} path=${path.value} offset=$offset",
    )
    val result =
      awaitProxyIo {
        withConnectedClient(streamInfo) { client -> client.getFileStream(path.value, offset, length) }
      }
    Log.d(
      TAG,
      "stream result connectionId=${streamInfo.connectionId} path=${path.value} offset=$offset success=${result.isSuccess} error=${result.exceptionOrNull()?.message ?: "none"}",
    )
    return result.getOrNull()
  }

  /**
   * NanoHTTPD's serve API is synchronous, but upstream clients are suspend-based. Do not use
   * runBlocking here: it installs a nested coroutine event loop on every range request and can
   * amplify thread contention under rapid seeks. Dispatch the suspend work onto the proxy's bounded
   * IO scope and wait only for the result, with a hard timeout and cancellation.
   */
  private fun <T> awaitProxyIo(operation: suspend () -> Result<T>): Result<T> {
    val result = AtomicReference<Result<T>?>(null)
    val latch = CountDownLatch(1)
    val job =
      proxyScope.launch {
        try {
          result.set(operation())
        } catch (cancellation: CancellationException) {
          result.set(Result.failure(cancellation))
        } catch (error: Exception) {
          result.set(Result.failure(error))
        } finally {
          latch.countDown()
        }
      }

    // An abandoned operation can still complete and hand back an open stream; close it so a
    // slow server can't permanently eat one of its own connection slots per timed-out request.
    fun discardLateResult() {
      job.invokeOnCompletion {
        (result.get()?.getOrNull() as? InputStream)?.let { stream -> runCatching(stream::close) }
      }
      job.cancel()
    }

    return try {
      if (!latch.await(PROXY_OPERATION_TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
        discardLateResult()
        Result.failure(IOException("Upstream proxy operation timed out"))
      } else {
        result.get() ?: Result.failure(IOException("Upstream proxy operation produced no result"))
      }
    } catch (interrupted: InterruptedException) {
      discardLateResult()
      Thread.currentThread().interrupt()
      Result.failure(interrupted)
    }
  }

  private suspend fun <T> withConnectedClient(
    streamInfo: StreamInfo,
    operation: suspend (NetworkClient) -> Result<T>,
  ): Result<T> =
    streamInfo.clientMutex.withLock {
      var client = streamInfo.client
      if (client == null) {
        val candidate =
          repository.createClient(streamInfo.connectionId).getOrElse { error ->
            Log.w(TAG, "Upstream client creation failed (${error::class.java.simpleName})")
            return@withLock Result.failure(error)
          }
        try {
          candidate.connect().getOrThrow()
          streamInfo.client = candidate
          client = candidate
        } catch (cancellation: CancellationException) {
          runCatching { candidate.disconnect() }
          throw cancellation
        } catch (error: Exception) {
          Log.w(TAG, "Upstream connect failed (${error::class.java.simpleName})")
          runCatching { candidate.disconnect() }
          return@withLock Result.failure(error)
        }
      } else {
        val existingClient = client
        if (!existingClient.isConnected()) {
          try {
            existingClient.connect().getOrThrow()
          } catch (cancellation: CancellationException) {
            throw cancellation
          } catch (error: Exception) {
            Log.w(TAG, "Upstream reconnect failed (${error::class.java.simpleName})")
            streamInfo.client = null
            runCatching { existingClient.disconnect() }
            return@withLock Result.failure(error)
          }
        }
      }

      val result = operation(client)
      result.exceptionOrNull()?.let { error ->
        if (error is CancellationException) throw error
        // Client error messages are app-constructed (HTTP status etc.) and carry no URLs/credentials.
        Log.w(TAG, "Upstream operation failed (${error::class.java.simpleName}: ${error.message})")
        // A dead session would otherwise be reused forever; evict it so the next request
        // reconnects instead of failing every range request until the stream is re-registered.
        val activeClient = streamInfo.client
        if (activeClient != null && !activeClient.isConnected()) {
          streamInfo.client = null
          runCatching { activeClient.disconnect() }
        }
      }
      result
    }

  private data class Route(
    val token: String,
    val path: NetworkPath?,
  )

  private fun parseRoute(uri: String): Route? {
    val withoutLeadingSlash = uri.removePrefix("/")
    val token = withoutLeadingSlash.substringBefore('/').takeIf(String::isNotBlank) ?: return null
    val pathText = withoutLeadingSlash.substringAfter('/', missingDelimiterValue = "")
    val path =
      if (pathText.isBlank()) {
        null
      } else {
        runCatching { NetworkPath.from(pathText) }.getOrNull() ?: return null
      }
    return Route(token, path)
  }

  private fun getKnownRegistrationMime(
    streamInfo: StreamInfo,
    path: NetworkPath,
  ): String? =
    streamInfo.primaryMimeType
      .takeIf { path == streamInfo.primaryPath }
      ?.takeUnless { it.equals("application/octet-stream", ignoreCase = true) }

  private fun mimeTypeFor(
    streamInfo: StreamInfo,
    path: NetworkPath,
  ): String =
    getKnownRegistrationMime(streamInfo, path)
      ?: NetworkMimeTypes.forFileName(path.relative)
      ?: "application/octet-stream"

  private fun sanitizeMimeType(value: String): String =
    value.takeIf { it.matches(Regex("[A-Za-z0-9!#$&^_.+-]+/[A-Za-z0-9!#$&^_.+*-]+")) }
      ?: "application/octet-stream"

  private fun generateToken(): String {
    var token: String
    do {
      val bytes = ByteArray(TOKEN_BYTES).also(random::nextBytes)
      token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
    } while (streamsByToken.containsKey(token))
    return token
  }

  private fun emptyResponse(
    status: Response.IStatus,
    mimeType: String,
  ): Response = newFixedLengthResponse(status, mimeType, ByteArrayInputStream(ByteArray(0)), 0L)

  private fun rangeNotSatisfiable(fileSize: Long): Response =
    emptyResponse(Response.Status.RANGE_NOT_SATISFIABLE, "application/octet-stream").apply {
      addHeader("Content-Range", "bytes */$fileSize")
      addHeader("Accept-Ranges", "bytes")
    }

  private fun notFound(headOnly: Boolean): Response =
    textResponse(Response.Status.NOT_FOUND, "Stream not found", headOnly)

  private fun upstreamFailure(headOnly: Boolean): Response =
    textResponse(Response.Status.SERVICE_UNAVAILABLE, "Upstream stream failed", headOnly)

  private fun textResponse(
    status: Response.IStatus,
    message: String,
    headOnly: Boolean,
  ): Response =
    if (headOnly) {
      HeadResponse(status, MIME_PLAINTEXT, message.toByteArray(Charsets.UTF_8).size.toLong())
    } else {
      newFixedLengthResponse(status, MIME_PLAINTEXT, message)
    }

  private fun closeAsync(streamInfo: StreamInfo) {
    if (!closingStreams.add(streamInfo)) return
    proxyScope.launch {
      try {
        close(streamInfo)
      } finally {
        closingStreams.remove(streamInfo)
      }
    }
  }

  private suspend fun close(streamInfo: StreamInfo) =
    withContext(NonCancellable) {
      streamInfo.clientMutex.withLock {
        val client = streamInfo.client
        streamInfo.client = null
        runCatching { client?.disconnect() }
      }
    }

  private fun cleanup() {
    val streams =
      synchronized(this) {
        tokenByRegistration.clear()
        (streamsByToken.values + closingStreams).distinct().also {
          streamsByToken.clear()
          closingStreams.clear()
        }
      }

    proxyScope.launch {
      streams.forEach { close(it) }
      proxyScope.cancel()
    }
  }
}
