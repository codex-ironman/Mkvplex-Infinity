/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.data.jellyfin

import app.infinity.mpvz.domain.jellyfin.JellyfinMediaSource
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import java.io.IOException

data class JellyfinSourceUpdate(
  val sources: List<JellyfinMediaSource>,
  val isLoading: Boolean,
  val error: Throwable? = null,
  val retryAttempt: Int = 0,
  // Enrichment can continue without keeping a usable source chooser in its loading state.
  val isRefreshing: Boolean = isLoading,
)

internal object JellyfinSourceLoader {
  private data class Batch(
    val priority: Int,
    val result: Result<List<JellyfinMediaSource>>,
    val complete: Boolean = true,
    val retryAttempt: Int = 0,
  )

  fun load(
    initial: List<JellyfinMediaSource>,
    metadata: suspend (forceRefresh: Boolean) -> Result<List<JellyfinMediaSource>>,
    playback: suspend () -> Result<List<JellyfinMediaSource>>,
    maxSources: Int = 0,
    retryDelaysMillis: List<Long> = listOf(750, 1_500),
    sparseRefreshDelayMillis: Long = 1_500,
    metadataHeadStartMillis: Long = 0,
  ): Flow<JellyfinSourceUpdate> = flow {
    val sources = linkedMapOf<String, Pair<Int, JellyfinMediaSource>>()
    fun merge(priority: Int, incoming: List<JellyfinMediaSource>) {
      for (source in incoming) {
        val previous = sources[source.id]
        if (previous != null || maxSources !in 1..500 || sources.size < maxSources) {
          if (previous == null || priority >= previous.first) sources[source.id] = priority to source
        }
      }
    }
    fun snapshot() = sources.values.map { it.second }
    merge(0, initial)
    emit(JellyfinSourceUpdate(snapshot(), sources.isEmpty(), isRefreshing = true))
    coroutineScope {
      val batches = Channel<Batch>(Channel.UNLIMITED)
      val firstMetadata = CompletableDeferred<List<JellyfinMediaSource>>()
      val firstPlayback = CompletableDeferred<Unit>()
      suspend fun fetch(request: suspend () -> Result<List<JellyfinMediaSource>>): Result<List<JellyfinMediaSource>> {
        val result = try { request() } catch (error: Exception) { Result.failure(error) }
        currentCoroutineContext().ensureActive()
        return result
      }
      launch {
        val result = fetch { metadata(false) }
        val known = result.getOrDefault(emptyList())
        firstMetadata.complete(known)
        // Dynamic servers initially expose an unanalyzed stand-in. Re-read once while
        // PlaybackInfo is still waiting/probing, instead of hiding late links until it ends.
        // Sparse ordinary sources remain valid; no name/count-only source is discarded.
        val sparse = result.isSuccess && known.size <= 1 && known.all {
          it.streams.isEmpty() && it.size == null && it.bitrate == null
        } && !firstPlayback.isCompleted
        batches.send(Batch(1, result, complete = !sparse))
        if (sparse) {
          withTimeoutOrNull(sparseRefreshDelayMillis) { firstPlayback.await() }
          val refreshed = if (firstPlayback.isCompleted) result else fetch { metadata(true) }
          batches.send(Batch(1, refreshed))
        }
      }
      launch {
        // Let the lightweight version list finish before starting playback probing.
        // A bounded hedge preserves PlaybackInfo-only and stalled-metadata servers.
        if (metadataHeadStartMillis > 0) {
          withTimeoutOrNull(metadataHeadStartMillis) { firstMetadata.await() }
        }
        for (attempt in 0..retryDelaysMillis.size.coerceAtMost(2)) {
          val result = fetch(playback)
          firstPlayback.complete(Unit)
          val error = result.exceptionOrNull()
          val retryable = when (error) {
            is CancellationException -> false
            is JellyfinSourceRequestException -> error.canRetry
            is IOException -> true
            else -> false
          }
          val again = retryable && attempt < retryDelaysMillis.size.coerceAtMost(2)
          if (result.isSuccess && firstMetadata.isCompleted && firstMetadata.await().map { it.id } != result.getOrThrow().map { it.id }) {
            batches.send(Batch(2, result, complete = false))
            // Dynamic servers can finish additional providers after PlaybackInfo selected
            // its first version. One final metadata read picks up those late sources.
            batches.send(Batch(1, fetch { metadata(true) }, complete = false))
          }
          batches.send(Batch(2, result, complete = !again, retryAttempt = if (again) attempt + 1 else 0))
          if (!again) break
          delay(maxOf(retryDelaysMillis[attempt], (error as? JellyfinSourceRequestException)?.retryAfterMillis ?: 0))
          // A provider may have completed after the first request failed. Publish those links
          // before retrying PlaybackInfo; never discard cached or already displayed versions.
          batches.send(Batch(1, fetch { metadata(true) }, complete = false, retryAttempt = attempt + 1))
        }
      }
      var playbackError: Throwable? = null
      var metadataDone = false
      var playbackDone = false
      var retryAttempt = 0
      try {
        while (!metadataDone || !playbackDone) {
          val batch = batches.receive()
          (batch.result.exceptionOrNull() as? CancellationException)?.let { throw it }
          batch.result.getOrNull()?.let { merge(batch.priority, it) }
          if (batch.priority == 1 && batch.complete) metadataDone = true
          if (batch.priority == 2) {
            playbackDone = batch.complete
            playbackError = batch.result.exceptionOrNull()
          }
          if (batch.priority == 2 || batch.retryAttempt > 0) retryAttempt = batch.retryAttempt
          val refreshing = !metadataDone || !playbackDone
          // Item metadata already contains selectable versions on Remux. PlaybackInfo
          // may still be probing its default source for 20–60 seconds; that must not
          // hide filters or imply the returned list is still unavailable.
          emit(JellyfinSourceUpdate(snapshot(), refreshing && sources.isEmpty(),
            if (refreshing) null else playbackError, retryAttempt, refreshing))
        }
      } finally {
        batches.cancel()
      }
    }
  }
}
