/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.domain.jellyfin

import kotlinx.serialization.Serializable
import java.util.Locale

@Serializable
data class JellyfinMediaSource(
  val id: String,
  val name: String,
  val container: String? = null,
  val size: Long? = null,
  val bitrate: Long? = null,
  val streams: List<JellyfinMediaStream> = emptyList(),
) {
  val description: String
    get() = buildList {
      streams.firstOrNull { it.type.equals("Video", ignoreCase = true) }?.displayTitle?.let(::add)
      streams.filter { it.type.equals("Audio", ignoreCase = true) }
        .mapNotNull { it.displayTitle ?: it.language ?: it.codec }
        .distinct().takeIf { it.isNotEmpty() }?.joinToString(" / ")?.let(::add)
      container?.uppercase(Locale.ROOT)?.let(::add)
      this@JellyfinMediaSource.size?.takeIf { it > 0 }?.let { add(String.format(Locale.ROOT, "%.2f GB", it / 1_000_000_000.0)) }
      bitrate?.takeIf { it > 0 }?.let { add(String.format(Locale.ROOT, "%.1f Mbps", it / 1_000_000.0)) }
    }.joinToString(" • ")
}

@Serializable
data class JellyfinMediaStream(
  val index: Int,
  val type: String,
  val codec: String? = null,
  val language: String? = null,
  val displayTitle: String? = null,
  val isExternal: Boolean = false,
  val deliveryUrl: String? = null,
)
