/* SPDX-License-Identifier: AGPL-3.0-or-later */
package app.infinity.mpvz.domain.jellyfin

import app.infinity.mpvz.utils.media.PlaybackSubtitleTrack
import java.util.UUID

data class JellyfinPlaybackCandidate(
  val sourceId: String,
  val url: String,
  val subtitles: List<PlaybackSubtitleTrack> = emptyList(),
  val status: JellyfinLinkStatus? = null,
  val hdrMetadata: Boolean? = null,
)

/** Alternatives are versions of ONE movie/episode, never entries in the episode queue. */
class JellyfinFallbackPlan(selectedUrl: String, initialCandidates: List<JellyfinPlaybackCandidate>) {
  private val tried = linkedSetOf(selectedUrl)
  private val candidates = linkedMapOf<String, JellyfinPlaybackCandidate>()
  init {
    val selectedIndex = initialCandidates.indexOfFirst { it.url == selectedUrl }
    update(if (selectedIndex >= 0) initialCandidates.drop(selectedIndex) + initialCandidates.take(selectedIndex) else initialCandidates)
  }
  @Synchronized fun update(incoming: List<JellyfinPlaybackCandidate>) {
    incoming.forEach { candidates[it.url] = it.copy(status = it.status ?: candidates[it.url]?.status) }
  }
  @Synchronized fun contains(url: String) = url in candidates
  @Synchronized fun next(failedUrl: String): JellyfinPlaybackCandidate? {
    if (failedUrl !in candidates) return null
    tried.add(failedUrl)
    val remaining = candidates.values.filter { it.url !in tried && it.status != JellyfinLinkStatus.UNAVAILABLE }
    val next = remaining.firstOrNull { it.status == JellyfinLinkStatus.REACHABLE } ?: remaining.firstOrNull()
    next?.let { tried.add(it.url) }
    return next
  }
}

/** Bounded process-local state; no credentials or large source arrays are put in an Intent. */
object JellyfinPlaybackFallbacks {
  const val EXTRA_SESSION = "mkvplex_jellyfin_source_session"
  private val plans = linkedMapOf<String, JellyfinFallbackPlan>()
  @Synchronized fun create(selectedUrl: String, candidates: List<JellyfinPlaybackCandidate>): String {
    while (plans.size >= 4) plans.remove(plans.keys.first())
    val id = UUID.randomUUID().toString()
    plans[id] = JellyfinFallbackPlan(selectedUrl, candidates)
    return id
  }
  @Synchronized fun get(id: String?) = plans[id]
}
