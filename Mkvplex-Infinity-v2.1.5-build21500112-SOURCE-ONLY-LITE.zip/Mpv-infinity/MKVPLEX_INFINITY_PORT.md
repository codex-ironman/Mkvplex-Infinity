# Mkvplex Infinity custom build

This port brings the custom Mkvplex build27300192 features to Mpv Infinity's AGPL release v2.1.5, commit `d9b32dfe5b26068a22f4cfea5463729aa843d215`.

The newer v2.2.5 source is not the base: its Permission-Only Terms require express written permission for derivative apps. The v2.1.5 root LICENSE is AGPL-3.0 and remains intact. Original author and dependency notices remain available through Credits & licenses. The About section reads App By Dark Ironman.

App ID: `app.infinity.mpvz.mkvplex`. Release label: Mkvplex Infinity. This installs alongside the existing Mkvplex and official Infinity apps. Accounts and preferences are scoped to this separate app; users add their servers after installation.

## Custom feature coverage

| Area | Port behavior |
| --- | --- |
| Navigation | Jellyfin first, with the other enabled Infinity tabs retained; Back returns to the first tab after child navigation handles it. |
| Jellyfin / Emby | Separate server type, authentication and libraries, including Emby home mapping; Room migration22→23 adds serverType. |
| Available links | Progressive sources, language/text filters, all returned variants, first playable selection without waiting for background enrichment. |
| Link reliability | Deterministic Remux placeholders and no-stream sentinels excluded; bounded first-attempt recovery, explicit fresh Retry, generation/account ownership guards. |
| Fetch performance | Lightweight details, viewed-item prefetch, shared in-flight metadata, 30-second memory cache, 750ms bounded metadata head start; no full-catalog prefetch. |
| Search | Encoded query parameters and one Recursive value, video/music type scope, stale-response rejection, query-preserving Retry and paging. Optional progress bar. |
| Working checks | Automatic working tick, independent fetch/check limits, manual check button on each link. All optional checks default OFF. |
| Copy / cast | Copy-link buttons and long-press Cast for selected sources, each opt-in. |
| Failed-source switching | Next alternative for the same video after a failure or 30-second startup timeout, for MPV and Native; attempts are scoped to current request/load. Default OFF. |
| Buffering speed | Bytes/KB/MB per second, including very slow traffic; MPV stream I/O with app-traffic fallback. Native uses the explicitly labelled app-traffic estimate. Default OFF. |
| Playback info | Manual Info button in portrait and landscape. MPV engine properties or actual Native decoder callback, hardware/software mode, source HDR/profile, resolution/FPS and audio. Missing output/display telemetry remains Unknown. |
| Dolby notices | Optional two-second supported-content notices. Native Vision checks the selected decoder's DV profile capability and the display; Atmos also requires encoded AudioTrack output and a supported route. Source tags alone do not claim final display signalling. |
| Layout | Episode artwork leaves room for titles/descriptions and actions; credits wrap. |
| Startup lag fixes | MPV intent subtitles use asynchronous generation-scoped commands off the main thread; Native subtitles stay on Infinity's Native renderer route. HTTP query-auth source playback omits redundant matching account headers in both engines. |
| Defaults / branding | All custom optional booleans OFF. Manual Info requires a user tap. About reads App By Dark Ironman. |
| Home hero | Lightweight metadata, immediate text title, poster preview for a slow backdrop, and one preloaded next image. Auto-rotation waits until the current image is shown or the load finishes. |

## Verification scope

The original port's full JVM suite completed: 279 cases, 277 passed, zero failures/errors and two optional live/captured-response integrations skipped because no session/capture fixture was configured. This update adds a hero summary request test and two artwork loading tests. The release validation file records the updated results and final APK checks.

The signed release passed package identity, release/non-debuggable, ARM64, v2/v3 signature, 16KiB zip alignment and ZIP CRC checks. All 25 native libraries and 219 bundled non-ART assets are byte-identical to the official v2.1.5 ARM64 APK (SHA256 `c866b214597c8867044eabd54618e13ea30cc148e5b26e9d9e2de9b713db0ccc`). The rebuilt ART profiles are retained for the new DEX. No later permission-only engine implementation is imported. Physical phone playback, sustained network throughput, HDR display signalling and every remote provider cannot be established by JVM tests.

The upstream subtitle native dependency's autotools configure step failed in this build environment. The build therefore stages the exact subtitle JNI bridge from the verified official APK using a build-only init script. The subtitle JNI/Java source is unchanged. Final binary comparison verifies the original bridge and every other native library.

## Installation and settings

Install the ARM64 release as Mkvplex Infinity. Its separate application ID means it can coexist with Mkvplex and the official Infinity app. Add your Jellyfin or Emby server and sign in again; credentials and settings are not copied from another app.

Open Settings → Advanced → Jellyfin / Emby links to enable the custom options you want. Each optional boolean starts OFF. Fetch and check limits are independent; zero means all available links. The Info button is available from the video controls and reads telemetry only while its sheet is open. Official automatic updates are disabled for this separately signed custom package.
