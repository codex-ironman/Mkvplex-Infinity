# Web/app source-loading comparison — build27300172

2026-11-02. App baseline: current custom build27300162 on mpvRx v2.7.2 commit9d5a27c2ba6e53e6d33633791ab8a5bb6747720c. Remux comparison: v0.37.0 commit1fa4e89cc6e63d546bcd0f50f2bb2ed31608bc51.

## What differs from Remux Web

Remux's `crates/remux-server/src/web_patches.rs` patches getItem to fetch `Fields=ChildCount` first and independently fetch `Fields=MediaSources` for the currently viewed Movie/Episode. It enables playback when the latter response arrives. `api/items.rs::item_for_user` uses the presence of MediaSources to decide whether to await addon stream refresh. `api/playback.rs` additionally loads/probes playback candidates and fetches subtitles.

The previous app detail request included MediaSources. Its chooser could separately request those sources while the detail fetch was still running, plus concurrently request PlaybackInfo. Build27300162 already made a returned list selectable without waiting for PlaybackInfo and added a short-lived cache; it did not share an unfinished detail fetch or split lightweight details from dynamic source loading.

Build27300172 omits MediaSources from the viewed item's full-detail request (retaining storyline, people, season/episode, user state and MediaStreams fields). It starts the viewed video's source-only GET independently. This request is shared with a chooser opening before it finishes. No all-catalog or all-episode prefetch is added. Existing display metadata is retained when a lighter response lacks format fields, and successful prefetches are guarded by current detail/server identity.

Metadata receives a bounded750ms head start over PlaybackInfo. A completed metadata request ends that head start immediately. A PlaybackInfo-only server still proceeds when metadata stalls. All original request deadlines, recovery budgets, late merging, selected-source authentication and subtitle behavior remain. In particular, this revision does not remove all PlaybackInfo calls or claim zero network work after a cache hit.

## Controlled tests

150 JVM tests completed:148 passed,2 optional capture integrations skipped, zero failures/errors.

- Two simultaneous consumers receive the same complete104-version response from one blocked metadata request.
- Cancelling the detail consumer leaves the chooser's request running; cancelling the final consumer cancels the work and allows a later fresh request.
- Different servers/users/tokens/items never share a request; account removal cancels only its own work. A failed request can be retried.
- A client HTTP fixture confirms concurrent prefetch/chooser requests result in one metadata HTTP call with all104 versions retained.
- One movie and eleven distinct E8 item fixtures each use one lightweight detail GET and one source-list GET; subsequent cache reads make no extra metadata call. These are synthetic fixtures, not live series availability checks.
- Fast metadata does not wait out an artificial750ms delay; stalled metadata permits PlaybackInfo fallback; closing during the head start does not start probing.
- Existing138 tests are also included. Actual totals and release/native/signature checks are recorded in VALIDATION.json.

## Verification limits

The current browser session opened the login page; no new signed-in live timing result is claimed for this revision. The previous admin web observation of104 The Pitt S1E8 versions and the supplied approximately12.4s server fetch logs remain historical evidence. No phone/emulator UI, full video, or real app-versus-web timing benchmark was performed. This changes app-side request scheduling and duplicate metadata work; it cannot make a cold provider return before the server sends its response.
