# Playback info — build 27300192

The video controls include an Info button in portrait and landscape, opening the existing player sheet layout. The sheet shows engine-reported decoder/description, actual hwdec-current mode, source HDR/profile/level, decoded HDR, renderer target, codec, resolution/FPS, pixel format and selected audio. Source track tags are not presented as proof of the display's active HDR mode. Dolby Vision source profiles remain distinct from a PQ/SDR renderer target. HDR10+ appears only on detected positive scene metadata and PQ; ordinary PQ is labelled HDR10 / PQ, not proof that dynamic metadata is absent.

Only this open sheet reads playback info, once per second on Dispatchers.IO while its lifecycle is STARTED. Closing the sheet cancels polling; no network request, new media probe, MPV option change, track selection or preference write is involved. The snapshot is read under the existing native core lock, checking loaded/current generation and ready/background phase. New loads clear the visible previous snapshot. Track changes and hardware fallback appear on the next sample. No media URL, token, title or full track listing is read or displayed.

Nine JVM cases cover actual software fallback versus configured hardware, MediaCodec direct/copy distinction, Dolby Vision profile versus SDR target, post-filter versus renderer data, positive HDR10+ metadata, HLG, unknown values, bounded non-sensitive reads and format details. Existing regression tests are run alongside them. The bundled native library contains the required property names; unsupported individual values still stay Unknown / not reported.

The engine may report an FFmpeg decoder/backend name rather than Android's internal c2/OMX component name. This UI displays what the engine actually exposes and does not invent a component name. Renderer target properties do not certify final physical screen signalling.

No physical phone/emulator playback or visual validation is claimed. Release checks compare all native libraries and bundled assets with the official v2.7.2 APK and preserve the custom update signing identity. Original decoder/renderer settings and prior subtitle lag changes are retained.

Property semantics: https://mpv.io/manual/master/#properties

Completed JVM run: 172 tests, 170 passed, 2 optional capture integrations skipped, zero failures/errors. Standard app Kotlin compilation also passed.
