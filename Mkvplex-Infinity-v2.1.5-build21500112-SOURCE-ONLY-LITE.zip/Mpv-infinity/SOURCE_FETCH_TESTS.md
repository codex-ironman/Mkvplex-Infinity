# Source fetching validation — build 27300162

2026-11-01. Based on the current private build27300152 backup and public mpvRx v2.7.2 commit9d5a27c2ba6e53e6d33633791ab8a5bb6747720c.

The app previously kept `isLoading` true until both metadata and PlaybackInfo finished. On Remux, a complete metadata version list can arrive before PlaybackInfo finishes probing its default source. The new loading flag represents whether the chooser is waiting for its first valid source; independent `isRefreshing` state keeps the background flow alive and all late merges intact.

The memory cache has a 30-second monotonic lifetime, a 16-item bound and a 1,024-source per-entry retention limit. It does not cap the returned list. Account tokens, users, item IDs and normalized server URLs form its private in-memory key. Nothing is persisted to disk. Failed/empty refreshes do not remove existing usable cache entries. Explicit Retry bypasses cached metadata. PlaybackInfo still runs for source/subtitle enrichment; a warm cache hit does not mean all background requests stop.

## Checks

- 138 JVM tests: 136 passed, 2 optional capture integrations skipped, no failures/errors.
- A complete metadata batch of104 versions enables the chooser while a deferred PlaybackInfo probe is still blocked. A105th source is appended after it unblocks.
- Warm `getItemSources` calls use one metadata HTTP request across two reads; forced refresh makes a second request. A populated detail response also avoids an extra source metadata request.
- Tests verify token/user/server/item separation,30-second expiry, capacity eviction, retained external subtitle indexes, retry freshness and cancellation of outstanding requests.
- All prior player, subtitle lag, buffering rate, advanced default-OFF, parser/placeholder, chronological episode, filter and cast policy tests run in the same suite.
- Admin Remux Web separately displayed104 source versions for The Pitt S1E8. Supplied server logs after disabling CNC/Pengu Stream resources measured12.382537831s(E8,104 versions) and12.360352589s(E13,94 versions) from Gelato/AIOStreams alone. These measurements precede this APK and describe server work, not a device speedup from this change.

## Limits

No physical Android UI/frame-rate, full media playback or ExtremeOS-specific test was performed. The user authorized using the existing admin account for the live server check. This app revision reduces repeated metadata work and post-list loading wait; the server's first cold provider lookup can still take about12 seconds. The native player, visuals and default-OFF preferences are preserved, with packaging checks recorded in VALIDATION.json.
