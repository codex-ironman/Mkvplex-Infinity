# Search correction — build27300182

2026-11-02. Based on the verified93-file custom build27300172 backup on public mpvRx v2.7.2 commit9d5a27c2ba6e53e6d33633791ab8a5bb6747720c.

## Findings and changes

- The video search bar advertised Movies/TV Shows/Episodes, but All omitted IncludeItemTypes. Remux v0.37's default requested types also include audio, albums, artists and channels. The app now explicitly requests its video types; music-library All stays scoped to music.
- Combining a query with a category appended Recursive twice. The URL is now built with encoded parameters and one Recursive value. HTTP fixtures check this for typed and paged search, including spaces, ampersands, literal plus signs and Odia text.
- Search requested dynamic MediaSources in list responses. It now requests lightweight list data and retains MediaStreams, imagery, storyline and series/episode fields. The selected detail/chooser retains its complete source-loading behavior.
- The standard client had a30-second read budget. Search now has60-second reads and90-second total calls so slower remote addon searches can finish. This is a deadline change, not a speedup claim or an artificial delay; ordinary browsing keeps its previous budget.
- A pending library request could publish unconditionally into currentItems after search began. Search cancels/invalidate those loads; generation and scope gates also reject late callbacks that outlive cancellation. Query, category, library and server changes invalidate old search destinations.
- Refresh/Retry now repeats the visible search. Paged searches retain query/type/library; duplicates do not make the server offset repeat, and empty pages stop repeated loading. Clearing whitespace behaves as clearing the query.
- Failed empty searches show the existing error view even with home libraries present. Successful empty responses remain No results. Existing optional search progress/default-OFF preferences and the player are unchanged.

## Verification

The full JVM suite includes the previous150 tests plus13 search tests. New tests exercise the production request gate, page merging and actual client request builder through OkHttp fixtures, including the dedicated Music screen's All types. Music/video context changes reject older results; clearing a music query restores that dashboard and clears the transient mode. These tests do not instantiate an Android activity. Actual pass/skip totals, signed release identity and original native/asset preservation are recorded in VALIDATION.json.

Read-only Remux Web checks returned Avengers movie results (including Endgame, Infinity War and Age of Ultron), the exact Thukra ke mera pyaar show, and The Pitt show. The visible profile was darkironman: although the user supplied an ExtremeOS demo account, that account was not verified and is not claimed as tested. No password/token is included in these artifacts. No server policy, addon, catalog or account setting was changed.

The exact phone search failure was not reproduced on an Android device, and the new APK was not installed on one. These changes repair identifiable request/publishing defects; they do not prove every query/provider/account will return results. Remux's own episode-search policy can still exclude episode results independently of this client.
