# Changelog

These notes are written in plain English and focus on what changed for real use.

## 2.1.5

### What’s new

- A better Stream experience. Browse the built-in catalog or add your own compatible add-ons, then open supported direct links in the player using your preferred playback engine. Poster and season artwork can be enriched with metadata keys.
- Audiobooks that stay in your folders. Browse and play books directly from selected storage, including nested folders—no importing or copying. All Books and Folders are separate views, with progress filters and resume support.
- More ways to make the app yours. Custom themes now let you adjust text color, giving you more control over the look of the app.
- A more dependable music player. Improvements to lyrics and audio-file handling.
- History and playback improvements. Watch history and its settings now work across Media and Stream, while clearing history keeps playback progress and downloads. Watch Statistics stays separate, and resolution labels are more accurate.

## 2.1.4 - Performance, Downloads & Smoothness

### Faster and smoother everyday use

- Improved overall app responsiveness during folder browsing, media-list refreshes, and UI scrolling by keeping filesystem refresh work off the UI thread.
- Improved yt-dlp downloads across supported websites with unique per-video output identity and reliable audio/video merging into a single playable media file.
- Improved download progress handling for smoother status updates while downloads continue in the background.
- Preserved the existing playback engines, media formats, high-refresh UI behavior, animations, thumbnails, and supported app features.

## 2.1.3 - Compatibility Fix

### Custom-theme music player

- Fixed music-player controls and text visibility when custom themes are active by applying the same theme-derived contrast logic used by the seekbar and pause button.

## 2.1.2 - Bug Fixes

### Bug fixes

- Fixed the Native Media3 repeat/loop button.
- Moved lyrics delay controls into a scrollable delay sheet while keeping positive and negative adjustments accessible around the current delay.
- Fixed standby lyrics so the active/current line remains visible.
- Fixed Navidrome search-bar top padding so it no longer hides behind the status bar.
- Fixed custom theme video lifecycle handling so it stops when video playback takes focus or the app goes into the background or closes.

## 2.1.1 - Bug Fixes

### 🐛 Bug fixes

- Fixed chapter lists and chapter indicators not appearing when movies were played with the Native engine.
- Restored compatible Media3 chapter metadata parsing while retaining a guarded fallback for alternate metadata representations.
- Fixed the Native chapter parser for the current Media3 API without changing the supported Native media formats or playback pipeline.

## 2.1.0 - Playback, Streaming, Libraries & Custom Themes

Mpv∞ 2.1.0 brings the major playback, streaming, media-library, subtitle, and custom-theme work now available on the stable branch.

### 🎬 Playback engines

- Added MPV, Media3/ExoPlayer, and Native playback with automatic and manual engine selection.
- Improved engine handoff while preserving playback position, queue state, subtitles, audio tracks, rotation, and playback settings.
- Improved HDR, Dolby Vision, 4K, large-file startup, buffering, seeking, decoder recovery, Picture-in-Picture, Cast, and background playback.
- Added proper pan and zoom behavior in both MPV and Native playback engines, including reliable focal-point interaction and persistent per-video display geometry.

### 🌐 Torrent and network streaming

- Added direct torrent playback, magnet links, torrent metadata files, multi-file selection, buffering, piece prioritization, read-ahead, and transfer diagnostics.
- Improved WebDAV, authenticated network streaming, range playback, remote media recovery, and large remote-file handling.

### 🎵 Music, Jellyfin and audiobooks

- Added local music browsing across Songs, Albums, Artists, Playlists, and Folders with search, sorting, artwork, queues, playlists, and background playback.
- Added Navidrome and Jellyfin music libraries, server-aware navigation, Jellyfin auto-tab support, album-art palettes, ambient backgrounds, and the edge-to-edge music visualizer.
- Added Audiobookshelf integration with audiobook browsing, chapters, artwork, chapter playback, timeline seeking, and player controls.

### 💬 Subtitles

- Added embedded and external subtitle support across MPV, Media3, and Native playback.
- Improved multiple subtitles, dual subtitles, ASS/SSA rendering through libass, subtitle translation, styling, positioning, gestures, pinch-to-zoom, subtitle timing, and PGS/image-subtitle handling.

### 🌈 Custom media themes

- Added saved editable image/video themes, live preview, custom opacity, blur, focal zoom, aspect handling, media effects, and a scrollable theme editor.
- Improved custom-theme visibility and readability across the home screen, cards, navigation, toolbars, dialogs, sliders, player controls, music tabs, network screens, and audiobook screens.

### ✅ Final UI fix

- Restored custom wallpaper and media-background visibility by removing the unwanted opaque black folder-card treatment.
- Corrected toolbar icons, navigation icons, music sub-tabs, labels, and controls that were using the background theme color instead of the contrasting color.
- Restored custom-theme editor controls and sliders, aligned Reset, Cancel, and Save, and renamed **“Save theme”** to **“Save”**.

### 📦 APK variants

- Standard Universal, ARM64-v8a, ARMv7, x86, and x86_64 APKs.
- FongMi Universal and ARM64-v8a APKs.
- Non-Vulkan Universal and ARM64-v8a APKs.
- All release APKs use the in-app version **v2.1.0** and are published with architecture-specific names so the in-app updater can select the correct package.

## 2.0.0 - Native Streaming, Authenticated Downloads & Playback Expansion

Mpv∞ 2.0.0 is a major release containing the complete feature, improvement, and reliability work added after v1.0.9.

### 🎬 Native Stream catalog and browsing

- Added a dedicated Stream screen with catalog rails, posters, media details, hero carousel, seasons, episodes, source selection, and direct playback.
- Added progressive catalog loading, caching, refresh, loading/error/empty states, provider browsing, name-based search, stale-search cancellation, and preserved search state.
- Added per-video aspect-ratio handling and persistent crop, pan, zoom, stretch, and geometry controls so one video's display settings do not unexpectedly affect another video.
- Added automatic black-bar crop detection with variable-aspect safety, ambient-background compatibility, and translated crop states.
- Added animated catalog rails, improved details sheets, source filters, ranked sources, poster handling, and native playback handoff.

### 🧩 Addon catalogs and stream resolvers

- Added persistent custom catalog manifests, multiple addon catalogs, arbitrary catalog types, provider names, catalog IDs, addon rails, and provider switches.
- Added configurable external stream-resolver support, stream URL resolution, resilient parsing, link normalization, direct-stream support, resolver caching, and provider-aware search.
- Added addon search paths, rate-limit handling, progressive refresh, stale-request cancellation, concurrent episode resolution, and resolver diagnostics in the in-app log catcher.

### 🧲 Torrent and series source discovery

- Added multi-source torrent catalogs, magnet metadata, episode source selection, ranked sources, native picker integration, loading states, posters, and source metadata.
- Added season aggregation, missing-season discovery, long-series support, anime identifier fallbacks, alternate catalog routing, and parallel season/episode resolver requests.
- Preserved the original source-selection experience while injecting additional resolver results into the native picker.

### 🔗 Direct media and network playback

- Added direct media playback paths for compatible stream sources and bypassed unnecessary extraction when a source can be played directly.
- Improved browser-like playback, range requests, cache-key isolation, stale-cache rejection, proxy handling, snapshot filtering, episode discovery, and short-response recovery.
- Added HTTP/range diagnostics, direct-stream validation, and better playback recovery for remote sources.

### 🔐 Website WebView login and cookie sessions

- Added in-app WebView login for supported websites including video, social, and media services.
- Added JavaScript, DOM storage, database storage, third-party cookies, viewport support, loading feedback, page-error handling, focus handling, and in-WebView redirects.
- Added persistent cookie-session export, multi-site cookie-file merging, complete WebView cookie-database export across domains and paths, Netscape cookie-file generation, cookie flushing, and non-sensitive cookie diagnostics.
- Added a Jellyfin-style **User Agent** bottom sheet with editable, persistent custom User Agent support.
- Added CookieWebView lifecycle, page, console, HTTP, focus, cookie-name, and export diagnostics to the in-app log catcher without logging cookie values.

### 📥 yt-dlp, Quick Download and media metadata

- Added Quick Download from supported websites through yt-dlp, including authenticated downloads using the configured cookie file.
- Added consistent User Agent behavior across every yt-dlp path: a saved custom User Agent always takes precedence; otherwise the shared default is used.
- Added supported-website referer handling, extractor options, JavaScript runtime support, retries, continuation, progress reporting, and improved shared-link handling.
- Improved downloaded media handling with better source metadata, thumbnails, artwork retrieval, filename handling, and artwork-aware output where supported by the source and container.
- Added separate-stream audio/video selection and merge handling, preventing video-only output when audio is available.
- Added pause, resume, continuation, paused status, direct-download integrity improvements, subtitle authentication, and source-aware media downloads.

### ▶️ Native Media3, MPV and player improvements

- Expanded the Native Media3 playback engine and improved automatic Native/MPV engine selection.
- Added stronger network playback, chapter synchronization, Native chapter seeking, skip-intro/outro seeking, source handoff, direct-playback eligibility checks, and playback-state persistence.
- Improved MPV and Native resume, audio handoff, background playback, music-player standby mode, Picture-in-Picture transitions, player teardown, orientation handling, and end-of-file behavior.
- Improved GPU/rendering configuration handling, decoder fallback, HDR compatibility, MediaCodec surface recovery, buffering, and playback diagnostics.
- Added more reliable per-video display geometry, aspect-ratio, zoom, crop, pan, stretch, and ambient rendering behavior.

### 💬 Subtitles and translation

- Added and improved AI subtitle translation, translated subtitle overlays, native secondary subtitles, cue translation, translation request race handling, and translation-state reset.
- Added automatic subtitle font fallback, configured subtitle typography, imported subtitle-font preservation, native subtitle auto-selection, embedded-subtitle restoration, and player-only translation opt-in.
- Preserved subtitle visibility until translated cues are ready and restored native subtitle behavior when translation is disabled.

### 🎵 Music, lyrics and visualizers

- Improved online lyrics loading, portrait and landscape lyrics layouts, artwork visibility, audio standby, background audio, music controls, and audio-service startup.
- Improved music-player standby mode, resume behavior, visualizer compositing, palettes, alpha handling, and orientation behavior.
- Preserved configured audio seeking and improved music-player lifecycle handling.

### 🌐 Jellyfin, WebDAV and network media

- Added Jellyfin-style browsing, details sheets, connection sheets, media-source selection, selected-stream playback, source-aware downloads, and authenticated subtitle sidecar downloads.
- Improved SMB, FTP, SFTP, WebDAV, and network-stream browsing, connection editing, bookmarks, hidden-folder handling, folder state, audio browsing, subtitle refresh, seeking, reconnects, and proxy recovery.
- Added native playback handoff for supported network media and prevented local proxy streams from being incorrectly routed through yt-dlp.

### 📂 Library, search and navigation

- Added watched-state propagation, child-folder badges, last-folder highlighting, nine-column grids, retained folder/search state, progressive search, cached rails, and improved recently played synchronization.
- Improved settings navigation, searchable preferences, bottom sheets, popup theming, system insets, orientation layouts, animations, and empty/loading states.
- Added improved connection management, media-source browsing, playlist handling, and supported-link routing.

### 🛠️ Diagnostics, build and reliability

- Added catalog, resolver, direct-media, WebView, yt-dlp, playback, Media3, codec, and crash diagnostics with in-app log-catcher integration.
- Added ARM64 catalog/debug build workflows, complete release-variant packaging, runtime asset preparation, resolver lifecycle hardening, Compose compatibility fixes, and activity/context leak prevention.
- Improved background playback, Picture-in-Picture cleanup, download continuation, network reconnects, subtitle restoration, stream loading, stale-search handling, and playback lifecycle reliability.

### ✅ Successful end-state fixes

- Fixed WebView page loading, full-page layout, loading feedback, login-field visibility, keyboard focus, and in-WebView navigation.
- Fixed complete WebView cookie export and cookie flushing after page completion.
- Fixed yt-dlp User Agent mismatches by consistently honoring the saved custom User Agent or the shared default User Agent.
- Fixed supported shared-link extraction and prevented video-only downloads when audio is available by requiring a combined stream or merging separate audio and video streams.
- Fixed Quick Download and standard downloads to share cookie, User Agent, referer, retry, format-selection, metadata, and artwork-aware handling.
- Fixed catalog loading, resolver errors, direct playback handoff, download pause/resume, PiP transitions, subtitle restoration, network reconnects, and multiple playback lifecycle issues.
- The Android app/About version for this release is **v2.0.0**.

## 1.0.9 - Playback Stability, Navigation & Library Improvements

### Playback & HDR
- Restored the fast Native Media3 local playback and seek path used by the stable v1.0.8 release.
- Restored default Media3 load control to avoid excessive memory pressure on high-bitrate 4K HDR and Dolby Vision files.
- Preserved direct local content-URI playback, HDR decoder fallback, and Native playback diagnostics.
- Improved navigation animation behavior and bounded transition work so rapid settings navigation remains responsive.

### Folder State & Library
- Fixed folder swipe actions so watched/new state propagates to child videos and their NEW badges.
- Refreshed retained video lists after folder-wide watched-state changes.
- Kept explicit folder overrides authoritative for child watched and NEW state calculations.

### Optional Extra Features
- Added a Settings > Extra features sub-screen with persisted opt-in controls.
- Added read-only watch-history summaries and library-oriented status checks using existing data.
- Moved the missing-file check and history loading off the UI thread.

### Network & UI
- Improved WebDAV/network media thumbnail handling through the authenticated network stream path.
- Restored configurable screen animations while using bounded animation specs to reduce rapid-open/close UI lag.
- Reverted Navigation3 to stable 1.1.1 after testing newer versions with rapid nested-settings transitions.

## 2.5.0 - Frame Review, Auto Crop & Library Performance

> [!IMPORTANT]
> **Project hiatus:** Following version 2.5.0, Mpv∞ development will be paused until further notice.

### 🎬 Frame Review, Seeking & Playback
- **Frame-Level Review**: Added a full-player Frame Review mode with horizontal frame swipes, previous/next-frame controls, precise frame and millisecond readouts, snapshots with optional subtitles, and a transparent responsive layout.
- **Frame-Addressed Timeline**: The Frame Review slider now selects integer video frames. Dragging uses throttled keyframe previews, while release performs an exact mpv seek with bounded refinement and adjacent-frame correction for precision without sustained decoder load.
- **Reliable Forward and Backward Seeking**: Backward seeks use exact targets to keep audio and video aligned. Forward seeks stop safely before EOF and a subsequent forward action can finish playback instead of becoming unresponsive near the end.
- **Safer Surface Recovery**: MediaCodec video is suspended before an Android playback surface is destroyed and restored only for the matching playback generation, reducing black frames and decoder failures after surface recreation.
- **thumbfast Seek Preview Removal**: Removed the separate ThumbFast overlay engine, frame-decode cache, preference, and UI. Scrubbing now uses one throttled live-video preview path, reducing duplicate decoder work and stale preview races.
- **Smoother Startup and Controls**: Reduced startup control flicker, replaced overshooting control springs with predictable timed transitions, and improved seek coalescing so rapid gestures settle on the latest requested position.
- **Correct Orientation from the First Frame**: Local videos pass their known dimensions into the player so portrait and landscape orientation can be selected before playback appears instead of rotating after startup.
- **Correct Audio State Across Transitions**: Playback teardown no longer carries a temporary seek mute into the next file, and terminal playback state is persisted immediately when a file reaches EOF.
- **Persistent Video Geometry**: Video zoom survives file loads, while crop, pan, zoom, stretch, and ambient rendering now share one consistent geometry path.
- **Immediate Runtime Changes**: Clearing playback history updates repository-backed state immediately, and edited enabled Lua scripts reload with the next player core.

### ✂️ Automatic Crop & Video Output
- **Automatic Black-Bar Cropping**: Added an Auto Crop aspect mode that samples multiple frames, detects persistent black borders conservatively, and caches results for repeat playback.
- **Variable-Aspect Safety**: Auto Crop now handles changing aspect ratios, source rotation, and short or dark scenes without retaining stale crop measurements.
- **Stretch and Ambient Compatibility**: Cropping works correctly in stretch layouts and updates the ambient background from the same final video geometry.
- **Translated Auto Crop Experience**: Auto Crop status, actions, results, and error messages are available across every supported app language.
- **Cleaner HDR Configuration**: Removed redundant tone-mapping and gamut-mapping overrides so HDR output follows the selected pipeline without conflicting transformations.

### 🎛️ Player Controls, PiP & Navigation
- **Onboarding Never Blocks the App**: "Get started" now always enters the app, even when permissions were skipped — the finish page lists any missing permissions in an amber warning instead of the quick-tour toggle, and screens that need storage show a compact in-place "Grant access" prompt.
- **Search Bar Respects the Status Bar**: The inline search bar (folders, videos, music, playlists, network, Jellyfin) no longer renders under the status bar and camera cutout — the system-inset padding lost in the Material search migration is back.
- **Streaming Link Handling Toggle**: New "Open streaming site links" switch in player settings controls whether Mpv∞ registers for YouTube, Vimeo, Twitch, Odysee, and Bilibili links — turn it off and those links go straight to their own apps while direct media URLs keep working.
- **Correct First Playlist Entry**: Opening any video other than the first from a folder no longer shows the opened video's name on the playlist sheet's first row — stale launch metadata from the temporary one-item queue is now cleared before the folder playlist is published.
- **Right-Edge Action Panel**: Added a bare right-edge pull handle that opens the complete player action set in the app's movable `DraggablePanel`.
- **Consistent Action Tiles**: Player actions use a responsive three-column tile layout with normalized icon sizes, no nested circular backgrounds, dynamic colors, and full-tile indicators for active settings such as Background Playback, HDR, Ambient, Repeat, Shuffle, transforms, speed, and zoom.
- **Swipe Speed Lock**: Added a hold-speed swipe gesture with locking, haptic feedback, and reliable restoration to 1x when the lock is released.
- **Configurable Audio Seeking**: Music-player rewind and forward controls now use the configured double-tap seek duration.
- **Reliable PiP Handoffs**: Expanding PiP restores the full player without interrupting playback, Back opens the mini player where appropriate, and the PiP close action stops playback cleanly.
- **Supported-Link Routing**: Expanded Open by default coverage for supported YouTube domains.
### 🌐 Network Streaming & Protocols
- **Auto-Next at End of File Restored**: Videos and music advance to the next queue item again when a file finishes — in the player and during background playback. A 2.5.0 change suppressed the end-of-file signal that keep-open builds rely on; it now flows again and is validated against the playback position so a dropped network stream can't fake it and skip mid-file.
- **Proxy Connection Slot Leak**: Timed-out network proxy operations no longer leave their late-arriving upstream streams open, which could exhaust small servers' connection limits and fail every following request.
- **WebDAV Playback Reliability**: Playback no longer fails outright on servers whose share root rejects or empties a depth-0 PROPFIND (common behind reverse proxies) — only credential rejections abort the connection now, and file sizes fall back to an HTTP HEAD/ranged probe when PROPFIND can't provide them. Failed proxy streams also recover: a dead upstream session is evicted so the next seek reconnects instead of buffering forever, and upstream failures are now logged (redacted) instead of silently returning 503.
- **No yt-dlp for Local Proxy Streams**: Loopback proxy URLs (all SMB/FTP/SFTP/WebDAV/torrent playback) are excluded from the yt-dlp hook outright, so extensionless network files can't be misrouted through the extractor.
- **YouTube on 32-bit and x86 Devices**: Fixed shared YouTube links failing with "could not load this link" on armeabi-v7a and x86 devices — the bundled Python runtime only shipped its arm64 build configuration, so yt-dlp crashed with "No module named \_sysconfigdata\_\_android\_..." before extraction could start.
- **SFTP Support**: Added SFTP as a full network protocol alongside SMB, FTP, and WebDAV — browse folders, stream with seeking through the secure loopback proxy, and manage connections from the same add/edit dialogs (default port 22).
- **Large-File Freeze & EOF Seek Fix**: Network reconnect options now reach the primary playback stream, so a dropped connection or a failed seek-reopen recovers automatically instead of freezing large files or showing endless buffering when seeking back after the end of a file.
- **Proxy Hang Guard**: A network body that ends early now surfaces as a recoverable disconnect instead of leaving the player waiting forever for missing bytes.
- **More Robust WebDAV Streaming**: Full-file streams reuse the shared HTTP client (consistent timeouts, no per-request client leak), and servers that ignore byte-range requests fall back to skip-to-offset streaming so seeking keeps working everywhere.
- **Music on Network Shares**: WebDAV, SMB, FTP, and SFTP browsers now show and play audio files when "Show audio in browser" is enabled, including folder queues and the audio-player interface.
- **Fewer Duplicate Requests**: Prevented duplicate network request bursts during playback startup.

### 🎬 Playback & Stability
- **Precise End-of-File Seeks**: Avoided non-precise seeks into EOF that could end playback unexpectedly.
- **Ambient Sheet Theming**: Fixed the Ambient sheet appearance in light mode.
- **Cleaner Builds**: Resolved Kotlin and Material API warnings and updated dependencies.

### � Onboarding & Quick Tour
- **Step-by-Step Permission Setup**: The first-run permission page is now a guided stepper — one permission per screen with progress dots, so everything fits any display without clipping. Optional permissions (notifications, audio) can be skipped individually, and skipping storage skips the whole permission flow.
- **Quick Tour Opt-In**: The final setup step offers a quick-tour toggle; the in-app tour itself ships in an upcoming release.

### �📋 Media Info
- **Image Details**: JPG, PNG, WebP, GIF, TIFF and other images now get a dedicated Image tab with resolution, format, bit depth, color space, compression, and orientation — including embedded cover images found inside audio and video files.
- **Other & Raw Tabs**: Timecode tracks, programs, and future MediaInfo section kinds appear in a new Other tab together with MKV attachment names, and the complete MediaInfo report is readable in-app from a Raw tab.
- **Full-Value Reader**: Tapping any field opens a scrollable, selectable popup with its complete value and a copy action, so long values are never lost to truncation.
- **Kind-Aware Overview**: Images show resolution, format, bit depth, and size; music shows duration, channels, sample rate, and bitrate; irrelevant placeholders such as "No Video" no longer appear.
- **Complete Container Metadata**: Every General field MediaInfo reports is listed, and the file's system path is shown both under the title and in the container card.

### 🌐 Network, Storage & Subtitles
- **Network Folder Bookmarks**: Save, open, and manage frequently used folders from saved SMB, FTP, and WebDAV connections without duplicating credentials.
- **Hardened WebDAV Playback**: Long-running streams are no longer cut off by a whole-call timeout, reserved filename characters are encoded exactly once, duplicate server entries are removed, and reverse-proxy hrefs resolve safely.
- **Network Subtitle Refresh**: External subtitles are discovered and refreshed correctly for WebDAV and other network media. Next/previous queue navigation now follows the current network item instead of reusing the first item's cached path.
- **Configurable Hidden Folders**: Added controls for including dot-prefixed and `.nomedia` folders that Android MediaStore normally omits.
- **Incremental Hidden Scanning**: Hidden-folder discovery now reuses indexed scan state and refreshes changed roots instead of repeatedly traversing the full storage tree.
- **Android 10 File Operations**: Restored rename, move, delete, and storage permission behavior on Android 10 while retaining scoped-storage handling on newer Android versions.
- **Cleaner Subtitle Colors**: Removed the duplicated subtitle background-color control so one setting owns the rendered value.

### 🎵 Music, Notifications, Lyrics & Playlists
- **Colloquial Hinglish Romanization**: Added a casual Latin-script lyrics option for Indic languages, including per-line mixed-script detection, Hindi schwa deletion, long-vowel handling, nasalization fixes, and cleaner Punjabi apostrophes.
- **No Stale Lyrics After Track Changes**: In-flight lyrics loading, source switching, and translation are cancelled and identity-checked so a slow previous track cannot overwrite the current song.
- **Reliable Notification Favorites**: Music notification favorites use the same stable identity as the app, update immediately, and stay synchronized with playlist changes.
- **Isolated Notification Controls**: Media notification actions now target the active playback session, include a close action, and avoid duplicate or cross-session commands.
- **Save Queue as Playlist**: The current player queue can be saved directly as a named playlist.
- **Faster Playlist Artwork**: Playlist rows reuse cached video thumbnails instead of regenerating artwork while browsing.
- **Relevant Queue Actions Only**: Play Next and Add to Queue remain available for audio selections without appearing in video selection menus where those actions are not supported.

### 📦 Installation
- **Obtainium Access**: Added a direct Obtainium badge and corrected setup link in the project README for easier installation and update tracking.

### ⚡ Library, Documentation & Stability
- **Smooth Large Libraries**: Lists containing hundreds of videos suspend thumbnail decoding, disk reads, and cache-key work during flings, then resume a bounded viewport batch after scrolling settles.
- **Incremental Playback Progress**: Five-second playback persistence updates only the affected library row instead of rebuilding and re-sorting every video, preserving stable lazy-list items and reducing mid-scroll jank.
- **Lower Per-Card Overhead**: Thumbnail preferences are observed once per screen, repository work runs off the main thread, and large video pickers use stable content types and scroll-aware loading.
- **Documentation Crash Fixed**: Fixed issue #571, where scrolling through mpv Input Command documentation crashed on the duplicated `COMMAND:playlist-next` lazy-list key. Playlist commands now appear once and all documentation rows have category-qualified unique keys.
- **More Reliable Player State**: Fixed playback-state updates that could lag behind user actions and improved queue, notification, and playlist synchronization during repeated media changes.

## 2.4.0 — Playlists, Playback Reliability & Expressive Navigation

### 🎬 Playback, PiP & Performance
- **Faster Video Startup**: Removed blocking external asset synchronization from the launch path. Validated internal mpv assets are reused immediately while external assets refresh after playback begins.
- **Reliable Seek Thumbnails**: Hardened ThumbFast-style preview initialization, request ordering, caching, and decode behavior so scrubbing shows the newest requested frame without stale replacements.
- **Clean PiP Dismissal**: Consolidated PiP close handling into one idempotent teardown path, preventing lingering playback, duplicated audio, and brief audio glitches after the PiP window is dismissed.
- **Safer Playback Transitions**: Improved yt-dlp, ambient-mode, clip-editor, renderer, queue, and audio-player lifecycle handling across repeated media changes.
- **Actionable Player Diagnostics**: Expanded statistics Page 6 with real process memory, Java/native heap, mpv cache, buffered duration, packet/file cache, torrent, and playback-health data.

### 📚 Playlists, Queues & Web Media
- **YouTube Playlist Support**: YouTube and other supported web playlist links can be imported from the Playlists tab with ordered videos, titles, channel metadata, and thumbnails alongside existing M3U/M3U8 support.
- **Metadata-Rich Player Queues**: Pasting a YouTube playlist into a link field now starts its first video and preloads every entry into the in-player playlist drawer with title, channel, artwork, duration, and stable URL metadata.
- **More Flexible Queues**: Added Play Next and Add to Queue actions, mixed audio/video playlist support, reliable local M3U path resolution, and safer queue ownership during media handoffs.
- **Shared Favorites Playlists**: Video favorites now appear as Favorite Videos in the main Playlists tab, while the same Favorite Songs collection is available from both Music and Playlists with consistent configured cover-art sizing.
- **Cleaner Playlist Browsing**: Favorite collections are clearly separated by media type, remote cards have consistent selection styling, and network playlist thumbnails and folder queues are restored.
- **Clear yt-dlp Setup**: First-time web playback now prompts before installing yt-dlp and shows installation progress instead of appearing to buffer indefinitely.

### 🔎 Search, Lyrics & Discovery
- **Production Settings Search**: Expanded settings coverage with ranked fuzzy matching, typo tolerance, subsequence matching, direct conditional-setting routing, precise scrolling, and highlighted matches.
- **Better Lyrics Coverage**: Added embedded ID3v2 lyrics extraction for MP3 files and improved online lyrics lookup for YouTube media.
- **Focused Browser Actions**: Queue selection actions now appear only in modes where they are valid, avoiding video-mode actions that depend on audio inclusion.

### 🧭 Navigation & Interface
- **Responsive Tab Navigation**: Added a smooth one-to-one sliding navigation pill and cancellable page transitions so rapid or random tab taps always settle on the latest selected destination.
- **Stable Swipe Navigation**: Restored predictable tab swipes and removed competing page-state writers that could leave the browser between screens.
- **Refined Player Controls**: Added always-dark player control backgrounds, unified light/dark button palettes, refreshed segmented controls, and improved audio-player controls.

### 🔔 Notifications & Remote Controls
- **Stateful Media Actions**: Media notifications now use Material Symbol transport icons, visibly distinguish saved Favorites, cycle Repeat states correctly, and expose expanded playback controls.
- **Reliable Notification Ownership**: Prevented duplicate media cards, restored the correct audio route, and kept notification state synchronized with the active playback session.
- **Clear PiP Seeking**: PiP controls now use dedicated Replay 10 and Forward 10 Material Symbols for precise ten-second seeking.

## 2.3.0 — Playback, Streaming Quality & Media Experience

### 🎬 Playback Reliability & Native Tools
- **Reliable Media Handoffs**: Reworked ownership across the player, mini-player, and background service so stale activities, callbacks, resolvers, and queues cannot take over a newer request. Audio-to-video, video-to-audio, playlist, URI, torrent, and yt-dlp transitions now avoid freezes, audio-only video, lost metadata, and mismatched queues.
- **Safer Session Recovery**: Playback position restores correctly after session recreation, HTTP demux cache survives player transitions, videos pause when the app moves to the background, and mini-player replacement no longer races the active session.
- **FDSAN-Safe mpv Builds**: Fixed the Android libmpv subprocess file-descriptor sanitizer crash in both standard and Fongmi builds, refreshed the bundled mpv libraries, and hardened native stop/replacement sequencing.
- **Native Video Clipping**: Added an on-player clipping workflow and hardened the editor and export path for reliable repeated use.
- **Player Lifecycle Fixes**: Prevented duplicate audio autoplay advances, playlist-sheet crashes, released-session service shutdowns, stale background-playback handoffs, and cross-contamination between audio brightness and playlist selection.
- **Restored Ambient Glow**: Brought back the proven v1.4.1 ambient glow shader and removed conflicting legacy ambient behavior.

### 🌐 Streaming Quality, yt-dlp & Subtitles
- **Per-Video Quality Selection**: Added a quality control for network streams and per-item yt-dlp format selection, with the chosen format carried through playback instead of applying one global guess.
- **Clearer Web Playback Status**: Improved yt-dlp web playback, resolver status feedback, and quality-button visibility across the player layouts.
- **Episode-Aware Subtitle Search**: SubHub searches now retain the current season and episode context when media moves through the playback pipeline.
- **Dedicated Subtitle Preferences**: Added a focused subtitle section to Settings so subtitle controls are easier to find and manage.

### 🍿 Jellyfin & Seerr
- **Built-In Seerr Requests**: Integrated Seerr with Jellyfin so movies and series can be discovered and requested inside Mpv∞, with refined discovery cards and live request-status updates.
- **Jellyfin Music in the Mpv∞ Player**: Jellyfin audio now uses the full music-player experience, with a redesigned Music section, complete album queues, swipeable tabs, home playlists, favorites, and synchronized favorite state.
- **Faster Jellyfin Actions**: Added direct quick play, YouTube trailers, improved resume actions, and a browser FAB that closes predictably, follows scrolling, and blocks accidental tab gestures while open.
- **Richer Library Browsing**: Moved libraries ahead of Continue Watching, redesigned list and episode layouts, improved season selection, and fixed tablet mini-player overlap.
- **Jellyfin Stability**: Fixed authentication persistence, music queue resolution, cover-art loading, local artwork handling, bitmap crashes, and incorrect album playback.

### 🎵 Music, Lyrics & Recents
- **Refined, Translated and Romanized Lyrics**: Improved the lyrics interface and controls, added lyric translation and romanization, and made Hindi and Indic transliteration, full-sentence parsing, and per-line results faster and more accurate.
- **Playlist Favorites & Feedback**: Added favorite controls in the music player, protected the default playlist, introduced square playlist artwork, and added an animated visualizer indicator for the currently playing track.
- **Reliable Local Music Discovery**: Folder artwork and local artwork URIs now decode correctly, and the music library automatically scans after the first permission grant and when the app resumes.
- **Separate Video and Audio History**: Recently Played now has swipeable Video and Audio tabs with independent filtering, counts, empty states, scrolling, and artwork sizing.

### 🧭 Browsing & Interface
- **Fuzzy Media Search**: Added typo-tolerant folder and video search for faster navigation through large libraries.
- **More Predictable Browser Controls**: Improved FAB expansion, outside-tap dismissal, scroll integration, quick-play access, and recent-item padding across browser screens.
- **Smoother Navigation**: Removed the bottom-navbar delay during page swipes, added swipe navigation to Jellyfin music tabs, and merged Network tabs into the header for a cleaner layout.
- **Player Control Polish**: Refined gesture handling, added speed-scaled remaining time, improved timer contrast, tightened control spacing, and made quality-control placement more consistent.

### 📦 Updates & Release Delivery
- **Preview Update Channel**: Added preview-build discovery to the in-app updater and a live release channel to the preview download site.
- **Activity-Aware Preview Builds**: Preview automation now checks for unpublished app changes before building, while still supporting complete manual builds.
- **Clearer Download Links**: Updated preview-site download link colors for better visibility.

## 2.2.2 — Lyrics & Navigation Hotfix

- **Smooth Karaoke Fill**: Word-timed lyrics now fill continuously from left to right with a soft glow. The previous per-letter jump, scale, and layout movement have been removed.
- **Reliable Tab Swiping**: Main browser navigation now uses the pager's settled page as its single source of truth, preventing interrupted swipes from leaving Recents and Playlists stuck between pages.
- **Synchronized Builds**: Standard, Fongmi, and non-Vulkan packages are built together from the same release tag and app source revision.

## 2.2.1 — Playback & Lyrics Hotfix

### 🎬 Video Playback Reliability
- **Black Screen on Startup Fixed**: Video output now waits for Android to attach a valid render surface before mpv initializes the renderer. This restores the proven 2.1.0 startup order and prevents `Missing surface pointer`, audio-only playback, and permanent `video=eof` states on slower devices, including Vivo devices running Android 16.
- **Safer Surface Recreation**: If the surface disappears while a file is loading, video selection is deferred until the replacement surface is attached instead of racing a destroyed native window.
- **Single Video-Restoration Path**: Removed duplicate Activity-level restoration state so `PlaybackSession` is the sole owner of deferred video selection.

### 🎤 Lyrics & Update Notes
- **Word-Timed Karaoke for Standard LRC**: Regular LRCLIB line-synced lyrics now receive stable per-word timing, so the active line animates word by word instead of displaying one static sentence. Enhanced LRC files keep their original word timestamps.
- **Consistent Centered Lyrics**: Normal and fullscreen lyrics now use the same centered layout for active lines, translations, and plain lyrics.
- **Maintained Markdown Renderer**: Update release notes now use the lightweight Material 3 Markdown renderer from Maven Central instead of a custom parser.

## 2.2.0 — Jellyfin, Torrent Series & Player Reliability Release

### 🪼 Jellyfin Streaming Integration
- **Built-in Jellyfin Client & Tab**: Connect to your Jellyfin server and browse Movies, Shows, and Music directly inside the app, with authenticated streaming, external subtitle support, and a bottom-sheet server setup flow that replaces the old dialog.
- **JellyCine-Style Home Experience**: Completely redesigned Jellyfin tab using Material 3 Expressive components — hero carousel with autoscroll animations, resume carousel, expanded Top Picks, and a dedicated Music section on the home page.
- **Richer Library Cards & Ratings**: Library cards now fetch real cover art and show IMDb star ratings, with Rotten Tomatoes ratings reorganized for readability and your libraries prioritized in the order you use them.
- **Faster, Smarter Library Browsing**: Libraries are queried by item type instead of slow folder traversal, with server-side genre filtering, prioritized Shows/Movies in search results, search debouncing, and direct breadcrumb navigation.
- **Episode Auto-Play & Next-Episode Overlay**: Series continue automatically with a next-episode overlay, audio/subtitle language sync between episodes, and an item info sheet for details before you play.
- **Two-Way Playback Sync**: Playback state (pause/resume/stop) is reported to the server in real time, and the app pulls your freshest watch position from Jellyfin before starting playback — resume works across devices.

### 🧲 Torrent Series & Network Streaming
- **Series Torrents Become a Real Playlist**: Multi-file torrents now appear as one playlist entry per episode (sorted naturally), so you can jump between episodes from the queue sheet, use next/previous, auto-advance at the end of an episode, and keep separate resume positions per file. Switching episodes restarts the stream on the right file automatically.
- **Media Tab Redesign**: The Torrent tab became the unified Media tab in JellyCine style — hero banner, resume carousel, poster cards, and a detail sheet — with saved torrent and network streams unified in one place and a save/open action on recent stream links.
- **Network Tabs Reorganized**: Tabs reordered to Local Network, Media, and Syncplay, with "Saved Links" naming and a streamlined Media tab UI.
- **Smarter Recents**: YouTube links now persist their real video titles and thumbnails into recents, and network streaming episode rows show proper episode titles with Jellyfin artwork fallback.
- **Honest Buffering Indicator**: A proper buffering spinner for network and torrent streams that only appears during genuine cache stalls — no more flicker while seeking or when controls are hidden.

### 🎤 Lyrics & Audio Experience
- **Letter-by-Letter Karaoke Lyrics**: Synced lyrics now animate every single character on its own beat — letters rise into place with a pop, glow briefly, and sweep from dim to bright, driven by a frame-interpolated playback clock so the wave stays fluid even between position updates.
- **Centered Lyric Focus**: The active line glides to the center of the view (instead of sticking to the top) with a depth-of-field falloff — nearby lines stay readable while distant lines blur and fade. Fullscreen lyrics are center-aligned with larger type.
- **Visualizer Engine Cleanup**: All four visualizers (Galaxy, Blob, Cuboid, Particle) now share one audio analysis source of truth — beats, volume gating, and spectrum data are identical across styles, and a dead duplicate rendering engine was removed.
- **Audio Quality-of-Life**: New audio file picker with persistent folder selection, an autoplay-next-audio preference, immediate audio stop when closing the player, correct "now playing" highlight in the music list, and a crash fix when starting playback from the Songs tab.

### 🎬 Player Reliability & Playback Engine
- **Load Recovery & Watchdog**: Media that never becomes ready now times out with a visible error and automatic retry instead of hanging forever; playback also recovers cleanly after reopening the app, and end-file metadata edge cases no longer crash the session.
- **Resume Position Correctness**: Each video resumes from its own saved position — the next playlist item no longer inherits the previous video's progress, progress is persisted for the active playlist item, and history identity is unified for local files.
- **Subtitle Improvements**: Choose preferred subtitles by ordered title keywords (e.g. "Dialogue" before "Signs"), yt-dlp subtitle titles no longer confuse language filters, and subtitle scale/position now compensate correctly during GPU video zoom and pan (#395).
- **Skip Markers Fixed**: Intro/outro skip markers no longer accidentally advance to the next video, and marker metadata survives track changes.
- **Zero-Permission External Playback**: Files shared from other apps play via file descriptors without any storage permission, with robust fallbacks for content URIs.
- **mpv.conf Option Ownership Page**: A dedicated, organized settings page (replacing the old popup) to hand specific option groups — renderer, decoder, shaders, subtitles, and more — over to your mpv.conf, with per-option control, live counts, and one-tap reset.

### 🧭 UI, Navigation & Updates
- **Expressive Adaptive Navigation Bar**: New Material 3 expressive navbar that sizes its pill to the actual content, adapts between phone and tablet instead of cramming six tabs, and centers correctly on launch.
- **Codec Support Indicators**: Per-video decoder support badges across browsing screens and a cleaned-up codec capabilities page, so you can see hardware vs. software decode support at a glance.
- **In-App Updates Get a Bottom Sheet**: The update dialog was replaced with a modern bottom sheet that renders release notes as formatted Markdown (headings, lists, bold, links) with version chips, release date, size, and download progress.
- **Picture-in-Picture Polish**: The media notification now stays available in PiP mode (#402).

### ⚡ Performance, Networking & Stability
- **One Shared HTTP Stack**: The bundled libcurl was replaced by the app-wide OkHttp client (scripts, Jellyfin reporting, subtitles all included), reducing native footprint and unifying cookies, headers, and TLS handling.
- **ANR & Leak Fixes**: Fixed a teardown ANR, audio-focus races, and an HLS credential leak; preference listeners are now shared instead of one per collector.
- **Snappier Lists**: Recently-played lookups are indexed, per-render date formatters were hoisted, recompositions were trimmed in Jellyfin browsing, and the library scrollbar no longer overlaps content.
- **Cleaner Codebase**: The project was reorganized along MVVM lines (update feature split into domain/UI layers, domain no longer depends on UI), every compiler warning was fixed, and dead code was removed.

## 2.1.0 — Feature & Experience Release

### 🧲 Native Torrent Streaming & Media Browsing
- **Built-in Torrent Streaming Engine**: Stream and play `.torrent` files, magnet links, and HTTP torrent URLs directly with background piece caching, sequential download prioritization, and integrated local streaming server.
- **Dedicated Torrent File & Episode Picker**: Interactive file selection screen showing all playable video and audio items within multi-file torrents, complete with individual file sizes, format tags, launch status, and episode labels.
- **Anime & Series Torrent Cards**: Redesigned Torrent history cards in Network Streaming that automatically group multi-episode series with expandable episode lists, poster art, synopsis, release year, and media type tags.
- **Smart TMDB Metadata & Artwork Parsing**: Multi-stage metadata engine that intelligently parses filenames, seasons, and episodes (supporting complex scene tags, colon separators like `S1:E1`, cross-format `1x01`, dashes, and anime numbering) with multi-candidate fallback search against TMDB to fetch high-resolution posters, backdrops, and overviews.
- **Inline Episode Search & Sorting**: Built-in search bar within expanded torrent cards to quickly filter large episode collections by title, file path, or episode number, alongside ascending/descending (1–N / A–Z) sorting toggles.
- **Torrent Playback History & Progress Memory**: Automatically tracks opened and watched torrent files with checkmark badges and one-tap resume capabilities.
- **Real-Time Torrent Buffering Status**: Live buffer duration indicator and demuxer cache percentage chip displayed directly beneath the player loading spinner during network cache buffering.

### 🎵 Music Library Revamp & Audio Player Experience
- **Dedicated Music Library Screen**: Completely redesigned Music tab with organized sub-tabs for **Songs**, **Albums**, **Artists**, **Playlists**, and **Folders**.
- **Audio Folder Browser & Sorting**: Integrated folder-based audio browser in the Music Library with folder sorting dialog (`FolderSortDialog`), instant text filtering, and clean audio-only traversal.
- **Customizable & Reorderable Music Sub-Tabs**: Preference setting to toggle visibility and customize the ordering of Music Library sub-tabs to match your workflow.
- **Interactive Cover Art Swipe Pager**: Horizontal swipe gestures on album art cards to fluidly navigate between previous and next tracks in active playlists with real-time drag physics.
- **Synchronized LRC Lyrics & In-Place Lyrics View**: Full support for synchronized LRC lyrics featuring white active-line highlighting, tap-to-restore fullscreen mode, auto-hiding controls, and embedded vs. external source toggling.
- **Audio Visualizers & Reactivity**: Full visualizer support across 4 distinct styles (Galaxy, Blob, 3D Cuboid Warptunnel, Particle) with spectrum capture lifecycle optimizations that suspend rendering behind sheets to save battery.
- **In-Place Lossless Specs & Audio Enhancements**:
  - Direct on-card Lossless badge with tap-to-expand details (`HI-RES LOSSLESS`, format, sample rate, bit depth, bitrate).
  - Quick-access Equalizer button in player controls, dedicated playback speed indicator next to A-B loop, and in-player playlist management.
  - Dynamic Range Compression (DRC) audio filter and non-overriding filter pipeline.

### 📦 Release Flavors & Device Compatibility
- **Standard Default Build**: The primary release featuring full `gpu-next` and Vulkan hardware acceleration, built for standard modern Android devices.
- **Non-Vulkan Compatibility Build**: A dedicated flavor with Vulkan disabled to eliminate startup and playback crashes on legacy GPU drivers and older devices without Vulkan support.
- **Fongmi High-Performance Build**: Advanced flavor supporting MediaCodec hardware decoding under Vulkan mode, aggressive rendering optimizations, and Dolby Vision (DV) playback capabilities.

### 🌐 Network Streaming, Proxies & Protocols
- **In-App HLS Proxy Engine**: Added dedicated local HLS proxy server with a settings toggle for optimized live stream and HLS media handling.
- **SMB Tree Ownership & Session Reliability**: Resolved DiskShare closing issues where session-cached SMB connections were prematurely closed during per-request streams.
- **Preserved HTTP Headers & Cookies**: Custom headers, cookies, and user-agent strings are now properly preserved across network stream resolvers and playback requests.
- **Recent Stream Cards & Quick Autofill**: Quick paste and autofill stream cards with one-tap playback launch.

### 📱 UI Polish, Themes & Controls
- **New Aurora Theme**: Added modern Aurora gradient color theme and refreshed navigation library icons.
- **Auto-Marquee for Long Media Titles**: Implemented continuous auto-marquee scrolling for long track names, torrent titles, and episode filenames across all list rows.
- **Expanded Video Sharpness Limits**: Expanded video sharpness adjustments to a full $\pm 10$ range (Issue #391).
- **Translucent Bottom Sheets & Normal Seekbar Polish**: Soft translucent sheet background styling (Issue #391) and fixed normal seekbar track coloring in dark themes (Issue #393).
- **Smooth Tab Pager & Navigation Inset Clearance**: Added pre-paging cache (`beyondViewportPageCount = 1`) and graphics-layer translation to prevent jank during tab swipes, with bottom padding clearance across all tabs to prevent navigation button overlap.
- **Video Mini-Player Control**: Option to toggle mini-player for video playback independently of audio, with subtitle suppression in mini-player mode.
- **Pulsing Search Highlights & Autoscroll**: Settings search now smoothly scrolls to and pulses the target preference with a high-contrast highlight indicator.
- **Unified Audio & Video Folder Blacklisting**: Manage blacklisted directories for audio and video media libraries independently or together.
- **Supported Codecs Inspection Screen**: Detailed hardware vs. software decoder capabilities list for all audio and video media codecs supported on device.
- **Full Multi-Language Localization**: Added complete Hindi language translation support alongside English, Arabic, German, Spanish, French, Japanese, Brazilian Portuguese, Russian, and Simplified Chinese.

### ⚡ Performance, Engine & Stability
- **Upgraded MPV Engine & FFmpeg 9.0**: Updated bundled `mpvlib` binaries with updated SSL certificates, Fongmi Vulkan / MediaCodec support, and universal non-Vulkan fallbacks for older devices.
- **Precise Network Seek Previews & Seek Guards**: Enhanced seekbar thumbnail scrubbing precision over network streams, non-blocking thumbnail extraction, and seek-guarding to prevent audio stuttering during rapid scrubbing.
- **Playback History Disambiguation**: Resolved history collisions for same-named files in different directories by keying history records with unique canonical paths (Issue #382).
- **Jetpack Compose Low-Power Tuning**: Phase-deferred layout and draw calls, memoized image bitmaps, optimized list recycling with `contentType`, and elimination of recomposition stalls during tab swiping.
- **Memory & Lifecycle Hardening**: Added LeakCanary detection in debug builds, persistent foreground playback notification services, and leak-free session teardowns.

## 2.0.0 — Major Release

### 🎵 Music Player & Audio Experience
- **Dedicated Music & Audio Player Interface**: Built a full-fledged audio player UI with responsive portrait/landscape layouts, dynamic theme backgrounds, transparent visualizers, cover art polish, and real-time metadata display.
- **Tablet Landscape Dual-Pane Music Player**: New tablet-optimized two-pane music player layout with smooth drag-and-drop playlist reordering.
- **Interactive Audio Visualizers**:
  - **3D Cuboid Warptunnel Visualizer**: Ported native Compose Canvas 3D tunnel visualizer featuring dynamic tunnel radius, touch-steering controls, 3D rotation gestures, pinch-zoom, screen-filling scale, dynamic theme palettes, and interactive reactivity.
  - **OpenGL Blob & Galaxy Visualizers**: High-rate spectrum capture, FFT audio-capture energy processing, tuned frequency envelopes, frame-time-aware interpolation, and responsive beat decay for smooth, jump-free rendering.
  - **PCM-based Visualizer Pipeline**: New per-bin FFT texture pipeline for enhanced audio spectrum analysis with dual waveform/FFT capture.
- **Separate Background Playback Controls**: Introduced independent background playback settings for audio vs. video media with notification permission prompts, system brightness restriction to valid ranges, and automatic service cleanup.
- **Smarter Media Notifications**: Audio notifications now strip file extensions from track titles and fall back to embedded album art when MPV reports no thumbnail.
- **Uninterrupted Background Music**: Swiping back during audio playback keeps the song playing, the playback service stays alive when reopening the player from a notification, and toggling the background playback setting off no longer pauses active music.
- **Equalizer & Audio Filters**: Added a built-in equalizer with debounced MPV audio filter updates for smooth slider movement, A-B looping, and persistent pitch correction controls.
- **Audio Playlist Management**: Added drag-and-drop playlist item reordering, M3U/IPTV `tvg-logo` thumbnail fallbacks, square 1:1 artwork cards, and automatic sibling audio file list population.
- **Audio Player Orientation & Controls**: Added configurable audio player orientation settings, centered play/pause controls in portrait mode, and dedicated audio background playback toggle.
- **Audio Mode UI Fixes**: System bars no longer flicker when opening sheets in audio mode, and seekbar timer colors adapt to the active theme.

### 📺 Google Cast & Remote Controls
- **Native Cast Integration**: Added stateful Google Cast buttons to both portrait and landscape player control bars with layout migration support for existing configurations.
- **Local & Remote Media Handoff**: Casts remote HTTP(S) streams directly, while local `file://` and `content://` media are served over a secure, tokenized local HTTP server with byte-range seeking and CORS support.
- **Remote Cast Controller**: Full-featured remote control dialog supporting play/pause, volume adjustment, seeking, playback speed selection, and media track switching.
- **Playback Continuity**: Seamlessly synchronizes title, play state, duration, and position when transferring playback between local device and Cast receivers, restoring state on disconnect.
- **Graceful Cast Degradation**: The player stays fully functional when the Google Cast module is unavailable on a device.

### ⚡ Performance & Video Player Polish
- **GPU View Transformations**: Implemented hardware-accelerated GPU view transformations for ultra-smooth video panning and zoom.
- **Refined Touch Gestures**: Restricted video pan gestures to two-finger operations to prevent accidental screen shifts while scrubbing or adjusting volume/brightness. Decoupled video and subtitle gesture toggles.
- **Snap-to-Preset Hold-Speed**: Hold-speed gesture now snaps to fixed presets (0.5x, 1x, 1.5x, 2x, 2.5x, 3x, 3.5x, 4x) displayed as a clean text pill, replacing the old overlay slider.
- **Native Ported Thumbnail Pipeline**: Integrated fast native video thumbnail extraction pipeline (ported from mpvRex) for instant seekbar scrubbing previews and refreshed visible thumbnail updates.
- **YouTube-Style Ambient Lighting**: Added ambient background mode that dynamically projects matching video color highlights around the player.
- **Display Refresh Rate Auto-Matching**: Automatically adjusts the display refresh rate to match video source frame rates for smooth, tear-free video output.
- **Anime4K & Vulkan Upscaling**: Added standalone Anime4K Ultra upscaling mode with `gpu-next` Vulkan requirement checks and optimized baseline profiles.
- **HDR Mode Hardening**: HDR modes are now properly gated by renderer support (GPU Next + Vulkan), colors are restored correctly when HDR is disabled, and your last selected HDR mode is remembered between sessions.
- **Linear HDR Restored**: Reverted Linear HDR to use mpv-native pipeline without hdr-toys shaders, fixing brightness issues on supported devices.
- **Robust Player Sessions**: Added an mpv session coordinator that reliably tears down and recovers sessions (no ghost players after crashes), sanitizes the mpv config, and collects player diagnostics.
- **Negative Brightness Control**: Support for negative brightness adjustment to dim the display below system default minimums.
- **Instant Video Launch & Startup Optimization**: Offloaded file loading to `Dispatchers.Default` to eliminate UI thread blocking. Deferred cold-start DB init, grammar pre-load, and auto-update checks to cut first-frame time significantly.
- **Screenshot Timestamps & Templates**: Re-worked screenshot templates (`%F`, `%P`, `%p`, `%wH`, `%wM`, `%wS`, `%wT`) to use exact video playback position instead of wall-clock time.
- **Audio Decoder Fallback**: Added audio decoder check and fallback for unsupported audio codecs in compressor.

### 📱 UI & Modern Tablet Dual-Pane Design
- **Telegram-Style Floating Pill Navbar**: Redesigned bottom navigation bar with a modern floating pill design, smooth sliding indicator animations, and gesture-synced pill motion that follows finger swipes across tabs.
- **Horizontal Pager Tab Navigation**: Implemented swipeable horizontal pager transitions across main navigation tabs (`MainScreen`).
- **Tablet & Foldable Dual-Pane Layouts**: Full dual-pane interface support for Folder List, File System Browser, and Settings screens with active folder card highlights and animated navigation pills.
- **Dynamic Grid & Column Layouts**: Independent grid/list view toggles for folders and video lists with custom column counts, side-by-side column sliders, and haptic feedback ticks on snap.
- **Quick Play FAB & Direct Play Toggle**: Added Quick Play Floating Action Button (FAB) with action menu (Open File, Recently Played, Open Link) and a new **Direct Quick Play** setting to immediately launch recent media without showing the menu.
- **Tree View Path Compression**: Configurable single-child folder flattening (`Off`, 1–5, `Unlimited`) applied per navigation step.
- **FAB Alignment & Exit Animations**: Aligned FAB Y-positions across Home, Recents, and File System screens, and preserved floating action bar buttons during exit animations.
- **Navbar & Toolbar Polish**: Fixed floating navbar bottom inset padding, added a smooth animated selection toolbar, and fixed the bottom navbar hiding in the audio library.
- **Unified Blur Theme Transitions**: Consistent blur-based theme transitions throughout the app.
- **Rounded Material Symbol Icons**: All app icons unified onto rounded Material Symbols with a cleaner icon pipeline.
- **Header Theme Toggle**: Single tap on app name/screen title now toggles dark/light theme with circular reveal animation (always enabled).

### 🌐 Syncplay & Network Streaming
- **Synchronized Room Playback**: Complete Syncplay client implementation featuring server connections, room creation/joining, MD5 password authentication, latency compensation, protocol version handshakes, and user list sync with background reconnection fixes.
- **Native HLS/DASH Streaming**: Direct media URLs (`.m3u8`, `.mpd`, `.mp4`, `.ts`) bypass yt-dlp to use MPV's native ffmpeg demuxers for faster, crash-free playback.
- **Expanded Protocol Support**: Added native stream detection and intent filter handling for `gopher://`, `sctp://`, `data://`, and MIME-only external player intents.
- **WebDAV Connectivity Enhancements**: Depth-zero `PROPFIND` connection checks for compatibility with servers like FileBrowser Quantum, with consistent trailing slash handling.
- **yt-dlp Audio Quality Selection**: Preferred audio stream quality selector (Auto, 64, 128, 192, 256 kbps) for network media links.
- **Lua Script Module Syncing**: Automatically syncs `script-modules/` to internal storage so Lua `require()` calls locate custom MPV modules.

### 🤖 AI Providers & Smart Tools
- **Multi-Provider AI Engine**: Integrated support for OpenAI, Anthropic, Groq, OpenRouter, Together AI, and OpenCode.
- **Resilient AI Parsing**: Added reasoning-block stripping, fallback JSON parsers, and provider-specific model memory for smart file renaming and subtitle cleanup.

### 🔍 Subtitle System & Search
- **Real-Time Subtitle Merging**: Online subtitle search results from SubHub and Wyzie stream in live as requests complete.
- **Anime Skip Integration**: Added Anime Skip provider integration (GraphQL api.anime-skip.com) for intro/ending detection, and removed obsolete TMDB mirror.
- **Hitbox & Gesture Adjustments**: Dynamic multi-line wrapped text hitbox calculations under zoom/pan, option to invert swipe subtitle gesture direction, and automatic secondary subtitle position offset using primary hitbox to prevent overlap.
- **Subtitle Track Roles**: Subtitle track sheet now displays track roles (primary/secondary) for multi-role subtitle tracks.
- **Stream Subtitle Fix**: Subtitles load reliably on network streams without breaking background playback.
- **Korean Subtitle Fix**: Fixed broken Korean Jamo rendering using NFC Unicode normalization.
- **Subtitle Persistence & Search Keyboard Fix**: Subtitles persist across sessions reliably (`addSubtitleSuspend`), and soft keyboard no longer covers the subtitle search dialog (`adjustResize`).

### ⚙️ Settings, Lifecycle, i18n & Binary Footprint
- **Dedicated MediaSearchEngine**: High-performance search engine indexing files and folders with VideoFolder references.
- **Incremental Folder Scanning**: Hidden folder scanning is now incremental and DB-backed, so revisiting large libraries is dramatically faster.
- **Settings Search & Suggestions**: Dynamic reflection-based settings search with query history and real-time suggestions.
- **App Language Preference**: Added per-app language selection independent of system language settings.
- **Redesigned Permission Setup**: Storage permission page redesigned with separate File & Notification sections and a guided Next-button flow, now responsive across screen sizes.
- **mpv Config Validation**: The config editor validates `mpv.conf` before saving and properly closes editor streams to avoid file lockups.
- **Folder Deletion Behavior**: Media-only deletion mode by default (removes video/audio files while protecting documents/images) with full recursive deletion toggle in settings.
- **Unified Background Playback Lifecycle**: Streamlined PiP transitions, screen lock/unlock handling, and task removal behavior for Android 15/16.
- **Android 16 Compatibility**: Native libmpv subprocess handling updated for Android 16, with a cache-safe, coordinated MPV teardown process.
- **Binary Footprint Optimization**: Removed ~50 MB of unused `libpython_bin.so` binaries across all CPU architectures.
- **Toast Notifications for Blocked Audio**: Displays helpful toast alerts when background playback is restricted by notification settings.
- **Memory Leak & Crash Fixes**: Plugged 5 memory leaks across player activity, main activity, and background services, and fixed audio player back navigation crashes.
- **Full Multi-Language Localization**: Complete string key synchronization and translations across English, Arabic, German, Spanish, French, Japanese, Brazilian Portuguese, Russian, and Simplified Chinese.
- **Code Cleanup**: Removed dead code, extracted shared utilities, DRY/SOLID cleanup across codebase.

### 🔒 Secure Folder
- **PIN Gate & Grid Screen**: Secure Folder now requires PIN authentication before access, with a grid view of secured media.
- **Biometric Authentication**: Added fingerprint and face unlock support for quick access (when device supports BIOMETRIC_STRONG).
- **Layout Mode**: Enabled List/Grid layout toggle in Secure Folder sort options.
- **Back Button Behavior**: Pressing back in selection mode now deselects all items first before navigating back.
- **Hide Entry Point**: Option to hide Secure Folder from preferences (still accessible via title double-tap).
- **Don't Ask Again Flags**: Added "don't ask again" options for move, restore, delete, and hide entry point confirmations.
- **Tablet Responsiveness**: Improved Secure Folder UI for tablet and foldable devices.

### 🏷️ Branding, Licensing & Cleanup
- **App Rename**: The app is now branded **Mpv∞** (renamed from "MpvInfinity") across UI, docs, and metadata.
- **New License**: Relicensed to **CC BY-NC 4.0** with license headers applied across the codebase.
- **Acknowledgements**: Added credit for MpvRex and Pixel Player (UI and thumbnail pipeline inspiration) and AFinity.
- **Code Quality**: Added ktlint formatting enforcement and fixed AAPT resource and Kotlin compiler warnings.

## 1.5.0-preview.5 — Preview Release

### Syncplay
- **Synchronized room playback**: Added Syncplay server, room, username, and optional password controls to Network Streaming.
- **Live player integration**: Local pause, resume, seek, file, and playback-position changes are shared with the room, while remote room updates are applied to mpv.
- **Protocol compatibility fixes**: Added the legacy and real protocol version handshake fields, MD5 server-password handling, latency compensation, user-list updates, and `ignoringOnTheFly` feedback suppression.
- **Localized interface**: Extracted all Syncplay UI text into Android resources and translated it for Arabic, German, Spanish, French, Japanese, Brazilian Portuguese, Russian, and Simplified Chinese.

### Google Cast
- **Native Cast control**: Added the standard stateful Google Cast button to portrait and landscape player controls, including a one-time layout migration for existing users.
- **Local and remote media handoff**: Receiver-accessible HTTP(S) streams are loaded directly; Android-local `file://` and `content://` media use a tokenized temporary LAN server with byte-range seeking and CORS support.
- **Playback continuity**: The sender transfers title, play state, duration, and current position, pauses local playback after a successful receiver load, and restores local playback at the receiver position when casting ends.
- **Complete sender controls**: Added Cast SDK expanded controls, notification/lock-screen integration, reconnection support, and receiver volume controls.
- **Receiver compatibility guardrail**: Casting uses Google's Default Media Receiver, so containers and codecs unsupported by the selected TV/Chromecast are not transcoded automatically.

### Playback Lifecycle & Background Playback
- **One background playback switch**: Audio preferences and the player background button now control the same persistent setting for both audio and video.
- **Reliable screen lock and unlock handling**: Playback now follows the selected background policy across screen-off, lock-screen, unlock, and resume transitions without losing the prior play state.
- **PiP lifecycle coordination**: Picture-in-picture transitions, PiP dismissal, screen locking while in PiP, and activity teardown now share one lifecycle policy instead of competing playback paths.
- **Persistent task-removal playback**: Swiping the app out of Recents no longer kills an active foreground playback session, so background audio continues until explicitly stopped.
- **Foreground service cleanup**: Disabling background playback immediately pauses playback and stops its foreground service and notification.
- **Preference migration**: Existing users who enabled the legacy audio-only screen-lock option are migrated to the unified background playback setting.

### Subtitle Search
- **Results appear as they arrive**: Online subtitle results are merged into the list as each selected SubHub source or Wyzie completes instead of waiting for every request.
- **Race-free repeat searches**: Starting another subtitle search cancels the previous request and clears stale results before streaming the new matches.

### Playback Engine
- **Updated bundled mpvlib**: Refreshed the packaged `mpvlib.aar` used by all preview APK variants.

### Media Library & Audio Browsing
- **Preference-aware media switch**: The Video/Audio selector appears only when audio browsing is enabled, remembers the selected library type, and resets to Video when audio browsing is disabled.
- **Complete audio playlists**: Audio launches now populate the active playlist so previous and next controls update and navigate correctly.
- **Square audio artwork**: Audio thumbnails use a square presentation in both grid and list cards while video thumbnails remain 16:9.
- **Audio-safe editing**: Video compression actions are hidden for audio selections and guarded from opening with audio files.

### Player Polish
- **Rounded streaming cache indicator**: Buffered seekbar progress is clipped to the same pill-shaped ends as the normal seek track.
- **Smoother natural visualizer**: Higher-rate spectrum capture, tuned frequency envelopes, frame-time-aware interpolation, and responsive beat decay make the audio blob react fluidly without harsh jumps.

### AI Providers & Smart Tools
- **Current provider protocols**: OpenAI, Anthropic, Groq, OpenRouter, Together, and OpenCode Zen requests now follow their current API shapes; OpenCode models are routed through Responses, Messages, Gemini, or Chat Completions as required.
- **Resilient response parsing**: Text, multipart content, reasoning blocks, citations, provider errors, and both object- and array-based model lists are parsed without relying on one rigid response schema.
- **Thinking-model rename fixes**: AI rename and subtitle-title output now discard reasoning and code fences, accept structured JSON fields, preserve extensions, and reject empty or unsafe names.
- **Provider-specific model memory**: Each provider keeps its own selected model and cached model list, preventing stale selections when switching services.
- **Correct speech endpoints**: Groq and OpenAI use supported transcription models, while OpenRouter speech requests use its current base64 JSON audio format.

## 1.5.0-preview.4 — Preview Release

### Google Cast
- **Native Cast control**: Added the standard stateful Google Cast button to portrait and landscape player controls, including a one-time layout migration for existing users.
- **Local and remote media handoff**: Receiver-accessible HTTP(S) streams are loaded directly; Android-local `file://` and `content://` media use a tokenized temporary LAN server with byte-range seeking and CORS support.
- **Playback continuity**: The sender transfers title, play state, duration, and current position, pauses local playback after a successful receiver load, and restores local playback at the receiver position when casting ends.
- **Complete sender controls**: Added Cast SDK expanded controls, notification/lock-screen integration, reconnection support, and receiver volume controls.
- **Receiver compatibility guardrail**: Casting uses Google's Default Media Receiver, so containers and codecs unsupported by the selected TV/Chromecast are not transcoded automatically.

### Playback Lifecycle & Background Playback
- **One background playback switch**: Audio preferences and the player background button now control the same persistent setting for both audio and video.
- **Reliable screen lock and unlock handling**: Playback now follows the selected background policy across screen-off, lock-screen, unlock, and resume transitions without losing the prior play state.
- **PiP lifecycle coordination**: Picture-in-picture transitions, PiP dismissal, screen locking while in PiP, and activity teardown now share one lifecycle policy instead of competing playback paths.
- **Persistent task-removal playback**: Swiping the app out of Recents no longer kills an active foreground playback session, so background audio continues until explicitly stopped.
- **Foreground service cleanup**: Disabling background playback immediately pauses playback and stops its foreground service and notification.
- **Preference migration**: Existing users who enabled the legacy audio-only screen-lock option are migrated to the unified background playback setting.

### Subtitle Search
- **Results appear as they arrive**: Online subtitle results are merged into the list as each selected SubHub source or Wyzie completes instead of waiting for every request.
- **Race-free repeat searches**: Starting another subtitle search cancels the previous request and clears stale results before streaming the new matches.

### Playback Engine
- **Updated bundled mpvlib**: Refreshed the packaged `mpvlib.aar` used by all preview APK variants.

### Media Library & Audio Browsing
- **Preference-aware media switch**: The Video/Audio selector appears only when audio browsing is enabled, remembers the selected library type, and resets to Video when audio browsing is disabled.
- **Complete audio playlists**: Audio launches now populate the active playlist so previous and next controls update and navigate correctly.
- **Square audio artwork**: Audio thumbnails use a square presentation in both grid and list cards while video thumbnails remain 16:9.
- **Audio-safe editing**: Video compression actions are hidden for audio selections and guarded from opening with audio files.

### Player Polish
- **Rounded streaming cache indicator**: Buffered seekbar progress is clipped to the same pill-shaped ends as the normal seek track.
- **Smoother natural visualizer**: Higher-rate spectrum capture, tuned frequency envelopes, frame-time-aware interpolation, and responsive beat decay make the audio blob react fluidly without harsh jumps.

### AI Providers & Smart Tools
- **Current provider protocols**: OpenAI, Anthropic, Groq, OpenRouter, Together, and OpenCode Zen requests now follow their current API shapes; OpenCode models are routed through Responses, Messages, Gemini, or Chat Completions as required.
- **Resilient response parsing**: Text, multipart content, reasoning blocks, citations, provider errors, and both object- and array-based model lists are parsed without relying on one rigid response schema.
- **Thinking-model rename fixes**: AI rename and subtitle-title output now discard reasoning and code fences, accept structured JSON fields, preserve extensions, and reject empty or unsafe names.
- **Provider-specific model memory**: Each provider keeps its own selected model and cached model list, preventing stale selections when switching services.
- **Correct speech endpoints**: Groq and OpenAI use supported transcription models, while OpenRouter speech requests use its current base64 JSON audio format.

## 1.5.0-preview.3 — Preview Release

### Playback Hotfix
- **Audio and video transitions rebuilt**: Every item is loaded with file-local video-track selection, preventing audio state from producing a black screen on the next video.
- **Reliable next-item playback**: Runtime navigation now sends an actual mpv `loadfile` replacement and clears the previous EOF pause state.
- **Preference-safe EOF handling**: Autoplay, Repeat One, Repeat All, Shuffle, playlist mode, and close-at-end now behave consistently, including very short audio files.
- **Safe seeking**: Audio never enters the native video-thumbnail path, and video thumbnails are generated only on demand while scrubbing—not automatically during file load.
- **Separated render surfaces**: The blob surface is mounted only for media independently identified as audio, preventing it from covering video during track-list transitions.
- **True beat response**: With audio-capture permission, real FFT data exclusively drives the blob; brightness and bloom are reduced while bass onsets pulse more clearly.

### 🔊 Audio Blob Visualizer
- **OpenGL ES 3.0 blob visualizer** — when playing audio without cover art, a reactive 3D blob appears behind the player controls. The blob morphs, pulses, and shifts color based on audio energy with a bloom/glow post-process.
- **Touch rotation**: Drag the blob to rotate it in 3D.
- **Pinch zoom fixed**: The blob now properly shrinks/enlarges when pinching — `pinchScaleFromRenderer()` was hardcoded to always return `1f`, resetting zoom on every new gesture.
- **Smaller default size**: Camera distance increased so the blob fits cleanly within screen bounds instead of nearly filling the height.
- **Audio Preferences toggle**: New "Audio blob visualizer" switch in Settings > Audio to enable or disable it.
- **Audio filter setting moved**: Audio filter (compressor/equalizer) options now live in Audio Preferences instead of the player's MoreSheet.

### 🎬 yt-dlp Changes
- **Audio quality preferences**: Independent bitrate caps for `Auto`, 64, 128, 192, and 256 kbps — composed with existing codec, resolution, FPS, HDR, and container selectors.
- **Serialized URL loading**: Initial and replacement URL loads now use one cancellable serialized job, preventing overlapping libmpv commands when links are pasted rapidly.
- **Graceful error recovery**: Recoverable URL load failures return to the player UI with an error message instead of escaping to the process-wide crash handler.
- **Audio quality removed from MoreSheet**: yt-dlp audio quality selector moved from the player's MoreSheet to yt-dlp settings.

### 📻 Audio Browsing
- **MediaStore + filesystem discovery** for common audio formats, neutral media counts, audio MIME mapping, and Android 13 `READ_MEDIA_AUDIO` permission handling.
- **Audio cards** show metadata titles, embedded cover artwork when available (via `audio-display=embedded-first`), and a music-note fallback icon.
- **Portrait-only playback** — audio files force sensor-portrait orientation and prevent the rotation action from switching back to landscape.
- **Sibling playlist includes audio** — when "Include audio" is on, the next/previous track list includes audio files from the same folder.
- **Audio icon placeholder fix**: Exported icon now displays correctly for audio files without cover art.
- **Audio pitch correction fix**: Pitch correction no longer persists when switching to a new video — resets to default per-file.
- **Audio autoplay race condition fixed**: Eliminated a race condition that could cause audio files to fail starting playback.

### 🌐 Network & External Playback
- **WebDAV PROPFIND fix**: Connection checks now use a depth-zero `PROPFIND` request instead of Sardine's `HEAD`-based `exists()` call, making it work with servers like FileBrowser Quantum that reject `HEAD` on DAV collections.
- **WebDAV trailing slash**: Collection URLs consistently keep a trailing slash during validation and browsing.
- **External-player discovery**: Added a MIME-only intent filter so external-player pickers can find Mpv∞ before attaching the final video or audio URI.
- **More protocol support**: Added `gopher://`, `sctp://`, and `data://` to network stream detection and intent filters.
- **Stream compatibility improved**: Better handling of edge-case media streams and improved browsing reliability.

### 🌲 Tree View Navigation
- **Configurable path compression**: New `Off`, 1–5, and `Unlimited` choices for single-child folder flattening. Applied independently per navigation step, preserving predictable physical paths. Tree View refreshes instantly when the depth changes.

### 🎨 Icon Consistency
- Converted all three `painterResource(R.drawable.ic_material_symbols_check)` usages to `Icons.Default.Check` through the app's `AppIcon` / `Icon` system.
- `SectionHeader.leadingIcon` and `CompactExpressiveIconButton.imageVector` now accept `AppIcon` instead of raw `ImageVector`, keeping everything on the unified icon pipeline.

### 🔊 Audio Playback Runtime Fixes
- **`local_media_path` extra**: Internal launches now pass the resolved filesystem path alongside the content URI, giving mpv a reliable fallback when `content://` URIs fail.
- **Serialized load dispatcher**: Added a dedicated `Dispatchers.Default.limitedParallelism(1)` dispatcher for media loading — prevents race conditions when queuing multiple load commands.
- **`vid=auto` before playback**: Non-M3U file loads explicitly reset the video track to auto before loading, avoiding "no video track" state from previous audio-only plays.
- **`audio-display=embedded-first`**: Enabled MPV's embedded cover art rendering for audio files.
- **Orientation on audio launch**: `setOrientation()` checks `isKnownAudioLaunch()` immediately, before the track-list event settles — fixes the black-screen + landscape glitch on audio start.
- **Subtitle "Off" option**: Added an explicit "Off" choice in the player subtitle sheet so users can disable subtitles without cycling through all tracks.

### 🗑️ Folder Deletion Behavior
- **Media-only deletion (default)**: Deleting a folder now only removes audio/video files — other files (images, logs, documents) are left untouched.
- **"Delete folder + all contents" toggle**: New option in Appearance Settings > File Browser to switch back to full recursive deletion when needed.
- **Album View cleanup fix**: Fixed an issue where the last video file in a folder was deleted but the empty folder remained.

### 📱 Tablet & Display
- **Dynamic refresh rate**: The player can now dynamically adjust the display refresh rate to match the video frame rate for smoother playback.
- **Dual-pane navigation fix**: Resolved a state leak that could cause crashes when navigating in tablet dual-pane mode.
- **Dual-pane settings button hidden**: The redundant settings button is no longer shown in dual-pane mode on tablets.
- **Folder card height fix**: Manual grid column counts now align properly with folder card heights in dual-pane layout.

### 🔍 Settings Search
- **Search history**: Recently searched terms are saved and displayed for quick re-selection.
- **Search suggestions**: The search field now shows contextual suggestions as you type.
- **Reflection-based fallback**: Settings search can dynamically discover settings via reflection when static indices are incomplete.



## 1.5.0-preview.2 — Preview Release

### 📦 MpvLib Update
- Updated mpv library and its dependencies

### ⚡ Performance & Startup
- **Faster video open**: Opening a video file now uses `Dispatchers.Default` for the `playFile()` call — keeps the UI thread free and the player starts faster
- **Leaner startup sync**: The MPV directory sync no longer blanket-copies `shaders/` and `fonts/` on every launch — only config files, scripts, and `script-opts/` are synced upfront. Shaders referenced in `mpv.conf` are pulled on demand via `syncReferencedShaders()`, and fonts are handled by the font manager. This cuts down startup time noticeably, especially for users with large shader packs
- **Removed Dynamic Speed Overlay**: The old `SpeedControlSlider` (a full-size overlay with a dot-track slider) and `CompactSpeedIndicator` are gone. Hold-speed is now shown as a simple, clean text pill (e.g. "2x"). The `showDynamicSpeedOverlay` preference has been removed too — no more toggles, no more clutter
- **Snap-to-preset hold speed**: The hold-speed gesture now snaps to fixed presets (0.5x → 1x → 1.5x → 2x → 2.5x → 3x → 3.5x → 4x) instead of a free-form slider. The settings slider also snaps to these values, so what you see is what you get
- **Hold speed range capped**: Boost speed is now capped at 0.5x–4x range (previously went up to 6x)

### 📱 Tablet Dual-Pane Layouts
- **Folder view dual pane**: On tablets (600dp+ smallest screen width), you can now see your folder list on the left and a video list on the right — tap a folder, see its contents immediately beside it. A new "Dual Pane View" toggle in Appearance Settings lets you turn this on/off
- **Settings dual pane**: The Settings screen also gets a two-panel layout on tablets — the section list stays on the left, and the selected settings page opens on the right. The currently active section is highlighted with a subtle background
- **Back navigation in dual pane**: Pressing back in dual-pane mode deselects the folder/settings page instead of closing the screen

### 🎥 Player & Subtitles
- **Invert swipe subtitle direction**: New "Invert swipe subtitles direction" setting in Gesture Preferences. When enabled, swiping left-to-right seeks backward and right-to-left seeks forward — useful if you prefer the mirrored behaviour
- **Screenshot overhaul**: Screenshot filename templates got a proper rework:
  - `%wH`, `%wM`, `%wS`, `%wT` now use the **video playback position** (not the wall clock time) — so screenshot filenames actually match the video timestamp
  - New template placeholders: `%F` (filename without extension), `%P` (position as `HH:MM:SS.mmm`), `%p` (position as `HH:MM:SS`)
  - `%f` now resolves from the actual filename first, falling back to media-title — more reliable naming
- **Korean Jamo subtitle fix**: Downloaded subtitles that use Korean Jamo (composite characters) now go through NFC Unicode normalization. No more broken/corrupted Korean glyphs in subtitles
- **Subtitle search keyboard fix**: Added `android:windowSoftInputMode="adjustResize"` to PlayerActivity — the subtitle search dialog no longer gets hidden behind the on-screen keyboard
- **Subtitle persistence fix**: External subtitles and subtitle settings now survive across playback sessions more reliably. Added `addSubtitleSuspend()` (suspend version) for better coroutine handling during subtitle loading
- **Cache indicator fix**: The buffered range on the seekbar no longer double-counts the played portion — it now shows the correct remaining buffer ahead of the playhead
- **Color hex fix**: `toColorHexString()` now manually extracts ARGB components instead of using `Int.toHexString()` which produced wrong values for some colors

### 🛠️ Lua Script Improvements
- **Lua `require()` support**: Custom Lua scripts using `require()` can now find modules in `script-modules/` subdirectories. The app recursively syncs helper folders from `scripts/` to internal storage, so Lua's C-level `fopen()` can actually read them. Modules are also cleaned up when scripts are disabled in settings

### 🧹 Cleanup
- **Removed libpython binaries**: Deleted ~50 MB of unused `libpython_bin.so` files from all 4 architectures — they were never loaded by the app
- **Simplified MPV version display**: Removed the `cleanBundledMpvVersion()` hack in CrashActivity — MPV version now shows cleanly without needing string patching
- **Fonts folder no longer auto-set**: When changing the base storage root, the fonts folder preference is no longer blindly overwritten — it's only cleared if it was pointing at the old root. This prevents accidental font-folder resets

## 1.5.0-preview.1 — Preview Release

### 📦 MpvLib Update
- Updated mpv library and its dependencies 

### ⚡ Performance & Stability
- **Startup optimization**: Deferred cold-start DB initialization, grammar pre-load, and auto-update check to cut first-frame time significantly
- **Memory leak fixes**: Plugged 5 memory leaks across PlayerActivity (screen-state receiver), PlayerViewModel (LRU caches, temp subtitle cleanup), MediaPlaybackService (bitmap leak), MainActivity (unused scope), and NetworkLifecycleObserver (uncancelled coroutine)
- **UI smoothness**: Optimized seekbar spring animation, precomputed skip-segment colors, memoized immutable copies in PlayerControls, hoisted per-card preference collectors
- **Player crash fix**: Resolved a crash in PlayerActivity during stream initialization
- **Streaming optimizations**: Load network streams on `Dispatchers.IO` instead of Default to reduce CPU pool contention

### 🎨 UI/UX Improvements
- **Dynamic Grids**: Added responsive grid layouts — auto-adjusts column count based on screen width across FileSystemBrowser, FolderList, VideoList, Playlist, and RecentlyPlayed screens
- **Centered controls**: Play/pause and navigation buttons now center in portrait mode
- **Haptic feedback**: Sort dialog sliders now provide haptic ticks on snap
- **Slider layout**: Column sliders placed side-by-side for better space usage
- **Theme refresh**: Boosted container saturation and surface tints across all themes (light/dark) for vivid, non-washed-out appearance
- **Subtitle sheet redesign**: Inline SeriesSelectionControls directly in the OnlineSubtitleSearchSheet search row
- **Compressor back-press fix**: Video compressor overlay now handles system back press correctly

### 🎥 Player & Streaming
- **HLS/DASH streaming fix**: Direct media URLs (.m3u8/.mpd/.mp4/.ts) now bypass yt-dlp and use mpv's native ffmpeg HLS demuxer — these streams previously failed in yt-dlp's generic extractor
- **yt-dlp audio selection**: New audio track selector in the yt-dlp panel; preferred languages sanitization for better auto-selection
- **Collapsible advanced settings**: YtdlpSettingsScreen now organizes advanced options under collapsible sections
- **Console option**: Added Console toggle in MoreSheet stats rows — opens the mpv debug console via script-message
- **Subtitle hitbox fixes**: Dynamic hitbox detection for multi-line wrapped text; fixed hitbox under zoom/pan; lowered minimum subtitle scale limit
- **Subtitle loading fix**: Fixed subtitle loading and player overlay issues with IntentSubtitleLoadPolicy and M3uPlaybackPolicy
- **Negative brightness**: Added negative brightness range support in vertical sliders
- **Streaming overlays**: Fixed streaming playback overlays and thumbnail rendering

### 🔍 Anime Skip Provider
- New **Anime Skip** provider (api.anime-skip.com GraphQL) for intro/ending detection — searches via MAL ID, pairs consecutive timestamps
- Removed dead db.videasy.net TMDB mirror (providers now skip IMDB resolution without it)
- Cleaned up WyzieSearchRepository: removed fallback mirror logic and dead VideasyTmdbTrendingResponse

### 📁 Media Search Engine
- **New MediaSearchEngine**: Dedicated search engine for searching files/folders with optimized indexing
- **FolderListScreen integration**: Search across folders and videos using the new engine with VideoFolder references
- **Multiple refactors**: Cleaned up search logic, improved readability, and added Kotlin smart-casting clarifications

### 🐛 Bug Fixes
- Fixed mpv console ytdl_hook warnings (removed invalid 'all_subtitles' option)
- Fixed video-aspect-override deprecation warnings
- Resolved player crash during stream playback
- Fixed subtitle swipe gesture hitbox
- Fixed dynamic grid rendering edge cases

## 1.4.1-final

### Player, Playback & Stability
- Fixed stuttering and massive frame drops by optimizing video and screen synchronization.
- Fixed overlapping video frames/glitches when skipping rapidly through videos.
- Fixed picture-in-picture mode progress sync so your playback progress is correctly saved on exit.
- Prevented screen locking when opening the video's chapter list if the video has no chapters.
- Fixed visible screen rotation animation glitches when using the swipe-back gesture to exit the player.
- Adjusted player bottom controls bar padding to a more comfortable size.
- Cleaned up redundant HDR colorspace and tone mapping settings to avoid visual confusion.
- Fixed sudden crashes when loading or playing certain media files.
- Added outlined text with a black border to the Stats Page 6 overlay so text stays readable over any video content.

### Library, File Browser & Sizing
- Fixed playback, titles showing up as raw IDs (like `msf:1000`), missing thumbnails, and progress tracking for local M3U/M3U8 playlists.
- Added support for folder thumbnails in folder grid view (disabled by default, can be turned on in settings).
- Centralized file sorting options and improved title alignment in grid layouts.
- Fixed selection bar background in library list and grid layouts.
- Added Copy, Move, and Compress/Downscale options to the library selection bar.
- Fixed top toolbar delete button showing during folder selection to prevent accidental folder deletions.
- Fixed thumbnail taps so they toggle item selection instead of selecting ranges of items.
- Fixed library Media Info button to open details page instead of playing the file.

### Gestures & Dialogs
- Fixed subtitle swipe and pinch gesture detection zones so they are more responsive and natural to use.
- Added custom skip keywords for video openings and endings to automatically skip intros/outros.
- Redesigned the Sort and View Options Dialog to be more compact, with a collapsible "Fields" toggle section.
- Fixed bottom control bar icon scaling for smaller/larger screens.
- Fixed a visual glitch where the seekbar layout preview looked wavy.

### Network & Connections
- Added support for sending your playback progress to Jellyfin when playing videos externally.

- Many More Small QOL Fixes and Optimizations 

## 1.4.0

### Player And Seek Preview

- added the ThumbFast-style seek preview UI and thumbnail cache improvements.
- restored the legacy live-video seek preview path and added a Player setting to switch between ThumbFast thumbnail preview and legacy live seeking.
- tightened ThumbFast preview accuracy by using smaller preview time buckets and preventing stale thumbnail requests from replacing the newest preview frame.
- fixed glitched player vector icons and tightened subtitle/notch safe-area behavior.
-  improved launch smoothness and predictive back behavior.

### Subtitles

-  added subtitle font management in Settings > Subtitles: choose a fonts directory, see the selected source folder, reload fonts, clear the font cache, and select the default subtitle font.
-  added custom subtitle border styles and a shadow offset slider.
- **Arnab Sadhukhan** added subtitle zoom gestures.
- **Arnab Sadhukhan** optimized the subtitle pinch hit-zone for multi-line subtitles.
- **Arnab Sadhukhan** added horizontal swipe on subtitles to seek dialog lines.

### Browser, Library, And Storage

- redesigned the Media Info page to use a premium, tabbed Material 3 interface with beautiful overview stats, container metadata detail, track summaries, and customizable sharing.
- implemented the unified Media Library view mode.
- added multi-select range handling, folder copy/move/rename, and SMB mutex/reconnection guards.
- redesigned settings sections and moved progress-related options into cleaner places.
- fixed segmented button unchecked color handling.
- fixed Lua script copy behavior.

### Gestures And Quality Of Life

- **Arnab Sadhukhan** added the playlist swipe-up gesture in the player when swiped up from middle of screen now playlists open.
- **Arnab Sadhukhan** added auto-scroll to the currently selected theme.
- Removed Avif / Jpeg-Xl type images from the settings selection
- Added Font selection in the Subtitle Settings section.
- Fixed issue of Lua script when copying specific part Copied whole Lua script.
- added Expressive Scrollbar like in Pixel player 

## 1.3.9

> # 🚀 **CURL IS NOW SUPPORTED!** 
> ### ⚠️ **EXPERIMENTAL** — This is brand new and may or may not work properly on your device. ⚠️
> Lua and JavaScript scripts can now make HTTP requests through the new native libcurl bridge via JNI.
> Use it, break it, and report issues so we can make it stable!, see `MPV_INFINITY_CUSTOM_COMMANDS.d` for tutorial on how to use in Lua and JS.
>
> **What this means:** You can now write scripts that fetch data from the internet — APIs, subtitles, metadata, you name it — all through libcurl compiled directly into the app.

- AI support has been updated. Gemini is removed and OpenCode Zen AI is now available for AI rename, subtitle formatting, and subtitle translation.
- AI model lists now come from the provider APIs instead of a saved model list in the app. OpenRouter also marks free models using the pricing data returned by OpenRouter itself.
- Background playback is fixed so repeat keeps working after using the headphone button, and returning to the player no longer restarts the current stream from the beginning.
- Subtitle search has been updated for the latest Wyzie source changes.
- Added Hybrid Skip Markers. The player can now check IntroDB, TIDB, and AniSkip together and use whichever result is found first.
- Anime4K settings are now easier to use with a collapsible section in Decoder Preferences and also Added Optimization by Sunny Vishnu .
- Added a setting to show or hide Media Info from Android's share/open-with screen.
- Added documentation for custom Lua/JS player commands in `MPV_INFINITY_CUSTOM_COMMANDS.md`.

## 1.3.8

- **Integrated yt-dlp by [**SunnyVishnu3**](https://github.com/SunnyVishnu3)** — Added full yt-dlp integration for video watching audio/video from YouTube and other supported sites directly within the app (_Dont expect from me to add Download Functionality_). **Note: You need to download yt-dlp first (Settings > Advanced > yt-dlp Manager) before playing YouTube links — don't be clueless.**
- Fixed Issue of USer defined Colors Filters were not getting Saved and not getting applied through Mpv conf by [**SunnyVishnu3**](https://github.com/SunnyVishnu3)
- Fixed Gemini AI Error Generating / Translating Subs.
- Fixed Crashing issue of MpvInfinity , in a nutshell Ambient mode and Custom lua were not initialized in Sync causing to crash player sometimes
- That's all for Today Adiosss!!

## 1.3.7

- **Updated Wyzie subtitle API integration** — Synced with latest Wyzie API changes: added `ai` field for AI-translated subtitle detection, updated provider sources list (removed `subdl`, `podnapisi`, `ajatttools`; added `tvsubtitles`), and fixed TMDB endpoints to include API key authentication.
- **Material 3 Expressive Design** — Complete visual overhaul using Material 3 Expressive design system for a more modern, fluid, and engaging experience
- **Smoother Animations** — Replaced rigid linear transitions with spring-based physics animations throughout the app (navigation, controls, browser, dialogs)
- Added Voltage Battery Temperature And improved the style of Page 6 
- Added Optimized Ambient Mode with Eco Battery Saver Mode who want to take feel of Ambient without much Battery Impact
- Removed Dead Code and also Optimized some File Handling / Ui Rendering Operations
- **Settings export now stores app version**  exported XML files include the app version, so import dialogs show the correct version instead of "unknown".
- **HEVC 10bit thumbnails**  added a software-decoder fallback using Android's MediaCodec API. When the system can't decode a video frame (e.g. HEVC 10bit on devices without hardware support), the app now tries Google's software decoder before giving up. This means more thumbnails will show up on devices with limited codec support ( To be tested Propelry on unsupported device).
- **Fixed app icon on Android 16**  changed the adaptive icon background from transparent to opaque black so the icon doesn't disappear on launchers that don't handle transparency well.
- **User mpv.conf now has highest priority**  during player startup, your mpv.conf settings are re-applied after all app defaults so they always take precedence. but some of the Hardcoded things doesnt change like for example `sid, aid`.
- 

## 1.3.6

- **Six AI providers, one gorgeous settings page**  OpenAI, Anthropic, OpenRouter, and Together joined Groq and Gemini in a completely redesigned UI. Every provider gets its own API key, every single model is visible (free ones get a bold green badge), and the new searchable model picker sorts free models to the top. The offline model experience got a premium card-based overhaul too  tiers, speed/translation badges, device recommendations, DeepSeek-R1 support, reasoning toggles, and a benchmark button for downloaded models. One-tap download, delete, and switch between models without ever leaving the screen.

- **Subtitle translation**  SUPPORTS ASS Subs Translation tooooooooo..... , you can now configure your target languages once in settings. One language means one tap to translate. Two or more means a clean picker showing only the languages you chose. Translation progress appears right on the video screen (even with the sheet closed), partially translated subs survive restarts, and a red X lets you cancel mid-translation instantly. When using local models, the system automatically picks the best downloaded model for each language, keeps it warm between chunks, and never runs two local AI jobs at once.

- **Generate subtitles from video audio**  **_(EXPERIMENTAL)_** This is work in progress might not work Don't baby Cry that this shit aint working ,i ain't getting paid enough to implement this whole heartedly , so what it does is -> one tap generates subtitles using the audio you're already playing. Media3 extraction feeds Groq, Gemini, or offline Whisper, and the resulting SRT/VTT saves automatically.

- **Smarter AI across the board**  reasoning tags are automatically stripped from final results, token limits prevent stalls in heavy tasks, and every AI feature (rename, formatting, translation) comes with customizable prompts that fall back gracefully to built-in instructions.

- **Real-time subtitle toggle**  new on/off switch in AI settings to control real-time subtitle generation from audio. When off, the indicator and generate button are hidden from the player.

- **AI features respect the master switch**  turning off AI Integration now hides all AI indicators (translation, real-time subs) and buttons (generate, translate, format) from the player view. Renamed "AI Subtitle Search Formatting" to "AI Search" for clarity.


## 1.3.5

- **Removed Play Store and F-Droid build variants**  streamlined to a single `standard` flavor with full update support and all features enabled.
- **Revamped README**  comprehensive feature documentation organized by category, UPI QR code and Buy Me a Coffee links in the Support section.
- **SMB Network Thumbnail Generation**  fixed thumbnail generation for SMB shares through Codex AI (Beta).
- **Bulk AI Rename**  rename multiple files at once using Gemini or Groq with concurrency limiting and edge case handling.
- **AI Subtitle Translation**  translate subtitles using AI providers with custom prompts, progress indication, and user preference management.
- **AI Subtitle Translation Enhancements**  in-house developed translation pipeline with fully customizable prompts and per-user preference overrides.

## 1.3.4

- Capped generated thumbnails to safer preview sizes so large videos do not waste memory while browsing.
- Improved MKV/WebM thumbnail handling, including embedded artwork and smarter fallback frames.
- Cleaned old thumbnail cache paths when clearing thumbnail cache.
- Fixed the About and crash info screen showing `UNKNOWN` in the bundled mpv version.
- Updated Gradle, Kotlin, Compose, Koin, Navigation 3, AndroidX, and related dependency versions through the version catalog.
- Added SUbHub MpvInfinity specific Subtitle Fetching nd Downloading featured developed by me
- Added Video COmpresser Overlay in Tree Mode also
- Cleaned up codebase and Improved Playback bottlenecks
- Added Window Offset to prevent Camera notch overlap issues


## 1.3.3

- Fixed Background Playback and Pip issues 
- Anime4K should feel much smoother now. The player now uses the clean six-preset Anime4K flow from the reference app and avoids piling old shader work on top of the new preset when you switch modes.
- Anime4K is still off by default, but when you turn it on the picker is simpler: Off, A, B, C, A+, B+, and C+.
- Moved the Fast / Balanced / High Anime4K choice into Decoder settings, with Balanced as the default.
- Removed frame interpolation because it added a lot of GPU load and did not add enough real value.
- Removed the old OneThird and Halfway thumbnail choices.
- Removed the unused old player screen path.
- Cleaned up the track sheets so audio, subtitle, chapter, decoder, and online subtitle lists no longer depend on the old generic sheet.
- Removed SubDL from subtitle search sources.
- Network streaming is now opt-in instead of being enabled on a fresh install.
- HDR and Ambient controls are no longer placed on the default player buttons, so heavy visual extras stay out of the way unless you add them yourself.
- Turning HDR on now starts with Linear HDR by default.
- The app now does less background media scanning and cache cleanup on startup, which should help large libraries open with less churn.
- Added new MpvLib File with Some Optimization and Removing Deprecated Andorid Versions
- Thumbnails are now Loaded Faster and more Precisly

## 1.3.2

### HDR hdr-toys Pipeline

- Replaced the old 3-mode HDR system (Off / SDR with HDR / Normal HDR) with a proper shader-based pipeline powered by [hdr-toys](https://github.com/natural-harmonia-gropius/hdr-toys).
- Four HDR modes are now available: **BT.2100 PQ** (HDR10), **BT.2100 HLG**, **BT.2020**, and **Linear HDR** (mpv-native, no shaders).
- 77 GLSL shaders are bundled in the app and copied to the mpv config directory on first use  no manual setup required.
- The HDR panel no longer shows an "Off" option. Off is the default and is toggled by the HDR button; the panel only presents the four active modes.
- Selecting a mode while GPU Next + Vulkan is unavailable shows a clear error pill and falls back to Off safely.
- Added `boostSdrToHdr` preference (used by the Linear HDR path).
- `HdrToysManager` cleanly removes all hdr-toys shaders when switching to Off or when the pipeline is not ready, so no stale shaders leak between sessions.

### Thermal & Battery Improvements

- Added `ThermalMonitor`  samples `PowerManager.getThermalHeadroom()` (Android 11+) every 10 seconds during playback.
- Ambient shader sample budget is automatically capped based on thermal headroom: 8 samples (severe), 12 (moderate), 18 (mild), uncapped (cool).
- Anime4K is proactively downgraded to C/Fast when thermal headroom drops below 40%, before frame drops even start.
- Ambient shader recompilation is now skipped when all parameters are identical to the last compiled version  reduces unnecessary GPU stutter on orientation changes and no-op callbacks.
- Removed redundant dual position polling: the event-driven `time-pos` observer and the polling loop were both updating the same StateFlow, causing double seek-bar recompositions on every MPV event.
- Background playback position poll interval halved from 250 ms to 500 ms when controls are not visible, cutting idle JNI wake-ups by 50%.

### Stats Page 6  Fixes

- **GPU estimate bar fixed**: was using cumulative drop + delay totals that drifted to 100% after long sessions and added a fixed FPS-proportional baseline (120fps with zero drops showed 70% GPU load). Now uses per-second delta counts relative to the current frame rate  0 drops = 0%, all frames dropped = 100%.
- **CPU label corrected**: relabelled from "CPU Usage" to "App CPU (this process)" to accurately reflect that `getElapsedCpuTime()` measures only MpvInfinity's own process, not the whole device.
- **Frame drop text now shows per-second deltas** alongside the all-time totals, so you can tell current rendering pressure at a glance.
- **Pause-aware poll backoff**: the stats loop backs off from 1 s to 2 s intervals when playback is paused, cutting pointless JNI calls when metrics are static.

### Gesture & Action Overlay Toggles

- Added a new **"Gesture & Action Overlays"** section in Player Settings with seven independent on/off switches:
  - **Volume slider overlay**  vertical pill shown during volume swipe
  - **Brightness slider overlay**  vertical pill shown during brightness swipe
  - **Hold speed overlay**  speed badge and slider shown during long-press speed boost
  - **Aspect ratio feedback**  pill shown when cycling aspect ratio
  - **Zoom level feedback**  pill shown when pinching to zoom
  - **Repeat & shuffle feedback**  pill shown when toggling repeat or shuffle
  - **Action feedback pills**  brief text pills from custom buttons, ambient toggle, subtitle drag, and Lua/JS scripts
- All overlays default to **on**, so existing behaviour is unchanged until the user opts out.
- Disabling an overlay suppresses only the visual pill  the underlying gesture action (volume change, speed change, etc.) still happens normally.

## 1.3.1

- Update FFmpeg to n8.1 (latest stable)
- Update Android SDK to 36, build tools 36.0.0
- Update Kotlin to 2.1.21, Gradle to 8.11.1
- Update dependencies: unibreak 6.2, harfbuzz 11.5.0, fribidi 1.0.17, freetype 2.13.4, mbedtls 3.6.5
- Add mujs 1.3.5 support for JavaScript scripting inside mpv
- JavaScript (.js) scripts are now supported alongside Lua scripts, with "Scripts (Lua / JS)" kept to the main section titles.
- Script editor now uses the native Sora editor with TextMate syntax highlighting for Lua and JavaScript.
- Script editor includes a chip toggle to choose between `.lua` and `.js` file extensions when creating or editing scripts.
- Custom player buttons can now run either Lua or JavaScript, with language selection per button and import/export support.
- Long-pressing the HDR button now opens an HDR Output panel with Off, SDR with HDR, and Normal HDR modes.
- Media title resolution improved: MPV's resolved title is preferred for non-direct-media URLs and when the current filename looks like a generic route (e.g., `/watch`, `/stream`).
- Updated mpv library dependency from `mpv-android-lib-v0.0.1.aar` to `mpvlib.aar` and removed the old AAR.
- Added Multiple new provider to Wyzie subtitle sources.
- PiP and background playback now save the latest watched position instead of returning to the timestamp from before PiP started.
- Video lists refresh playback progress as soon as the saved position changes, so returning from the player shows the current progress.
- Folder thumbnails now begin rendering immediately when a folder opens, while still using cached thumbnail data first.

## 1.3.0

- The project now carries the `MpvInfinity` name across the app, docs, and release files.
- Tree View `NEW` labels now work properly and update as you watch.
- Single-child folders now flatten automatically so you reach files faster.
- Subtitle matching is smarter and better at finding subtitles that line up.
- Cached library data shows up first, then refreshes quietly in the background.
- Browser updates now react to changes instead of constantly polling.
- The player now remembers your chosen aspect ratio.
- Seeking feels steadier and cleanup after playback is smoother.
- Ambient mode and Lua scripting were reverted.
- The settings page was revamped.
- New tab and video animations were added.
- Icons were refreshed across the app.
- Network and playlist behavior was cleaned up.
- Folder pinning was added.
- A video size downgrade option was added in the video editing section.
- Page 6 was added to More Sheet for battery usage and extra system info.
- A new status icon row can show network speed, battery percentage, and time.

## 1.2.9

- Library scanning became faster and more dependable.
- Subtitle search got a noticeable improvement.
- Theme picking now jumps to the active theme more cleanly.
- Ambient mode got another round of polish and fixes.

## 1.2.8-hotfix

- A rough ambient mode change was rolled back to keep playback stable.
- The zoom sheet layout was cleaned up.
- Playback profiles became easier to manage.

## 1.2.8

- Background playback became more dependable.
- File rename and delete flows became safer and clearer.
- Custom buttons load more reliably.
- Play Store and F-Droid releases were cleaned up.
- The update and media tools were reorganized.

## 1.2.7

- The seekbar was cleaned up and accidental swipe behavior was reduced.
- F-Droid builds were added.
- Release packaging and signing became more reliable.

## 1.2.6

- Background playback and notifications became steadier.
- Filter presets and video quality controls were improved.
- External subtitle scaling and positioning were fixed.

## 1.2.5

- Video scaling and smooth motion options were added.
- Thumbnail generation became faster and more consistent.
- Browser spacing and player gestures were cleaned up.

## 1.2.4

- New videos now show a `NEW` label more reliably.
- Rotated videos and aspect handling were improved.
- Subtitle styling controls were expanded.
- Playlist order and storage permission handling were cleaned up.

## 1.2.3

- Network thumbnails became optional.
- Recently Played works better with network items.
- Thumbnail loading became faster.
- Browser navigation and floating actions became more consistent.

## 1.2.2

- Repeat and shuffle now stay the way you left them.
- Subtitle preferences now carry across playback more reliably.
- Hardware decoding falls back more safely on tricky devices.
- Player rotation and status bar behavior were improved.
- SMB playback became more dependable.

## 1.2.1

- Grid mode arrived for folders and videos.
- Scroll position is remembered when you come back.
- Thumbnail visibility can be toggled.
- A background playback edge case was fixed.

## 1.2.0

- The app got a major Material 3 refresh.
- Settings were reorganized into a cleaner card layout.
- Local M3U playlists were added.
- Recently Played got pull-to-refresh.
- Track and subtitle handling became smarter.

## 1.1.0

- Network browsing arrived for SMB, FTP, and WebDAV.
- File manager mode and breadcrumb navigation were added.
- Playlist mode became more useful.
- Recently Played learned how to handle playlists too.
- The project website and screenshots were refreshed.

## 1.0.0

- First public release.
- Media info viewing and sharing were added.
- F-Droid release work was prepared.
