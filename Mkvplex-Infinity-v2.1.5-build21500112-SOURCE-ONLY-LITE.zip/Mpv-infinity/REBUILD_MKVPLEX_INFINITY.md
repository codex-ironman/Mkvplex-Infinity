# Rebuilding Mkvplex Infinity

This is a modified build of the AGPL-3.0 Mpv Infinity v2.1.5 source at
`d9b32dfe5b26068a22f4cfea5463729aa843d215`.
Upstream: https://github.com/ZHINFINITY/Mpv-infinity/tree/v2.1.5
No v2.2.5 Permission-Only implementation is included.

See `MKVPLEX_INFINITY_PORT.md` for feature coverage. The root LICENSE and
upstream dependency notices are retained. This package is a custom build,
not an official upstream release.

## Build

Use JDK 17, the included Gradle wrapper (Gradle 9.5.0), Android SDK platform
37.0, build-tools 36.0.0, CMake 3.22.1 and NDK 27.3.13750724. The
`subtitle-libass` module also uses platform 35 and NDK 28.2.13676358.
Accept Android SDK licenses using the normal SDK manager. Configure the
SDK path in local.properties or ANDROID_HOME. The repository's AARs,
JNI libraries and native source are included in the complete source archive.

```bash
./gradlew :app:testStandardDebugUnitTest \
  -PtargetAbi=arm64-v8a -PenableX86=false \
  -PcustomApplicationId=app.infinity.mpvz.mkvplex \
  -PcustomVersionCode=2150011 --no-configuration-cache

./gradlew :app:assembleStandardRelease \
  -PtargetAbi=arm64-v8a -PenableX86=false \
  -PcustomApplicationId=app.infinity.mpvz.mkvplex \
  -PcustomVersionCode=2150011 --no-configuration-cache
```

The ARM64 split's resulting versionCode is 21500112. The supplied release was
built with `-I ../build-tools/unshrunk_release.gradle` to skip bytecode and
resource shrinking. Sign your rebuild with your own Android key. It will not
update the supplied custom APK unless signed with that APK's original key.
Signing keys and server credentials are excluded from the complete source
archive. The separate private build backup contains the update-signing key.

## Supplied APK verification

`VALIDATION.json` records the finished APK hash, signing certificate,
test totals and limitations. The supplied APK preserves all 25 native
libraries and 219 bundled non-ART assets from the official v2.1.5 ARM64 APK,
whose SHA256 is:
`c866b214597c8867044eabd54618e13ea30cc148e5b26e9d9e2de9b713db0ccc`.

Official baseline URL:
https://github.com/ZHINFINITY/Mpv-infinity/releases/download/v2.1.5/Mpv.-arm64-v8a-v2.1.5.apk

The build-tools folder includes the packaging verification used for this
release. Rebuilt ART profiles are retained for the new DEX. The upstream
updater is disabled because official APKs have a different application ID
and signing identity. No physical-device playback test is implied by a
successful JVM test or signature check.

The release uses the exact unchanged subtitle JNI bridge from that verified
official APK. Building the upstream libass dependency downloads locally failed
at their autotools configure step. To reproduce the supplied native selection,
place the official APK at `baseline/official-v215.apk` next to the source folder,
run `python3 build-tools/prepare_official_libass.py` from the archive root, then
run the release Gradle command inside `Mpv-infinity` with the extra argument
`-I ../build-tools/official_libass.gradle`. The helper checks the entire official
APK hash before extracting the bridge. It stages the binary under `tooling/`;
the original subtitle JNI/Java source and the player engines stay unchanged.

For this hero update, the unchanged CMake outputs can also be staged from the
verified previous custom ARM64 APK, build 21500102:

```bash
python3 build-tools/prepare_previous_native.py /path/to/previous.apk "$PWD/native"
export MKVPLEX_NATIVE_ROOT="$PWD/native"
cd Mpv-infinity
./gradlew :app:testStandardDebugUnitTest :app:assembleStandardRelease \
  -PtargetAbi=arm64-v8a -PenableX86=false -I ../build-tools/previous_native.gradle
```

The package helper verifies the resulting version and checks all native
libraries and non-profile assets against the previous signed release.

To reproduce the supplied release packaging, pass `--unshrunk` to
`build-tools/package_hero_update.py` after using the unshrunk release init script.
