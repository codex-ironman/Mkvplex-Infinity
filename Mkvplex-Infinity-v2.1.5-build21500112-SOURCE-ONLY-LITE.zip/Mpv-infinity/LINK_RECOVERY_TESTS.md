# Source-list diagnostics — build 27300152

Checked the authorized Polyfin demo account using same-origin authenticated metadata and PlaybackInfo requests on 2026-10-28. Eleven distinct series at S1E8, plus The Pitt S1E13, were each requested twice. No media body, CDN redirect, subtitle or full video was downloaded in this diagnostic. Counts are snapshots and can change as addons finish or the server filters failed versions.

| Series | Episode | First PlaybackInfo | Second PlaybackInfo |
|---|---|---:|---:|
| The Pitt | S1E8 | 32 links | 31 links |
| Reacher | S1E8 | NoCompatibleStream (0 links) | 30 links |
| Thukra Ke Mera Pyaar | S1E8 | 7 links | 11 links |
| Queen of Tears | S1E8 | 13 links | 33 links |
| MF GHOST | S1E8 | 12 links | 36 links |
| Fire Force | S1E8 | 17 links | 18 links |
| Severance | S1E8 | 59 links | 62 links |
| FROM | S1E8 | 82 links | 83 links |
| Wednesday | S1E8 | 31 links | 30 links |
| Stranger Things | S1E8 | 39 links | 42 links |
| The Last of Us | S1E8 | 9 links | 63 links |
| The Pitt | S1E13 | 50 links | 83 links |

Every HTTP response in these twelve cases was 200. Reacher S1E8 nevertheless returned ErrorCode=NoCompatibleStream on the first PlaybackInfo, followed by 30 sources on the second. The Pitt S1E13 did not reproduce an empty response during this run, but its metadata expanded from 52 to 85 sources (PlaybackInfo 50 to 83). These results establish a dynamic first-request/late-provider behavior; they do not establish that every returned URL plays.

The app now distinguishes transient source-list errors from authentication/account limits, retries at most twice inside the current chooser, retains usable links during recovery, and refreshes metadata to merge later provider results. Requests cancel on close or replacement. If a provider permanently returns no sources, the app still reports the final failure and offers Retry. No Oracle or Polyfin configuration was changed.

Google Cast discovery and receiver playback need a physical Android device and a compatible receiver. The long-press shortcut was compiled with the existing Cast SDK; container/resume policy and default-OFF preference were covered by JVM tests. No physical receiver or phone UI verification is claimed. This shortcut does not implement Polyfin's separate DLNA or signed-in-app remote-control APIs.
